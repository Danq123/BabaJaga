import React, { useState } from 'react';
import { View, Text, SafeAreaView, StatusBar as RNStatusBar, Platform, ScrollView, StyleSheet, Modal, ActivityIndicator } from 'react-native';
import { StatusBar } from 'expo-status-bar';

import { C, S, F, R } from './src/theme.js';
import TabBar, { TABS } from './src/components/TabBar.js';
import { Card, Button, Toast } from './src/components/ui.js';
import { useGame } from './src/game/useGame.js';
import { APP_NAME } from './src/appInfo.js';
import { formatGameTime, formatDuration, formatBtc, formatEur, formatHash } from './src/game/format.js';

import FarmScreen from './src/screens/FarmScreen.js';
import ShopScreen from './src/screens/ShopScreen.js';
import MarketScreen from './src/screens/MarketScreen.js';
import LearnScreen from './src/screens/LearnScreen.js';
import StatsScreen from './src/screens/StatsScreen.js';

export default function App() {
  const { ready, state, derived, actions, offline, toasts, liveInfo } = useGame();
  const [tab, setTab] = useState('farm');
  const [showIntro, setShowIntro] = useState(true);

  if (!ready || !state || !derived) {
    return (
      <View style={st.loading}>
        <ActivityIndicator color={C.accent} size="large" />
        <Text style={[F.small, { marginTop: S.md }]}>Načítavam farmu…</Text>
      </View>
    );
  }

  const badge = {};
  if (derived.brokenCount > 0) badge.shop = derived.brokenCount;
  if (toasts.length) badge.farm = toasts.length;

  const time = formatGameTime(state.time);

  return (
    <SafeAreaView style={st.safe}>
      <StatusBar style="light" />
      {Platform.OS === 'android' ? <View style={{ height: RNStatusBar.currentHeight || 0, backgroundColor: C.bg }} /> : null}

      {/* ---------------- hlavička ---------------- */}
      <View style={st.header}>
        <View style={{ flex: 1 }}>
          <Text style={st.title}>
            <Text style={{ color: C.accent }}>₿</Text> Bitcoin Farma
          </Text>
          <Text style={F.tiny}>
            {time.label} · {state.paused ? '⏸ pauza' : `${state.speed}× rýchlosť`}
          </Text>
        </View>
        <View style={st.headerStats}>
          <HeaderStat label="MAJETOK" value={formatEur(derived.netWorth, 0)} color={C.accent} />
          <HeaderStat label="BTC" value={formatBtc(state.btc, 5)} />
          <HeaderStat label="HASHRATE" value={formatHash(derived.hashrate)} />
        </View>
      </View>

      {/* ---------------- obsah ---------------- */}
      <View style={{ flex: 1 }}>
        {tab === 'farm' ? <FarmScreen state={state} d={derived} actions={actions} goShop={() => setTab('shop')} /> : null}
        {tab === 'shop' ? <ShopScreen state={state} d={derived} actions={actions} /> : null}
        {tab === 'market' ? <MarketScreen state={state} d={derived} actions={actions} liveInfo={liveInfo} /> : null}
        {tab === 'learn' ? <LearnScreen state={state} /> : null}
        {tab === 'stats' ? <StatsScreen state={state} d={derived} actions={actions} /> : null}
      </View>

      <TabBar active={tab} onChange={setTab} badge={badge} />

      {/* ---------------- toasty ---------------- */}
      <View pointerEvents="box-none" style={st.toastLayer}>
        {state.toast ? (
          <Toast
            kind={state.toast.kind}
            title={state.toast.title}
            text={state.toast.text}
            actionLabel="zavrieť"
            onPress={actions.dismissEngineToast}
          />
        ) : null}
        {toasts.slice(0, 2).map((t, i) => (
          <View key={i} style={{ marginTop: i ? S.sm : 0 }}>
            <Toast kind={t.kind} title={t.title} text={t.text} actionLabel="super" onPress={actions.dismissToast} />
          </View>
        ))}
      </View>

      {/* ---------------- offline ---------------- */}
      <Modal visible={!!offline} transparent animationType="fade" onRequestClose={actions.dismissOffline}>
        <View style={st.overlay}>
          <Card style={st.modal}>
            <Text style={{ fontSize: 34 }}>😴</Text>
            <Text style={[F.h2, { marginTop: S.sm }]}>Zatiaľ čo si bol preč…</Text>
            <Text style={[F.small, { marginTop: S.sm, lineHeight: 20, color: C.textDim }]}>
              Farma bežala {formatDuration(offline.offlineGameSeconds)} herného času
              {offline.capped ? ' (limit offline progresu)' : ''}.
            </Text>
            <View style={st.divider} />
            <RowLine label="Vyťažené" value={formatBtc(offline.gainedBtc || 0, 8)} color={C.accent} />
            <RowLine
              label="Zmena hotovosti"
              value={`${(offline.spentEur || 0) > 0 ? '−' : '+'}${formatEur(Math.abs(offline.spentEur || 0), 2)}`}
              color={(offline.spentEur || 0) > 0 ? C.red : C.green}
            />
            <RowLine label="Aktuálny majetok" value={formatEur(derived.netWorth, 0)} color={C.text} />
            <Button style={{ marginTop: S.lg }} label="Pokračovať" onPress={actions.dismissOffline} />
          </Card>
        </View>
      </Modal>

      {/* ---------------- intro ---------------- */}
      <Modal visible={showIntro} transparent animationType="fade" onRequestClose={() => setShowIntro(false)}>
        <View style={st.overlay}>
          <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', padding: S.xl }}>
            <Card style={st.modal}>
              <Text style={{ fontSize: 40 }}>⛏️</Text>
              <Text style={[F.h1, { marginTop: S.sm }]}>{APP_NAME}</Text>
              <Text style={[F.small, { marginTop: S.xs, color: C.accent, fontWeight: '700' }]}>
                vzdelávacia simulácia ťažby
              </Text>

              <View style={st.divider} />

              {[
                ['🖨️', 'Kupuj ASIC stroje', 'Rozhoduje efektivita v J/TH a tvoja cena elektriny — nie hashrate.'],
                ['🌡️', 'Stráž chladenie', 'Príliš veľa tepla = stroje samy znížia výkon alebo sa odpoja.'],
                ['📈', 'Sleduj 4-ročný cyklus', 'Halving zníži odmenu o polovicu. Cena historicky vrcholí 1–1,5 roka po ňom.'],
                ['💶', 'Predávaj BTC na prevádzku', 'Elektrina sa platí v eurách, ťažíš v bitcoinoch. Presne ako v skutočnosti.'],
                ['🎓', 'Uč sa hraním', 'Každá udalosť a nákup odomyká vysvetlenie reálneho mechanizmu Bitcoinu.'],
              ].map(([e, t, d2], i) => (
                <View key={i} style={st.introRow}>
                  <Text style={{ fontSize: 18 }}>{e}</Text>
                  <View style={{ flex: 1, marginLeft: S.md }}>
                    <Text style={F.h3}>{t}</Text>
                    <Text style={[F.tiny, { lineHeight: 15, marginTop: 2 }]}>{d2}</Text>
                  </View>
                </View>
              ))}

              <View style={[st.warnBox]}>
                <Text style={[F.tiny, { lineHeight: 16, color: C.yellow }]}>
                  ⚠️ Toto je hra. Nepoužívajú sa žiadne reálne bitcoiny ani peniaze a nie je to investičné
                  poradenstvo. Nikto nedokáže bitcoin „namnožiť“ — sľuby garantovaného zhodnotenia sú podvod.
                </Text>
              </View>

              <Button style={{ marginTop: S.lg }} label="Začať ťažiť" onPress={() => setShowIntro(false)} />
              <Button
                style={{ marginTop: S.sm }}
                variant="muted"
                label="Najprv si prečítať Akadémiu"
                onPress={() => {
                  setShowIntro(false);
                  setTab('learn');
                }}
              />
            </Card>
          </ScrollView>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

function HeaderStat({ label, value, color }) {
  return (
    <View style={{ alignItems: 'flex-end' }}>
      <Text style={F.tiny}>{label}</Text>
      <Text style={[F.mono, { fontSize: 13, color: color || C.text }]} numberOfLines={1}>
        {value}
      </Text>
    </View>
  );
}

function RowLine({ label, value, color }) {
  return (
    <View style={st.rowLine}>
      <Text style={[F.small, { flex: 1 }]}>{label}</Text>
      <Text style={[F.mono, { color }]}>{value}</Text>
    </View>
  );
}

const st = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  loading: { flex: 1, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: S.lg,
    paddingVertical: S.md,
    backgroundColor: C.bgAlt,
    borderBottomWidth: 1,
    borderBottomColor: C.border,
    gap: S.md,
  },
  title: { fontSize: 18, fontWeight: '800', color: C.text, letterSpacing: -0.3 },
  headerStats: { flexDirection: 'row', gap: S.lg },
  toastLayer: { position: 'absolute', top: 8, left: S.lg, right: S.lg, gap: S.sm, zIndex: 50 },
  overlay: { flex: 1, backgroundColor: 'rgba(4,6,10,0.86)', justifyContent: 'center', padding: S.xl },
  modal: { padding: S.xl, maxHeight: '92%' },
  divider: { height: 1, backgroundColor: C.border, marginVertical: S.lg },
  introRow: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: S.md },
  rowLine: { flexDirection: 'row', alignItems: 'center', paddingVertical: 5 },
  warnBox: {
    marginTop: S.sm,
    padding: S.md,
    borderRadius: R.sm,
    backgroundColor: 'rgba(255,197,61,0.09)',
    borderWidth: 1,
    borderColor: C.yellowDim,
  },
});
