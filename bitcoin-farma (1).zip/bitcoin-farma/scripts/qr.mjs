#!/usr/bin/env node
/**
 * Generátor QR kódu na spustenie Bitcoin Farmy v telefóne.
 *
 *   npm run qr                        # zistí LAN IP, port 8081
 *   npm run qr -- --ip 192.168.1.42   # vlastná IP
 *   npm run qr -- --port 19000        # vlastný port
 *   npm run qr -- --url exp://...     # celá vlastná URL
 *   npm run qr -- --web               # aj QR na webovú verziu (http://IP:PORT)
 *   npm run qr -- --size 640          # veľkosť PNG v px
 *
 * Výstupy (adresár qr/):
 *   expo-qr.svg   vektorový QR — škálovateľný, ideálny na tlač
 *   expo-qr.png   rastrový QR — do prezentácie / na druhý displej
 *   expo-qr.html  samostatná stránka s QR a návodom (funguje offline)
 *
 * QR sa vypíše aj priamo do terminálu, takže ho môžeš nascanovať hneď.
 */

import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

/* ----------------------------- argumenty ----------------------------- */

const argv = process.argv.slice(2);
const arg = (name, fallback) => {
  const eq = argv.find((a) => a.startsWith(`--${name}=`));
  if (eq) return eq.slice(name.length + 3);
  const i = argv.indexOf(`--${name}`);
  if (i !== -1 && argv[i + 1] && !argv[i + 1].startsWith('--')) return argv[i + 1];
  return fallback;
};
const flag = (name) => argv.includes(`--${name}`);

const PORT = arg('port', process.env.EXPO_PORT || '8081');
const SIZE = Number(arg('size', 640));
const OUT = arg('out', path.join(ROOT, 'qr'));
const WANT_WEB = flag('web');
const PLACEHOLDER = '192.168.1.100';

/* ------------------------- zistenie LAN adresy ------------------------ */

function detectLanIp() {
  const ifaces = os.networkInterfaces();
  const candidates = [];
  for (const [name, list] of Object.entries(ifaces)) {
    for (const ni of list || []) {
      if (ni.family !== 'IPv4' || ni.internal) continue;
      candidates.push({ name, address: ni.address });
    }
  }
  // uprednostni bežné privátne rozsahy (WiFi / ethernet), nie docker/vpn/link-local
  const rank = (a) => {
    if (/^(192\.168\.|10\.)/.test(a.address)) return 0;
    if (/^172\.(1[6-9]|2\d|3[01])\./.test(a.address)) return 1;
    if (/^(169\.254\.|127\.)/.test(a.address)) return 9;
    if (/^(docker|br-|veth|virbr|tun|tap|utun)/i.test(a.name)) return 8;
    return 5;
  };
  candidates.sort((x, y) => rank(x) - rank(y));
  const best = candidates[0];
  return best && rank(best) < 5 ? best : null;
}

const detected = detectLanIp();
const IP = arg('ip', detected ? detected.address : PLACEHOLDER);
const isPlaceholder = !detected && !arg('ip');

const expoUrl = arg('url', `exp://${IP}:${PORT}`);
const webUrl = `http://${IP}:${PORT}`;

/* ------------------------------ QR kód ------------------------------- */

let QRCode;
try {
  QRCode = require('qrcode');
} catch {
  console.error(`\n❌ Chýba balíček "qrcode". Spusti:\n\n    npm install\n\n`);
  process.exit(1);
}

const QR_OPTS = {
  errorCorrectionLevel: 'M',
  margin: 2,
  color: { dark: '#0B0E14ff', light: '#FFFFFFFF' },
};

fs.mkdirSync(OUT, { recursive: true });

const svg = await QRCode.toString(expoUrl, { ...QR_OPTS, type: 'svg' });
const png = await QRCode.toBuffer(expoUrl, {
  ...QR_OPTS,
  type: 'png',
  width: SIZE,
  rendererOpts: { quality: 1 },
});
const terminal = await QRCode.toString(expoUrl, { type: 'terminal', small: true });

fs.writeFileSync(path.join(OUT, 'expo-qr.svg'), svg, 'utf8');
fs.writeFileSync(path.join(OUT, 'expo-qr.png'), png);

let webSvg = '';
if (WANT_WEB) {
  webSvg = await QRCode.toString(webUrl, { ...QR_OPTS, type: 'svg' });
  fs.writeFileSync(path.join(OUT, 'web-qr.svg'), webSvg, 'utf8');
  fs.writeFileSync(
    path.join(OUT, 'web-qr.png'),
    await QRCode.toBuffer(webUrl, { ...QR_OPTS, type: 'png', width: SIZE, rendererOpts: { quality: 1 } })
  );
}

/* --------------------------- HTML stránka ---------------------------- */

const html = `<!DOCTYPE html>
<html lang="sk"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Bitcoin Farma — QR na spustenie</title>
<style>
  :root{--bg:#0B0E14;--card:#161B27;--border:#252D3F;--text:#E8ECF4;--dim:#98A2B8;--acc:#F7931A;--red:#FF5C5C}
  *{box-sizing:border-box}
  body{margin:0;background:var(--bg);color:var(--text);min-height:100vh;display:flex;align-items:center;
    justify-content:center;padding:24px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
  .card{background:var(--card);border:1px solid var(--border);border-radius:20px;padding:32px;max-width:520px;width:100%}
  h1{font-size:22px;margin:0 0 4px;letter-spacing:-.4px}
  .sub{color:var(--acc);font-size:12px;font-weight:700;letter-spacing:.8px;text-transform:uppercase}
  .qr{background:#fff;border-radius:14px;padding:14px;margin:22px 0;display:flex;justify-content:center}
  .qr svg{width:100%;max-width:300px;height:auto;display:block}
  code{background:#0B0E14;border:1px solid var(--border);border-radius:7px;padding:2px 7px;
    font-size:13px;color:var(--acc);word-break:break-all}
  .url{display:block;margin-top:10px;font-size:14px;text-align:center}
  ol{color:var(--dim);font-size:13.5px;line-height:1.85;padding-left:20px;margin:16px 0 0}
  ol b{color:var(--text)}
  .warn{border:1px solid #6E2222;background:rgba(255,92,92,.08);border-radius:11px;
    padding:12px 14px;margin-top:20px;font-size:12.5px;line-height:1.65;color:#ffd9d9}
  .meta{margin-top:18px;font-size:11.5px;color:var(--dim);border-top:1px solid var(--border);padding-top:14px}
</style></head><body>
<div class="card">
  <div class="sub">₿ Bitcoin Farma</div>
  <h1>Nascanuj a hraj</h1>
  <div class="qr">${svg}</div>
  <code class="url">${expoUrl}</code>
  ${WANT_WEB ? `<div class="qr">${webSvg}</div><code class="url">${webUrl} <span style="color:var(--dim)">(web verzia)</span></code>` : ''}
  <ol>
    <li>Na počítači spusti <b><code>npx expo start</code></b> v adresári <code>bitcoin-farma</code>.</li>
    <li>Telefón a počítač musia byť na <b>rovnakej WiFi</b>.</li>
    <li>Nascanuj QR — <b>Android</b>: aplikáciou Fotoaparát alebo Expo Go. <b>iOS</b>: aplikáciou Fotoaparát.</li>
    <li>Ak QR nefunguje, opíš URL vyššie alebo použi <code>npx expo start --tunnel</code>.</li>
  </ol>
  <div class="warn">
    <b>Expo Go pre SDK 56/57 zatiaľ nie je v App Store ani Google Play</b> (čaká na schválenie).
    Na Androide stiahni staršie Expo Go z <b>expo.dev/go</b>, na iOS použi <b>eas go</b>,
    alebo si vygeneruj development build: <code>npm install expo-dev-client</code> a potom
    <code>npx expo run:android</code>.
  </div>
  <div class="meta">
    IP: <code>${IP}</code>${isPlaceholder ? ' — <b style="color:var(--red)">placeholder!</b> Dosaď svoju LAN IP cez <code>npm run qr -- --ip Tvoja.IP.Adresa</code>' : ` (zistené automaticky z rozhrania ${detected.name})`}
    · port <code>${PORT}</code> · vygenerované ${new Date().toLocaleString('sk-SK')}
  </div>
</div></body></html>`;

fs.writeFileSync(path.join(OUT, 'expo-qr.html'), html, 'utf8');

/* ------------------------------- výstup ------------------------------ */

console.log(terminal);
console.log(`  ₿ Bitcoin Farma — QR na spustenie v telefóne\n`);
console.log(`  URL        ${expoUrl}`);
if (WANT_WEB) console.log(`  Web URL    ${webUrl}`);
console.log(`  IP adresa  ${IP}${isPlaceholder ? '   ⚠️  PLACEHOLDER — nenašla sa LAN IP' : `  (${detected.name})`}`);
console.log(`  Port       ${PORT}`);
console.log(`\n  Uložené do ${path.relative(process.cwd(), OUT)}/`);
console.log(`    expo-qr.svg    vektorový (na tlač)`);
console.log(`    expo-qr.png    ${SIZE}×${SIZE} px`);
console.log(`    expo-qr.html   stránka s QR a návodom`);
if (WANT_WEB) console.log(`    web-qr.svg/.png`);

if (isPlaceholder) {
  console.log(`\n  ⚠️  Vygeneroval som QR s placeholder IP. Pre svoju sieť spusti:\n`);
  console.log(`      npm run qr -- --ip TVOJA_LAN_IP\n`);
  console.log(`  Svoju IP zistíš cez "ipconfig getifaddr en0" (macOS) alebo "ipconfig" (Windows).`);
}

console.log(`\n  ℹ️  Expo CLI vypisuje vlastné QR priamo pri "npx expo start" — tento skript`);
console.log(`     je užitočný, keď chceš QR ako obrázok (druhý displej, tlač, prezentácia).\n`);
