/**
 * Balance skript — simuluje „rozumného hráča“ a vypíše metriky.
 * Spusti: node scripts/balance.mjs
 */
import {
  createState, advanceGameTime, derive, buyRig, buyUpgrade, sellBtc, sellRig,
  repairRigs, repairCost,
} from '../src/game/engine.js';
import { HARDWARE } from '../src/data/hardware.js';
import { UPGRADES } from '../src/data/upgrades.js';
import { GAME } from '../src/game/constants.js';
import { formatHash, formatEur, formatPower } from '../src/game/format.js';

const DAY = 86400;

/** Klon stavu s rovnakým prostredím, ale bez RNG závislosti. */
function probeState(s) {
  const t = createState({ seed: 2026 });
  t.eur = 1e9;
  t.difficulty = s.difficulty;
  t.difficultyTrend = s.difficulty;
  t.difficultyShock = 1;
  t.price = s.price;
  t.priceBase = s.price;
  t.priceShock = 1;
  t.height = s.height;
  t.temp = s.temp;
  t.settings.elecPrice = s.settings.elecPrice;
  t.upgrades = { ...s.upgrades };
  t.rigs = {};
  for (const [id, r] of Object.entries(s.rigs)) {
    t.rigs[id] = { count: r.count || 0, on: true, mode: r.mode || 'normal', broken: 0 };
  }
  return t;
}

/**
 * MARGINÁLNY prínos jedného kusu stroja pri aktuálnom stave farmy.
 * (Rozdiel v dennom čistom zisku pred a po pridaní stroja.)
 */
function marginal(s, hwId) {
  const t = probeState(s);
  const before = derive(t);
  buyRig(t, hwId, 1);
  const after = derive(t);
  return {
    net: after.netEurPerDay - before.netEurPerDay,
    hash: after.hashrate - before.hashrate,
    heat: after.heatKw - before.heatKw,
  };
}

/* ------------------------------------------------------------------ */

console.log('=== Ekonomika strojov NA ŠTARTE (prázdna farma, 0,08 €/kWh, 35 kW chladenie) ===');
console.log(
  'stroj'.padEnd(26), 'cena'.padStart(10), 'hashrate'.padStart(11),
  'príjem/d'.padStart(11), 'elektr/d'.padStart(11), 'čistý/d'.padStart(11),
  'návratnosť'.padStart(12), 'teplo'.padStart(9)
);
const empty = createState({ seed: 2026 });
for (const hw of HARDWARE) {
  const t = probeState(empty);
  buyRig(t, hw.id, 1);
  const c = derive(t);
  console.log(
    hw.name.padEnd(26),
    formatEur(hw.price, 0).padStart(10),
    formatHash(hw.hash).padStart(11),
    formatEur(c.grossEurPerDay, 2).padStart(11),
    formatEur(c.elecEurPerDay, 2).padStart(11),
    formatEur(c.netEurPerDay, 2).padStart(11),
    (c.netEurPerDay > 0 ? `${(hw.price / c.netEurPerDay).toFixed(0)} dní` : '—').padStart(12),
    `${hw.heat.toFixed(2)} kW`.padStart(9)
  );
}

/* ------------------------------------------------------------------ */

console.log('\n=== Hra „rozumného hráča“ ===');
console.log(
  `1 herný rok = ${(365 * DAY / (GAME.BASE_TIME_SCALE * 4) / 60).toFixed(1)} min reálneho času pri 4×, ` +
  `${(365 * DAY / (GAME.BASE_TIME_SCALE * 16) / 60).toFixed(1)} min pri 16×\n`
);

const s = createState({ seed: 2026 });
// bot predáva polovicu úlovku hneď (ako reálny miner, ktorý platí elektrinu z ťažby)
s.settings.autoSellPct = 100; // rastový bot: všetko ihneď predáva a reinvestuje
let day = 0;
let plan = [];
const snapshots = [];
const YEARS = 8;

while (day < YEARS * 365) {
  advanceGameTime(s, DAY);
  day++;

  // 1) opravy
  for (const id of Object.keys(s.rigs)) {
    const cost = repairCost(s, id);
    if (cost > 0 && s.eur > cost) repairRigs(s, id);
  }

  // 2) záchrana pri dlhu — treasury už predala BTC; ak to nestačilo, predaj stroje
  if (s.autoShutdown || s.eur < -1000) {
    let guard = 0;
    while (s.eur < 200 && guard++ < 4) {   // nepredávame v panike všetko
      const owned = HARDWARE.filter((h) => s.rigs[h.id]?.count > 0);
      if (!owned.length) break;
      const worst = owned.sort((a, b) => marginal(s, a.id).net - marginal(s, b.id).net)[0];
      sellRig(s, worst.id, 1);
    }
  }

  // 3) vylepšenia — chladenie má absolútnu prednosť, ak sa farma prehrieva
  const c0 = derive(s);
  if (c0.load > 0.6 || s.thermalState !== "ok" || c0.brokenCount > 0) {
    for (const u of UPGRADES) {
      if (u.coolingKw && !s.upgrades[u.id] && s.eur > u.price * 1.05) { buyUpgrade(s, u.id); break; }
    }
  }
  for (const u of UPGRADES) {
    if (!s.upgrades[u.id] && s.eur > u.price * 4 && buyUpgrade(s, u.id).ok) break;
  }

  // 4) stroje — prepočet marginálnej návratnosti každých 10 dní (je to drahé)
  if (day % 3 === 1) {
    plan = HARDWARE
      .map((hw) => ({ hw, m: marginal(s, hw.id) }))
      .filter((x) => x.m.net > 0)
      .map((x) => ({ hw: x.hw, days: x.hw.price / x.m.net }))
      .sort((a, b) => a.days - b.days)
      .map((x) => x.hw);
  }
  // Nekupuj stroje, ktoré by prehriali farmu — najprv musí prísť chladenie.
  let heatNow = derive(s).heatKw;
  const coolKw = derive(s).coolingKw;
  for (let i = 0; i < 20 && plan.length; i++) {
    const reserve = 0.75; // reinvestuj, ale nechaj prevádzkovú rezervu
    const best = plan.find((hw) => hw.price <= s.eur * reserve);
    if (!best) break;
    if (heatNow + best.heat > coolKw * 0.7) {
      for (const u of UPGRADES) {
        if (u.coolingKw && !s.upgrades[u.id] && s.eur > u.price * 1.05) { buyUpgrade(s, u.id); break; }
      }
      break;
    }
    const qty = Math.max(1, Math.min(10, Math.floor((s.eur * 0.85) / best.price)));
    if (!buyRig(s, best.id, qty).ok) break;
    heatNow += best.heat * qty;
  }

  if (day % 180 === 0) snapshots.push({ day, c: derive(s), price: s.price, halv: s.stats.halvingsSeen, upg: Object.keys(s.upgrades).length });
}

console.log(
  'deň'.padStart(6), 'rok'.padStart(6), 'hashrate'.padStart(12), 'stroje'.padStart(7),
  'tepl.'.padStart(7), 'eff'.padStart(6), 'čistý/deň'.padStart(13),
  'cena BTC'.padStart(12), 'majetok'.padStart(15), 'halv.'.padStart(6)
);
for (const sn of snapshots) {
  const c = sn.c;
  console.log(
    String(sn.day).padStart(6),
    (sn.day / 365).toFixed(1).padStart(6),
    formatHash(c.hashrate).padStart(12),
    `${c.rigCount}/${c.brokenCount}`.padStart(7),
    `${c.temp.toFixed(0)}°C`.padStart(7),
    `${(c.efficiency * 100).toFixed(0)}%`.padStart(6),
    formatEur(c.netEurPerDay, 0).padStart(13),
    formatEur(sn.price, 0).padStart(12),
    formatEur(c.netWorth, 0).padStart(15),
    String(sn.halv).padStart(6)
  );
}

const fin = derive(s);
console.log('\n--- Zhrnutie po ' + YEARS + ' herných rokoch ---');
console.log('Vyťažené BTC       :', s.stats.btcMined.toFixed(6));
console.log('Predané BTC        :', s.stats.btcSold.toFixed(6));
console.log('Zaplatená elektrina:', formatEur(s.stats.eurSpentElectricity, 0));
console.log('Investície do HW   :', formatEur(s.stats.eurSpentRigs, 0));
console.log('Investície do upg. :', formatEur(s.stats.eurSpentUpgrades, 0));
console.log('Opravy             :', formatEur(s.stats.eurSpentRepairs, 0));
console.log('Poruchy            :', s.stats.breakdowns);
console.log('Halvingy           :', s.stats.halvingsSeen);
console.log('Konečný majetok    :', formatEur(fin.netWorth, 0), `(hotovosť ${formatEur(s.eur, 0)}, BTC ${s.btc.toFixed(4)})`);
console.log('Hashrate           :', formatHash(fin.hashrate), `· podiel siete ${(fin.share * 100).toExponential(2)} %`);
console.log('Spotreba           :', formatPower(fin.watts), `· chladenie ${fin.coolingKw.toFixed(0)} kW · záťaž ${(fin.load * 100).toFixed(0)} %`);
console.log('Difficulty         :', (s.difficulty / 1e12).toFixed(1), 'T  (trend',
  (s.difficultyTrend / 1e12).toFixed(1), 'T, šok', s.difficultyShock.toFixed(2) + ')');
console.log('Block height       :', Math.floor(s.height).toLocaleString('sk-SK'));
console.log('Cena BTC           :', formatEur(s.price, 0), '· min/max v hre:',
  formatEur(Math.min(...s.priceHistory), 0), '/', formatEur(Math.max(...s.priceHistory), 0));
console.log('Vylepšenia         :', Object.keys(s.upgrades).length, '/', UPGRADES.length);
console.log('Stroje             :', Object.entries(s.rigs)
  .map(([id, r]) => `${id}×${r.count}`).join(', ') || 'žiadne');
