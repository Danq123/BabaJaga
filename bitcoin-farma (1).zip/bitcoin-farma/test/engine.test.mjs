import test from 'node:test';
import assert from 'node:assert/strict';

import {
  sellRig,
  repairCost,
  createState,
  advance,
  advanceGameTime,
  derive,
  blockRewardAt,
  networkHashrate,
  buyRig,
  buyUpgrade,
  sellBtc,
  repairRigs,
  applyOfflineProgress,
  checkAchievements,
  cycleFactor,
  fairPrice,
} from '../src/game/engine.js';
import { HARDWARE, HW_BY_ID, jPerTh } from '../src/data/hardware.js';
import { UPGRADES } from '../src/data/upgrades.js';
import { GAME } from '../src/game/constants.js';

test('blockRewardAt kopíruje reálny Bitcoin', () => {
  assert.equal(blockRewardAt(0), 50);
  assert.equal(blockRewardAt(209_999), 50);
  assert.equal(blockRewardAt(210_000), 25);
  assert.equal(blockRewardAt(420_000), 12.5);
  assert.equal(blockRewardAt(630_000), 6.25);
  assert.equal(blockRewardAt(840_000), 3.125);
  assert.equal(blockRewardAt(1_050_000), 1.5625);
  assert.equal(blockRewardAt(1_260_000), 0.78125);
  assert.equal(blockRewardAt(210_000 * 64), 0);
});

test('networkHashrate sedí so vzťahom difficulty × 2^32 / 600', () => {
  // reálne: difficulty ~130 T => ~930 EH/s
  const h = networkHashrate(1.3e14);
  assert.ok(h > 9e20 && h < 1e21, `očakávali sme ~9.3e20, dostali ${h}`);
});

test('nová hra je v konzistentnom stave', () => {
  const s = createState({ seed: 42 });
  const c = derive(s);
  assert.equal(c.rigCount, 0);
  assert.equal(c.hashrate, 0);
  assert.equal(c.netEurPerDay, 0);
  assert.equal(s.eur, GAME.START_EUR);
  assert.ok(c.netHashrate > 0);
  assert.ok(c.share === 0);
  assert.ok(c.daysToHalving > 0 && c.daysToHalving < 400);
});

test('VoltCore T19 má na štarte kladnú maržu', () => {
  const s = createState({ seed: 42 });
  const r = buyRig(s, 't19', 1);
  assert.ok(r.ok, r.reason);
  const c = derive(s);
  assert.ok(c.hashrate > 0);
  assert.ok(c.watts > 0);
  assert.ok(c.grossEurPerDay > 5, `gross/deň = ${c.grossEurPerDay}`);
  assert.ok(c.netEurPerDay > 0, `net/deň = ${c.netEurPerDay} (malo by byť kladné)`);
  assert.ok(c.paybackDays < 400, `návratnosť ${c.paybackDays} herných dní`);
});

test('ťažba reálne pripisuje BTC a odpočítava elektrinu', () => {
  const s = createState({ seed: 7 });
  buyRig(s, 't19', 2);
  const c0 = derive(s);
  advanceGameTime(s, 86400); // 1 herný deň
  assert.ok(s.btc > 0, 'mal by vyťažiť nejaké BTC');
  assert.ok(s.stats.eurSpentElectricity > 0, 'mal by zaplatiť elektrinu');
  const dailyBtc = s.btc;
  // hrubý príjem bez poplatku a bez luck by mal byť +- blízko
  const expected = c0.btcPerSec * 86400 / (1 - c0.poolFee) * (1 - c0.poolFee);
  assert.ok(dailyBtc > expected * 0.5 && dailyBtc < expected * 1.6,
    `vyťažené ${dailyBtc} vs očakávané ${expected}`);
});

test('halving zníži odmenu a zvýši počítadlo', () => {
  const s = createState({ seed: 3 });
  buyRig(s, 't19', 3);
  const before = blockRewardAt(s.height);
  advanceGameTime(s, 31_000 * GAME.BLOCK_TIME); // prejde halving na 1 050 000
  assert.ok(s.height >= 1_050_000, `height ${s.height}`);
  assert.ok(s.stats.halvingsSeen >= 1);
  assert.equal(blockRewardAt(s.height), before / 2);
});

test('difficulty rastie v čase', () => {
  const s = createState({ seed: 5 });
  const d0 = s.difficulty;
  advanceGameTime(s, 20 * 86400);
  assert.ok(s.difficulty !== d0, 'difficulty sa mala upraviť');
});

test('prehriatie znižuje efektivitu', () => {
  const s = createState({ seed: 11 });
  s.eur = 1e6;
  buyRig(s, 'z1', 20); // veľa tepla, malé chladenie
  advanceGameTime(s, 3 * 86400);
  const c = derive(s);
  assert.ok(s.temp > GAME.AMBIENT_C + 10, `teplota ${s.temp}`);
  assert.ok(c.efficiency < 1, `efektivita ${c.efficiency}`);
});

test('chladenie vyrieši prehrievanie', () => {
  const s = createState({ seed: 11 });
  s.eur = 1e6;
  buyUpgrade(s, 'fans');
  buyUpgrade(s, 'immersion');
  s.eur += 100000;
  buyRig(s, 'z1', 20);
  advanceGameTime(s, 3 * 86400);
  const c = derive(s);
  assert.ok(c.efficiency > 0.95, `efektivita s chladením ${c.efficiency}`);
});

test('upgrade s requires sa nedá kúpiť bez prerequisite', () => {
  const s = createState({ seed: 1 });
  s.eur = 1e9;
  const bad = buyUpgrade(s, 'hosting'); // vyžaduje solar
  assert.equal(bad.ok, false);
  assert.ok(/solar|Solárna/i.test(bad.reason || ''));
  assert.ok(buyUpgrade(s, 'solar').ok);
  assert.ok(buyUpgrade(s, 'hosting').ok);
  assert.equal(s.settings.elecPrice, 0.035);
});

test('predaj BTC pripíše euro', () => {
  const s = createState({ seed: 2 });
  s.btc = 0.5;
  const before = s.eur;
  const r = sellBtc(s, 0.5);
  assert.ok(r.ok);
  assert.ok(s.eur > before);
  assert.equal(s.btc, 0);
  assert.ok(s.stats.eurFromSales > 0);
});

test('poruchy sa dajú opraviť', () => {
  const s = createState({ seed: 13 });
  s.eur = 1e6;
  buyRig(s, 's9', 50); // vysoká poruchovosť
  advanceGameTime(s, 60 * 86400);
  const broken = derive(s).brokenCount;
  if (broken > 0) {
    assert.ok(repairRigs(s, 's9').ok);
    assert.equal(derive(s).brokenCount, 0);
  } else {
    assert.ok(true, 'žiadna porucha — v poriadku');
  }
});

test('offline progres je obmedzený a funguje', () => {
  const s = createState({ seed: 9 });
  buyRig(s, 't19', 2);
  s.savedAt = Date.now() - 1000 * 60 * 60 * 24 * 30; // 30 reálnych dní
  const res = applyOfflineProgress(s, Date.now());
  assert.ok(res.capped, 'mal by naraziť na limit');
  assert.ok(res.offlineGameSeconds <= GAME.MAX_OFFLINE_GAME_SECONDS + 1);
  assert.ok(s.btc > 0);
});

test('udalosti sa spúšťajú a majú efekt', () => {
  const s = createState({ seed: 17 });
  s.eur = 1e6;
  buyRig(s, 't19', 5);
  advanceGameTime(s, 120 * 86400);
  assert.ok(s.log.length > 5, `log má ${s.log.length} záznamov`);
  assert.ok(s.stats.gameDays >= 119);
});

test('achievements sa odomykajú', () => {
  const s = createState({ seed: 21 });
  s.eur = 1e7;
  buyRig(s, 't19', 12);
  const unlocked = checkAchievements(s);
  const ids = unlocked.map((a) => a.id);
  assert.ok(ids.includes('first-rig'));
  assert.ok(ids.includes('ten-rigs'));
  // druhýkrát už nič nové
  assert.deepEqual(checkAchievements(s), []);
});

test('cena BTC ostáva v rozumných medziach a cyklí', () => {
  const s = createState({ seed: 23 });
  const seen = new Set();
  for (let i = 0; i < 400; i++) {
    advanceGameTime(s, 86400);
    seen.add(Math.round(s.price / 1000));
    assert.ok(s.price > 1000 && s.price < 5_000_000, `cena ${s.price}`);
  }
  assert.ok(seen.size > 20, 'cena by sa mala hýbať');
  assert.ok(cycleFactor(GAME.START_HEIGHT) > 0.2 && cycleFactor(GAME.START_HEIGHT) < 1.8);
});

test('engine je deterministický pri rovnakom seede', () => {
  const run = () => {
    const s = createState({ seed: 1234 });
    s.eur = 1e6;
    buyRig(s, 'x19', 10);
    advanceGameTime(s, 30 * 86400);
    return [s.btc, s.eur, s.price, s.difficulty, s.temp, s.height];
  };
  assert.deepEqual(run(), run());
});

test('stav je JSON-serializovateľný', () => {
  const s = createState({ seed: 1 });
  s.eur = 1e6;
  buyRig(s, 't19', 3);
  advanceGameTime(s, 5 * 86400);
  const clone = JSON.parse(JSON.stringify(s));
  const a = derive(s);
  const b = derive(clone);
  assert.equal(a.hashrate, b.hashrate);
  assert.equal(a.netWorth, b.netWorth);
});

test('dlhá hra nerobí NaN', () => {
  const s = createState({ seed: 99 });
  s.eur = 5e7;
  for (const hw of HARDWARE) buyRig(s, hw.id, 5);
  for (const u of UPGRADES) {
    s.eur = Math.max(s.eur, u.price + 1);
    buyUpgrade(s, u.id);
  }
  advanceGameTime(s, 4 * 365 * 86400);
  for (const key of ['btc', 'eur', 'price', 'temp', 'difficulty', 'height']) {
    assert.ok(isFinite(s[key]), `${key} = ${s[key]}`);
  }
  const c = derive(s);
  for (const key of ['hashrate', 'watts', 'netEurPerDay', 'netWorth', 'efficiency']) {
    assert.ok(isFinite(c[key]), `${key} = ${c[key]}`);
  }
});

test('J/TH je konzistentné so specifikáciou', () => {
  const t19 = HW_BY_ID.t19;
  assert.ok(Math.abs(jPerTh(t19) - 37.5) < 0.5, `t19 J/TH = ${jPerTh(t19)}`);
  // každý drahší tier by mal byť efektívnejší
  const sorted = [...HARDWARE].sort((a, b) => a.tier - b.tier);
  for (let i = 1; i < sorted.length; i++) {
    assert.ok(jPerTh(sorted[i]) <= jPerTh(sorted[i - 1]),
      `${sorted[i].id} by mal mať lepšie J/TH než ${sorted[i - 1].id}`);
  }
});

test('účtovníctvo sedí: hotovosť = príjmy − výdavky', () => {
  const s = createState({ seed: 555 });
  s.settings.autoSellPct = 100;
  s.eur = 50000;
  const start = s.eur;
  let rigSales = 0;
  // náhodná sekvencia akcií
  for (let i = 0; i < 400; i++) {
    advanceGameTime(s, 3600 * 6);
    if (i % 7 === 0) buyRig(s, 't19', 1);
    if (i % 23 === 0) buyRig(s, 's9', 2);
    if (i % 31 === 0) buyUpgrade(s, 'fans');
    if (i % 41 === 0) { const r = sellRig(s, 's9', 1); if (r.ok) rigSales += r.income; }
    if (i % 53 === 0) { const c = repairCost(s, 't19'); if (c > 0 && s.eur > c) repairRigs(s, 't19'); }
    if (i % 97 === 0 && s.btc > 0) sellBtc(s, s.btc * 0.3);
  }
  const st = s.stats;
  const expected = start + st.eurFromSales + rigSales
    - st.eurSpentRigs - st.eurSpentUpgrades - st.eurSpentElectricity - st.eurSpentRepairs;
  const diff = Math.abs(expected - s.eur);
  assert.ok(diff < 0.01,
    `nesedí o ${diff.toFixed(4)} €\n  očakávané ${expected.toFixed(2)}\n  skutočné  ${s.eur.toFixed(2)}`);
});

test('auto-predaj pripisuje EUR a neuberá z vyťaženého množstva', () => {
  const a = createState({ seed: 8 }); buyRig(a, 't19', 3); a.settings.autoSellPct = 0;
  const b = createState({ seed: 8 }); buyRig(b, 't19', 3); b.settings.autoSellPct = 100;
  advanceGameTime(a, 10 * 86400);
  advanceGameTime(b, 10 * 86400);
  assert.ok(Math.abs(a.stats.btcMined - b.stats.btcMined) < 1e-12, 'vyťažené množstvo musí byť rovnaké');
  assert.ok(b.btc < 1e-12, 'pri 100 % auto-predaji by nemal ostať žiadny BTC');
  assert.ok(b.eur > a.eur, 'auto-predaj musí zvýšiť hotovosť');
  assert.ok(a.btc > 0, 'pri 0 % auto-predaji musí BTC ostať');
});

test('treasury predá BTC, keď nie je na elektrinu', () => {
  const s = createState({ seed: 12 });
  buyRig(s, 't19', 2);
  s.eur = 5;
  s.btc = 0.05; // ~4 000 €
  s.settings.autoSellPct = 0;
  s.settings.autoTreasury = true;
  advanceGameTime(s, 30 * 86400);
  assert.ok(s.eur >= -1, `eur by nemalo byť hlboko v mínuse, je ${s.eur}`);
  assert.ok(s.stats.btcSold > 0, 'treasury mala predať BTC');
  assert.equal(s.autoShutdown, false, 'nemalo by dôjsť k odstaveniu');
});

test('dlh nad limit odpojí farmu a pri likvidite sa sama naštartuje', () => {
  const s = createState({ seed: 14 });
  buyRig(s, 't19', 2);
  s.btc = 0;
  s.eur = -10000; // dlh nad DEBT_LIMIT
  s.settings.autoTreasury = false;
  advanceGameTime(s, 3600);
  assert.equal(s.autoShutdown, true, 'malo by dôjsť k odstaveniu');
  assert.equal(derive(s).hashrate, 0);
  s.eur = 5000; // splatí dlh
  advanceGameTime(s, 3600);
  assert.equal(s.autoShutdown, false, 'farma by sa mala sama naštartovať');
  assert.ok(derive(s).hashrate > 0);
});

test('tepelný regulátor plynule zníži výkon a ustáli sa (nekmitá)', () => {
  const s = createState({ seed: 16 });
  s.eur = 1e7;
  buyRig(s, 'z1', 30); // 117 kW tepla na 35 kW chladenia
  advanceGameTime(s, 5 * 86400);
  const c = derive(s);
  assert.ok(c.curtail < 0.9, `regulátor mal znížiť výkon, curtail = ${c.curtail}`);
  assert.ok(c.hashrate < c.nominalHashrate, 'hashrate má byť pod nominálnym');
  assert.ok(s.temp > GAME.TEMP_WARN_C && s.temp <= GAME.TEMP_CRITICAL_C + 1,
    `teplota má ostať v pásme regulácie, je ${s.temp}`);
  // ustálený stav: ďalších 20 dní bez rozkmitania
  const samples = [];
  for (let i = 0; i < 20; i++) {
    advanceGameTime(s, 86400);
    samples.push(s.temp);
  }
  const spread = Math.max(...samples) - Math.min(...samples);
  assert.ok(spread < 6, `teplota má byť stabilná, rozptyl ${spread.toFixed(2)} °C`);
  // bez nekonečného spamu v logu
  assert.ok(s.log.length <= GAME.LOG_LIMIT);
});

test('chladenie vráti farmu na plný výkon', () => {
  const s = createState({ seed: 16 });
  s.eur = 1e7;
  buyRig(s, 'z1', 30);
  buyUpgrade(s, 'fans');
  buyUpgrade(s, 'immersion');
  buyUpgrade(s, 'transformer');
  advanceGameTime(s, 5 * 86400);
  const c = derive(s);
  assert.ok(c.curtail > 0.98, `s chladením má byť plný výkon, curtail = ${c.curtail}`);
  assert.ok(s.temp < GAME.TEMP_WARN_C, `teplota ${s.temp}`);
});
