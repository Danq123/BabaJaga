import { registerRootComponent } from 'expo';

import App from './App';

// registerRootComponent volá AppRegistry.registerComponent za nás.
// Funguje to v Expo Go aj v development builde.
registerRootComponent(App);
