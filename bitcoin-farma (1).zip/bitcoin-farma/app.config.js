/**
 * Dynamická Expo konfigurácia — JEDINÝ zdroj pravdy pre identitu projektu.
 *
 * Nahrádza pôvodný app.json. Hodnoty zodpovedajú identite, ktorú si zadal:
 *   { "name": "My app", "slug": "my-app" }
 *
 * Dajú sa prepísať premennými prostredia (užitočné pre varianty buildov):
 *   APP_NAME, APP_SLUG, APP_VERSION, APP_BUNDLE_ID, EAS_PROJECT_ID
 *
 * Spusti `npx expo config --type public`, ak chceš vidieť výslednú konfiguráciu.
 */

const fs = require('fs');
const path = require('path');

const has = (rel) => fs.existsSync(path.join(__dirname, rel));

/* ------------------------- identita projektu ------------------------- */

const NAME = process.env.APP_NAME || 'My app';
const SLUG = process.env.APP_SLUG || 'my-app';
const VERSION = process.env.APP_VERSION || '1.0.0';

// identifikátory balíkov odvodené zo slug-u (validné pre iOS aj Android)
const idPart = SLUG.replace(/[^a-z0-9]+/gi, '').toLowerCase() || 'myapp';
const BUNDLE_ID = process.env.APP_BUNDLE_ID || `com.${idPart}.mobile`;

// scheme pre deep-linky (malé písmená, bez pomlčiek)
const SCHEME = process.env.APP_SCHEME || idPart;

/* ------------------------------ extra -------------------------------- */

const extra = {};
if (process.env.EAS_PROJECT_ID) {
  extra.eas = { projectId: process.env.EAS_PROJECT_ID };
}

module.exports = () => ({
  name: NAME,
  slug: SLUG,
  version: VERSION,
  scheme: SCHEME,

  orientation: 'portrait',
  userInterfaceStyle: 'dark',
  newArchEnabled: true,
  backgroundColor: '#0B0E14',

  // ikony len ak reálne existujú, inak ich Expo nerieši
  ...(has('assets/icon.png') ? { icon: './assets/icon.png' } : {}),
  splash: {
    backgroundColor: '#0B0E14',
    resizeMode: 'contain',
    ...(has('assets/splash.png') ? { image: './assets/splash.png' } : {}),
  },

  ios: {
    supportsTablet: true,
    bundleIdentifier: BUNDLE_ID,
  },

  android: {
    package: BUNDLE_ID,
    edgeToEdgeEnabled: true,
    adaptiveIcon: {
      backgroundColor: '#0B0E14',
      ...(has('assets/icon.png') ? { foregroundImage: './assets/icon.png' } : {}),
    },
  },

  web: {
    bundler: 'metro',
  },

  plugins: [],

  ...(Object.keys(extra).length ? { extra } : {}),
});
