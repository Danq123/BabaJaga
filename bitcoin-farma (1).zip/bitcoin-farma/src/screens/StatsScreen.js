import React, { useState } from 'react';
import { View, Text, ScrollView, Alert, StyleSheet } from 'react-native';

import { C, S, F, signColor } from '../theme.js';
import { Card, Section, Button, Row } from '../components/ui.js';
import {
  formatEur, formatBtc, formatHash, formatPower, formatEnergy, formatNumber,
  formatGameTime, formatDifficulty,
} from '../game/format.js';
import { UPGRADES } from '../data/upgrades.js';
import { HARDWARE } from '../data/hardware.js';
import { LESSONS } from '../data/lessons.js';
import { ACHIEVEMENTS } from '../data/achievements.js';
import { GAME } from '../game/constants.js';
import { APP_NAME } from '../appInfo.js';

export default function StatsScreen({ state: s, d, actions }) {
  const [confirming, setConfirming] = useState(false);
  const time = formatGameTime(s.time);
  const st = s.stats;

  const totalRigs = Object.values(s.rigs).reduce((a, r) => a + (r.count || 0), 0);
  const totalWatts = Object.entries(s.rigs).reduce((a, [id, r]) => {
    const hw = HARDWARE.find((h) => h.id === id);
    return a + (hw ? hw.watts * (r.count || 0) : 0);
  }, 0);
  const lifetimeKwh = st.eurSpentElectricity / Math.max(0.0001, s.settings.elecPrice);

  const revenue = st.eurFromSales;
  const costs = st.eurSpentRigs + st.eurSpentUpgrades + st.eurSpentElectricity + st.eurSpentRepairs;
  const pnl = d.netWorth - GAME.START_EUR;

  return (
    <ScrollView style={stl.scroll} contentContainerStyle={stl.content} showsVerticalScrollIndicator={false}>
      <Card accent={C.accent} style={{ marginBottom: S.lg }}>
        <Text style={F.tiny}>ČAS V HRE</Text>
        <Text style={[F.h2, { marginTop: 2 }]}>{time.label}</Text>
        <Text style={[F.tiny, { marginTop: 4 }]}>
          {formatNumber(st.gameDays)} herných dní · {formatNumber(Math.floor(s.height))} blockov ·{' '}
          {st.halvingsSeen}× halving
        </Text>
      </Card>

      <Section title="Výsledok hospodárenia">
        <Card>
          <Row label="Počiatočný vklad" value={formatEur(GAME.START_EUR, 0)} />
          <Row label="Súčasný majetok" value={formatEur(d.netWorth, 0)} valueColor={signColor(d.netWorth)} />
          <Row label="Zisk / strata (PnL)" value={formatEur(pnl, 0)} valueColor={signColor(pnl)} />
          <Row label="Návratnosť vkladu" value={`${((pnl / GAME.START_EUR) * 100).toFixed(1)} %`} valueColor={signColor(pnl)} />
          <View style={stl.divider} />
          <Row label="Realizované tržby (predaj BTC)" value={formatEur(revenue, 0)} valueColor={C.green} />
          <Row label="Náklady celkovo" value={`−${formatEur(costs, 0)}`} valueColor={C.red} />
          <Row label="Nerealizovaný zisk v BTC" value={formatEur(s.btc * s.price, 0)} valueColor={C.accent} />
        </Card>
      </Section>

      <Section title="Ťažba">
        <Card>
          <Row label="Vyťažené celkovo" value={formatBtc(st.btcMined, 8)} valueColor={C.accent} />
          <Row label="v satoshi" value={formatNumber(Math.round(st.btcMined * 1e8))} />
          <Row label="Predané" value={formatBtc(st.btcSold, 8)} hint={formatEur(st.eurFromSales, 0)} />
          <Row label="Kúpené za EUR" value={formatBtc(st.btcBought, 8)} />
          <View style={stl.divider} />
          <Row label="Aktuálny hashrate" value={formatHash(d.hashrate)} />
          <Row label="Podiel na sieti" value={`${(d.share * 100).toExponential(3)} %`} />
          <Row label="Nainštalovaný výkon" value={formatPower(totalWatts)} />
          <Row label="Spotrebovaná elektrina" value={formatEnergy(lifetimeKwh)} />
          <Row label="Zaplatená elektrina" value={formatEur(st.eurSpentElectricity, 0)} valueColor={C.red} />
        </Card>
      </Section>

      <Section title="Farma">
        <Card>
          <Row label="Počet strojov" value={formatNumber(totalRigs)} />
          <Row label="Pokazených" value={formatNumber(d.brokenCount)} valueColor={d.brokenCount ? C.red : C.green} />
          <Row label="Počet porúch celkovo" value={formatNumber(st.breakdowns)} />
          <Row label="Minuté na opravy" value={formatEur(st.eurSpentRepairs, 0)} />
          <Row label="Investície do hardvéru" value={formatEur(st.eurSpentRigs, 0)} />
          <Row label="Investície do vylepšení" value={formatEur(st.eurSpentUpgrades, 0)} />
          <Row label="Vylepšenia" value={`${Object.keys(s.upgrades).length} / ${UPGRADES.length}`} />
          <Row label="Zostatková hodnota strojov" value={formatEur(d.rigValue, 0)} />
        </Card>
      </Section>

      <Section title="Sieť">
        <Card>
          <Row label="Výška blocku" value={formatNumber(Math.floor(s.height))} />
          <Row label="Odmena za block" value={`${d.reward} BTC`} />
          <Row label="Difficulty" value={formatDifficulty(s.difficulty)} />
          <Row label="Hashrate siete" value={formatHash(d.netHashrate)} />
          <Row label="Do halvingu" value={`${formatNumber(Math.ceil(d.blocksToHalving))} blockov`} hint={`${formatNumber(Math.round(d.daysToHalving))} dní`} />
          <Row label="Do úpravy difficulty" value={`${formatNumber(Math.ceil(d.blocksToDiffAdj))} blockov`} />
          <Row label="Seed hry" value={String(s.seed)} />
        </Card>
      </Section>

      <Section title="Progres">
        <Card>
          <Row label="Úspechy" value={`${Object.keys(s.achievements).length} / ${ACHIEVEMENTS.length}`} />
          <Row label="Objavené poznatky" value={`${Object.keys(s.lessonsSeen).length}`} />
          <Row label="Lekcie v Akadémii" value={String(LESSONS.length)} />
          <Row label="Najvyšší majetok" value={formatEur(st.peakNetWorth, 0)} valueColor={C.accent} />
        </Card>
      </Section>

      <Section title="Nastavenia">
        <Card>
          <Row label="Rýchlosť hry" value={`${s.speed}×`} />
          <Row label="Cena elektriny" value={`${s.settings.elecPrice.toFixed(4)} €/kWh`} />
          <Row label="Auto-predaj ťažby" value={`${s.settings.autoSellPct} %`} />
          <Row label="Záchranný auto-predaj" value={s.settings.autoTreasury ? 'zapnutý' : 'vypnutý'} valueColor={s.settings.autoTreasury ? C.green : C.textDim} />
          <Row label="Zdroj ceny" value={s.priceMode === 'live' ? 'živý kurz' : 'simulácia'} />
          <View style={stl.divider} />
          <Button label="💾 Uložiť teraz" variant="muted" onPress={actions.save} />
          {confirming ? (
            <View style={{ marginTop: S.md, gap: S.sm }}>
              <Text style={[F.small, { color: C.red, lineHeight: 18 }]}>
                Naozaj chceš zmazať uloženú hru a začať odznova? Tento krok sa nedá vrátiť.
              </Text>
              <View style={{ flexDirection: 'row', gap: S.sm }}>
                <Button label="Zrušiť" variant="muted" style={{ flex: 1 }} onPress={() => setConfirming(false)} />
                <Button
                  label="Zmazať a reštartovať"
                  variant="danger"
                  style={{ flex: 1 }}
                  onPress={() => {
                    setConfirming(false);
                    actions.newGame();
                  }}
                />
              </View>
            </View>
          ) : (
            <Button label="🔄 Nová hra" variant="danger" style={{ marginTop: S.sm }} onPress={() => setConfirming(true)} />
          )}
        </Card>
      </Section>

      <Card style={{ backgroundColor: C.bgAlt }}>
        <Text style={[F.small, { lineHeight: 20, color: C.textDim }]}>
          <Text style={{ color: C.text, fontWeight: '700' }}>{APP_NAME}</Text> — vzdelávacia simulácia ťažby
          bitcoinu. Herný engine používa skutočné vzťahy (odmena za block, difficulty = hashrate × 2³² ÷ 600,
          halving každých 210 000 blockov), ale ekonomika je zmenšená a vyvážená pre hrateľnosť.
          Nejde o investičné poradenstvo a nepoužívajú sa žiadne reálne prostriedky.
        </Text>
      </Card>
    </ScrollView>
  );
}

const stl = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: C.bg },
  content: { padding: S.lg, paddingBottom: S.xxl, gap: S.lg },
  divider: { height: 1, backgroundColor: C.border, marginVertical: S.md },
});
