import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, StyleSheet } from 'react-native';

import { C, S, F, R, signColor } from '../theme.js';
import { Card, Section, Button, Chip, Segmented, Row } from '../components/ui.js';
import PriceChart from '../components/Sparkline.js';
import { formatEur, formatBtc, formatSats, formatNumber, formatGameTime } from '../game/format.js';
import { fairPrice, cycleFactor } from '../game/engine.js';
import { GAME } from '../game/constants.js';

const PRESETS = [0.1, 0.25, 0.5, 1];

export default function MarketScreen({ state: s, d, actions, liveInfo }) {
  const [pct, setPct] = useState(0.25);
  const [eurAmt, setEurAmt] = useState(500);

  const fair = fairPrice(s.time, s.height);
  const phase = (s.height % GAME.HALVING_BLOCKS) / GAME.HALVING_BLOCKS;
  const cyclePct = (cycleFactor(s.height) - (1 - GAME.PRICE_CYCLE_AMP)) / (2 * GAME.PRICE_CYCLE_AMP);

  return (
    <ScrollView style={st.scroll} contentContainerStyle={st.content} showsVerticalScrollIndicator={false}>
      {/* ---------------- režim ceny ---------------- */}
      <Card style={{ marginBottom: S.lg }}>
        <View style={st.rowBetween}>
          <Text style={F.label}>ZDROJ CENY</Text>
          <Chip
            label={s.priceMode === 'live' ? '🌐 ŽIVÝ KURZ' : '🎲 SIMULOVANÝ TRH'}
            color={s.priceMode === 'live' ? C.green : C.purple}
            filled
          />
        </View>
        <Segmented
          style={{ marginTop: S.md }}
          options={[
            { value: 'sim', label: '🎲 Simulácia' },
            { value: 'live', label: '🌐 Živý kurz' },
          ]}
          value={s.priceMode}
          onChange={(m) => {
            if (m === 'live' && !(s.livePrice > 0)) actions.refreshPrice();
            else actions.setPriceMode(m);
          }}
        />
        {s.priceMode === 'live' ? (
          <Text style={[F.tiny, { marginTop: S.sm, lineHeight: 16 }]}>
            {liveInfo.status === 'loading'
              ? 'Načítavam kurz z CoinGecko…'
              : liveInfo.status === 'error'
              ? 'Nepodarilo sa načítať kurz — skontroluj pripojenie. Hra beží ďalej na simulácii.'
              : s.livePrice
              ? `Posledná aktualizácia: ${new Date(s.livePrice && liveInfo.at ? liveInfo.at : Date.now()).toLocaleTimeString('sk-SK')}${liveInfo.usd ? ` · ${formatNumber(Math.round(liveInfo.usd))} USD` : ''}`
              : ''}
          </Text>
        ) : (
          <Text style={[F.tiny, { marginTop: S.sm, lineHeight: 16 }]}>
            Simulovaný trh používa 4-ročný cyklus naviazaný na halving plus náhodný šum. Udalosti spôsobujú dočasné
            cenové šoky, ktoré sa samy vytratia.
          </Text>
        )}
        {s.priceMode === 'live' ? (
          <Button small label="🔄 Obnoviť kurz" variant="muted" style={{ marginTop: S.sm }} onPress={actions.refreshPrice} />
        ) : null}
      </Card>

      {/* ---------------- graf ---------------- */}
      <Section title="Cena BTC / EUR">
        <Card>
          <View style={st.rowBetween}>
            <View>
              <Text style={[F.big, { fontSize: 30, color: C.accent }]}>{formatEur(s.price, 0)}</Text>
              <Text style={F.tiny}>{formatNumber(Math.round((s.price / 100_000_000) * 1000))} € za 1 000 sats</Text>
            </View>
            <View style={{ alignItems: 'flex-end' }}>
              <Chip label={`šok ×${s.priceShock.toFixed(3)}`} color={Math.abs(s.priceShock - 1) > 0.01 ? C.yellow : C.textFaint} />
              <Text style={[F.tiny, { marginTop: 6 }]}>férová {formatEur(fair, 0)}</Text>
            </View>
          </View>
          <View style={{ marginTop: S.lg }}>
            <PriceChart data={s.priceHistory} height={130} />
          </View>
        </Card>
      </Section>

      {/* ---------------- cyklus ---------------- */}
      <Section title="Kde sme v 4-ročnom cykle">
        <Card>
          <View style={st.cycleTrack}>
            <View style={[st.cycleFill, { width: `${Math.max(0, Math.min(1, phase)) * 100}%` }]} />
            <View style={[st.cycleMarker, { left: `${GAME.PRICE_CYCLE_PEAK_PHASE * 100}%` }]} />
          </View>
          <View style={st.rowBetween}>
            <Text style={F.tiny}>halving</Text>
            <Text style={[F.tiny, { color: C.accent }]}>vrchol cyklu</Text>
            <Text style={F.tiny}>ďalší halving</Text>
          </View>
          <View style={st.divider} />
          <Row
            label="Pozícia v cykle"
            value={`${(phase * 100).toFixed(1)} %`}
            hint={`cyklus ×${cycleFactor(s.height).toFixed(2)}`}
          />
          <Row
            label="Do halvingu"
            value={`${formatNumber(Math.ceil(d.blocksToHalving))} blockov`}
            hint={`≈ ${formatNumber(Math.round(d.daysToHalving))} dní`}
          />
          <Row label="Odmena po halvingu" value={`${d.reward / 2} BTC`} valueColor={C.purple} />
          <Text style={[F.small, { marginTop: S.md, lineHeight: 19, color: C.textDim }]}>
            Historicky cena vrcholí približne 1–1,5 roka po halvingu a dno tvorí okolo dvoch rokov po ňom.
            Simulácia tento tvar kopíruje — ale mineri, ktorí čakajú na vrchol, často predajú neskoro.
          </Text>
        </Card>
      </Section>

      {/* ---------------- peňaženka ---------------- */}
      <Section title="Tvoja peňaženka">
        <Card>
          <View style={st.wallet}>
            <View style={{ flex: 1 }}>
              <Text style={F.tiny}>ZOSTATOK BTC</Text>
              <Text style={[F.h2, { color: C.accent }]}>{formatBtc(s.btc, 8)}</Text>
              <Text style={F.tiny}>{formatSats(s.btc * 1e8)}</Text>
            </View>
            <View style={{ alignItems: 'flex-end' }}>
              <Text style={F.tiny}>HODNOTA</Text>
              <Text style={F.h2}>{formatEur(s.btc * s.price, 2)}</Text>
            </View>
          </View>
          <View style={st.divider} />
          <Row label="Vyťažené celkovo" value={formatBtc(s.stats.btcMined, 6)} />
          <Row label="Predané celkovo" value={formatBtc(s.stats.btcSold, 6)} hint={formatEur(s.stats.eurFromSales, 0)} />
          <Row label="Kúpené za EUR" value={formatBtc(s.stats.btcBought, 6)} />
        </Card>
      </Section>

      {/* ---------------- obchodovanie ---------------- */}
      <Section title="Obchodovanie">
        <Card>
          <Text style={F.tiny}>PREDAŤ BTC</Text>
          <View style={st.presets}>
            {PRESETS.map((p) => (
              <Pressable key={p} onPress={() => setPct(p)} style={[st.preset, pct === p && st.presetOn]}>
                <Text style={[st.presetLabel, pct === p && st.presetLabelOn]}>
                  {p === 1 ? 'všetko' : `${p * 100} %`}
                </Text>
              </Pressable>
            ))}
          </View>
          <View style={st.rowBetween}>
            <Text style={[F.mono, { color: C.textDim }]}>
              {formatBtc(s.btc * pct, 6)} → {formatEur(s.btc * pct * s.price, 2)}
            </Text>
          </View>
          <Button
            style={{ marginTop: S.md }}
            label={`Predať ${pct === 1 ? 'všetko' : `${pct * 100} %`} za ${formatEur(s.btc * pct * s.price, 0)}`}
            variant="good"
            disabled={s.btc <= 0}
            onPress={() => actions.sellBtc(s.btc * pct)}
          />

          <View style={st.divider} />

          <Text style={F.tiny}>KÚPIŤ BTC (DCA)</Text>
          <View style={st.presets}>
            {[100, 500, 1000, 5000].map((v) => (
              <Pressable key={v} onPress={() => setEurAmt(v)} style={[st.preset, eurAmt === v && st.presetOn]}>
                <Text style={[st.presetLabel, eurAmt === v && st.presetLabelOn]}>{formatNumber(v)} €</Text>
              </Pressable>
            ))}
          </View>
          <Button
            style={{ marginTop: S.md }}
            label={`Kúpiť BTC za ${formatEur(eurAmt, 0)} (${formatBtc(eurAmt / s.price, 6)})`}
            variant="muted"
            disabled={s.eur < eurAmt}
            onPress={() => actions.buyBtc(eurAmt)}
          />
          <Text style={[F.tiny, { marginTop: S.sm, lineHeight: 16 }]}>
            Nákup BTC v hre nespotrebúva žiadne reálne peniaze — je to simulácia.
          </Text>
        </Card>
      </Section>

      {/* ---------------- treasury ---------------- */}
      <Section title="Treasury — ako miner platí elektrinu">
        <Card>
          <Text style={[F.small, { lineHeight: 20, color: C.textDim }]}>
            Elektrina sa platí v eurách, ale ťažíš bitcoiny. Reálni mineri preto musia časť úlovku predávať.
            Tu si nastavíš, koľko.
          </Text>
          <View style={st.divider} />
          <Text style={F.tiny}>AUTOMATICKÝ PREDAJ ŤAŽBY</Text>
          <Segmented
            style={{ marginTop: S.sm }}
            options={[0, 25, 50, 75, 100].map((v) => ({ value: v, label: `${v} %` }))}
            value={s.settings.autoSellPct}
            onChange={actions.setAutoSellPct}
          />
          <Row
            label="Peňažný tok do peňaženky"
            value={`${formatEur(d.cashFlowEurPerDay, 2)}/deň`}
            valueColor={signColor(d.cashFlowEurPerDay)}
            hint={d.cashFlowEurPerDay < 0 ? 'strácaš hotovosť' : ''}
          />
          <Row
            label="BTC zostáva v držbe"
            value={`${formatBtc(d.btcPerDay * (1 - d.autoSellPct / 100), 8)}/deň`}
            valueColor={C.accent}
          />
          <Row label="Runway hotovosti" value={isFinite(d.runwayDays) ? `${d.runwayDays.toFixed(1)} dní` : '∞'} />

          <View style={st.divider} />
          <View style={st.rowBetween}>
            <View style={{ flex: 1, paddingRight: S.md }}>
              <Text style={F.h3}>Záchranný auto-predaj</Text>
              <Text style={[F.tiny, { marginTop: 3, lineHeight: 15 }]}>
                Keď nemáš na elektrinu, engine sám predá toľko BTC, koľko treba. Vypni to, ak chceš hrať čisté HODL.
              </Text>
            </View>
            <Pressable
              onPress={() => actions.setAutoTreasury(!s.settings.autoTreasury)}
              style={[st.switch, s.settings.autoTreasury ? st.switchOn : st.switchOff]}
            >
              <View style={[st.knob, s.settings.autoTreasury && st.knobOn]} />
            </Pressable>
          </View>
        </Card>
      </Section>
    </ScrollView>
  );
}

const st = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: C.bg },
  content: { padding: S.lg, paddingBottom: S.xxl, gap: S.lg },
  rowBetween: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  divider: { height: 1, backgroundColor: C.border, marginVertical: S.md },
  wallet: { flexDirection: 'row', alignItems: 'flex-start' },
  cycleTrack: { height: 10, backgroundColor: C.bgAlt, borderRadius: 99, overflow: 'visible', marginBottom: 6 },
  cycleFill: { height: 10, backgroundColor: C.accent, borderRadius: 99, opacity: 0.6 },
  cycleMarker: { position: 'absolute', top: -3, width: 2, height: 16, backgroundColor: C.text },
  presets: { flexDirection: 'row', gap: S.sm, marginTop: S.sm, marginBottom: S.sm },
  preset: {
    flex: 1,
    paddingVertical: 9,
    borderRadius: R.sm,
    backgroundColor: C.bgAlt,
    borderWidth: 1,
    borderColor: C.border,
    alignItems: 'center',
  },
  presetOn: { backgroundColor: C.accent, borderColor: C.accent },
  presetLabel: { fontSize: 12, fontWeight: '700', color: C.textDim },
  presetLabelOn: { color: '#1A1206' },
  switch: { width: 46, height: 27, borderRadius: 99, padding: 3, justifyContent: 'center' },
  switchOn: { backgroundColor: C.green },
  switchOff: { backgroundColor: C.borderHi },
  knob: { width: 21, height: 21, borderRadius: 99, backgroundColor: '#fff' },
  knobOn: { alignSelf: 'flex-end' },
});
