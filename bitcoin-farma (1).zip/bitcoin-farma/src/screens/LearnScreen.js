import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, StyleSheet } from 'react-native';

import { C, S, F, R } from '../theme.js';
import { Card, Section, Segmented, Chip } from '../components/ui.js';
import { LESSONS } from '../data/lessons.js';
import { ACHIEVEMENTS } from '../data/achievements.js';
import { HARDWARE } from '../data/hardware.js';
import { formatNumber } from '../game/format.js';

export default function LearnScreen({ state: s }) {
  const [tab, setTab] = useState('lessons');
  const [open, setOpen] = useState({});

  const discovered = Object.keys(s.lessonsSeen);
  const unlockedAch = ACHIEVEMENTS.filter((a) => s.achievements[a.id]);

  return (
    <ScrollView style={st.scroll} contentContainerStyle={st.content} showsVerticalScrollIndicator={false}>
      <Card style={{ marginBottom: S.lg, backgroundColor: C.bgAlt }}>
        <Text style={F.h2}>🎓 Akadémia</Text>
        <Text style={[F.small, { marginTop: S.sm, lineHeight: 20, color: C.textDim }]}>
          Všetko v tejto hre je postavené na skutočných vzťahoch Bitcoinu: odmena za block, difficulty, halving,
          hashprice, J/TH. Hraním odomykáš vysvetlenia toho, čo sa ti práve stalo.
        </Text>
        <View style={{ flexDirection: 'row', gap: S.sm, marginTop: S.md, flexWrap: 'wrap' }}>
          <Chip label={`${LESSONS.length} lekcií`} color={C.accent} />
          <Chip label={`${discovered.length} objavených poznatkov`} color={C.green} />
          <Chip label={`${unlockedAch.length}/${ACHIEVEMENTS.length} úspechov`} color={C.purple} />
        </View>
      </Card>

      <Segmented
        options={[
          { value: 'lessons', label: 'Lekcie' },
          { value: 'found', label: `Objavené (${discovered.length})` },
          { value: 'ach', label: `Úspechy (${unlockedAch.length})` },
        ]}
        value={tab}
        onChange={setTab}
        style={{ marginBottom: S.lg }}
      />

      {tab === 'lessons'
        ? LESSONS.map((l) => (
            <Accordion
              key={l.id}
              emoji={l.emoji}
              title={l.title}
              open={open[l.id]}
              onToggle={() => setOpen((o) => ({ ...o, [l.id]: !o[l.id] }))}
              body={
                <>
                  <Text style={[F.body, { lineHeight: 22 }]}>{l.text}</Text>
                  <View style={st.fact}>
                    <Text style={[F.small, { color: C.accent, lineHeight: 19 }]}>💡 {l.fact}</Text>
                  </View>
                </>
              }
            />
          ))
        : null}

      {tab === 'found' ? (
        discovered.length === 0 ? (
          <Card>
            <Text style={[F.small, { lineHeight: 20 }]}>
              Zatiaľ si nič neobjavil. Poznatky sa odomykajú, keď niečo kúpiš, zažiješ halving, úpravu difficulty
              alebo nejakú udalosť.
            </Text>
          </Card>
        ) : (
          <>
            <Card style={{ marginBottom: S.md, backgroundColor: C.bgAlt }}>
              <Text style={[F.small, { lineHeight: 19, color: C.textDim }]}>
                Tieto poznatky si objavil hraním — viažu sa k udalostiam, strojom a vylepšeniam, s ktorými si sa stretol.
              </Text>
            </Card>
            {discovered.map((text, i) => (
              <Card key={i} style={{ marginBottom: S.sm }} accent={C.green}>
                <Text style={[F.body, { lineHeight: 21 }]}>{text}</Text>
              </Card>
            ))}
          </>
        )
      ) : null}

      {tab === 'ach' ? (
        <>
          <Section title={`Odomknuté (${unlockedAch.length})`}>
            {unlockedAch.length === 0 ? (
              <Card>
                <Text style={F.small}>Zatiaľ žiadne. Kúp si prvý stroj!</Text>
              </Card>
            ) : (
              unlockedAch.map((a) => (
                <Card key={a.id} style={{ marginBottom: S.sm }} accent={C.accent}>
                  <View style={st.achRow}>
                    <Text style={{ fontSize: 24 }}>{a.emoji}</Text>
                    <View style={{ flex: 1, marginLeft: S.md }}>
                      <Text style={F.h3}>{a.name}</Text>
                      <Text style={F.tiny}>{a.desc}</Text>
                    </View>
                    <Text style={{ color: C.green, fontSize: 18 }}>✓</Text>
                  </View>
                </Card>
              ))
            )}
          </Section>
          <Section title={`Zamknuté (${ACHIEVEMENTS.length - unlockedAch.length})`}>
            {ACHIEVEMENTS.filter((a) => !s.achievements[a.id]).map((a) => (
              <Card key={a.id} style={{ marginBottom: S.sm, opacity: 0.55 }}>
                <View style={st.achRow}>
                  <Text style={{ fontSize: 24 }}>🔒</Text>
                  <View style={{ flex: 1, marginLeft: S.md }}>
                    <Text style={F.h3}>{a.name}</Text>
                    <Text style={F.tiny}>{a.desc}</Text>
                  </View>
                </View>
              </Card>
            ))}
          </Section>
        </>
      ) : null}

      {/* ---------------- tabuľka reálnych čísel ---------------- */}
      <Section title="Reálne halvingy Bitcoinu">
        <Card>
          {[
            ['2009', '0', '50 BTC', '—'],
            ['2012', '210 000', '25 BTC', 'nov. 2012'],
            ['2016', '420 000', '12,5 BTC', 'júl 2016'],
            ['2020', '630 000', '6,25 BTC', 'máj 2020'],
            ['2024', '840 000', '3,125 BTC', 'apríl 2024'],
            ['~2028', '1 050 000', '1,5625 BTC', 'očakávaný'],
          ].map((row, i) => (
            <View key={i} style={[st.gridRow, i === 0 && { borderBottomWidth: 1, borderBottomColor: C.border }]}>
              {row.map((cell, j) => (
                <Text
                  key={j}
                  style={[
                    F.small,
                    { flex: j === 0 ? 0.8 : 1 },
                    i === 0 && [F.tiny, { color: C.textFaint }],
                    j === 2 && { color: C.accent, fontWeight: '700' },
                  ]}
                  numberOfLines={1}
                >
                  {cell}
                </Text>
              ))}
            </View>
          ))}
          <Text style={[F.tiny, { marginTop: S.md, lineHeight: 16 }]}>
            Hra začína na blocku {formatNumber(1_020_000)} — teda v ére odmeny 3,125 BTC, presne ako skutočný
            Bitcoin dnes.
          </Text>
        </Card>
      </Section>

      <Section title="Efektivita ASIC-ov v hre">
        <Card>
          {HARDWARE.map((hw) => (
            <View key={hw.id} style={st.gridRow}>
              <Text style={[F.small, { flex: 2 }]} numberOfLines={1}>
                {hw.emoji} {hw.name}
              </Text>
              <Text style={[F.mono, { flex: 1, textAlign: 'right', color: C.textDim }]} numberOfLines={1}>
                {(hw.watts / (hw.hash / 1e12)).toFixed(1)} J/TH
              </Text>
            </View>
          ))}
          <Text style={[F.tiny, { marginTop: S.md, lineHeight: 16 }]}>
                Reálny vývoj: Antminer S9 (2016) mal ~98 J/TH, dnešná špička je okolo 13–15 J/TH. To je pokles
                o viac než 7-násobok za desaťročie — a dôvod, prečo staré stroje končia v šrote.
          </Text>
        </Card>
      </Section>

      <Card style={{ backgroundColor: C.bgAlt, marginTop: S.sm }}>
        <Text style={[F.h3, { color: C.yellow }]}>⚠️ Disklaimer</Text>
        <Text style={[F.small, { marginTop: S.sm, lineHeight: 20, color: C.textDim }]}>
          Toto je vzdelávacia simulácia, nie investičné poradenstvo a nie spôsob, ako „množiť bitcoiny“.
          Žiadne reálne bitcoiny ani peniaze sa tu nepoužívajú, neodosielajú ani neskladujú.
          Reálny mining aj reálne kryptomeny nesú riziko straty celého vkladu. Nikdy nevkladaj peniaze,
          o ktoré nemôžeš prísť, a nedôveruj nikomu, kto sľubuje garantované zhodnotenie bitcoinu —
          také schémy sú podvod.
        </Text>
      </Card>
    </ScrollView>
  );
}

function Accordion({ emoji, title, body, open, onToggle }) {
  return (
    <Card style={{ marginBottom: S.sm, padding: 0, overflow: 'hidden' }}>
      <Pressable onPress={onToggle} style={st.accHead}>
        <Text style={{ fontSize: 20 }}>{emoji}</Text>
        <Text style={[F.h3, { flex: 1, marginLeft: S.md }]}>{title}</Text>
        <Text style={[F.h3, { color: C.textDim }]}>{open ? '−' : '+'}</Text>
      </Pressable>
      {open ? <View style={st.accBody}>{body}</View> : null}
    </Card>
  );
}

const st = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: C.bg },
  content: { padding: S.lg, paddingBottom: S.xxl, gap: S.lg },
  fact: {
    marginTop: S.md,
    padding: S.md,
    backgroundColor: C.bgAlt,
    borderRadius: R.sm,
    borderLeftWidth: 3,
    borderLeftColor: C.accent,
  },
  accHead: { flexDirection: 'row', alignItems: 'center', padding: S.lg },
  accBody: { paddingHorizontal: S.lg, paddingBottom: S.lg },
  achRow: { flexDirection: 'row', alignItems: 'center' },
  gridRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 6, gap: S.sm },
});
