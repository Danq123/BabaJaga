import React, { useMemo, useState } from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';

import { C, S, F, R, signColor } from '../theme.js';
import { Card, Section, Button, Chip, Segmented, Row } from '../components/ui.js';
import { formatHash, formatEur, formatPower, formatNumber } from '../game/format.js';
import { HARDWARE, HW_BY_ID, jPerTh } from '../data/hardware.js';
import { UPGRADES, UPGRADE_BY_ID } from '../data/upgrades.js';
import { GAME } from '../game/constants.js';
import { shopPrice, canBuyUpgrade, repairCost } from '../game/engine.js';

const QTY = [1, 5, 10];

/**
 * Vypočíta, čo by kúpa `qty` kusov urobila s farmou (bez nákupu).
 * Používa rovnakú logiku ako engine, len na kópii stavu.
 */
function projectRig(s, d, hw, qty) {
  const cooling = d.coolingKw;
  const newLoad = cooling > 0 ? (d.heatKw + hw.heat * qty) / cooling : 99;

  // hrubý príjem na TH je pre všetky stroje rovnaký — rozdiel je len v spotrebe
  const grossPerDay = (hw.hash / 1e12) * d.hashPriceEurPerThDay * qty * (1 - d.poolFee);
  const elecPerDay = (hw.watts * qty * 24 * d.elecPrice) / 1000;
  const netPerDay = grossPerDay - elecPerDay;
  const cost = shopPrice(s, hw) * qty;
  return {
    grossPerDay,
    elecPerDay,
    netPerDay,
    cost,
    payback: netPerDay > 0 ? cost / netPerDay : Infinity,
    newLoad,
    overheats: newLoad > 0.98,
    throttle: newLoad > 0.75,
  };
}

export default function ShopScreen({ state: s, d, actions }) {
  const [qty, setQty] = useState(1);
  const [tab, setTab] = useState('hw');

  const totalBroken = useMemo(
    () => Object.values(s.rigs).reduce((a, r) => a + (r.broken || 0), 0),
    [s.rigs]
  );
  const totalRepair = useMemo(
    () => Object.keys(s.rigs).reduce((a, id) => a + repairCost(s, id), 0),
    [s.rigs, totalBroken]
  );

  return (
    <ScrollView style={st.scroll} contentContainerStyle={st.content} showsVerticalScrollIndicator={false}>
      <Card style={{ marginBottom: S.lg }} accent={C.accent}>
        <Row label="Hotovosť" value={formatEur(s.eur, 0)} valueColor={signColor(s.eur)} />
        <Row
          label="Chladenie"
          value={`${formatPower(d.heatKw * 1000)} / ${formatPower(d.coolingKw * 1000)}`}
          valueColor={d.nominalLoad > 0.98 ? C.red : d.nominalLoad > 0.75 ? C.yellow : C.green}
          hint={`${(d.nominalLoad * 100).toFixed(0)} % záťaž`}
        />
        <Row label="Cena elektriny" value={`${d.elecPrice.toFixed(4)} €/kWh`} />
        <Row label="Hashprice" value={`${d.hashPriceEurPerThDay.toFixed(4)} €/TH/deň`} />
      </Card>

      <Segmented
        options={[
          { value: 'hw', label: '🖨️ Hardvér' },
          { value: 'up', label: '🔧 Vylepšenia' },
          { value: 'svc', label: '🛠️ Servis' },
        ]}
        value={tab}
        onChange={setTab}
        style={{ marginBottom: S.lg }}
      />

      {tab === 'hw' ? (
        <>
          <View style={st.qtyRow}>
            <Text style={F.tiny}>MNOŽSTVO</Text>
            <Segmented options={QTY.map((q) => ({ value: q, label: `${q}×` }))} value={qty} onChange={setQty} style={{ flex: 1 }} />
          </View>

          <Card style={{ marginBottom: S.lg, backgroundColor: C.bgAlt }}>
            <Text style={[F.small, { lineHeight: 19 }]}>
              💡 <Text style={{ color: C.text, fontWeight: '700' }}>Hrubý príjem na TH/s je pre všetky stroje rovnaký.</Text>{' '}
              Rozhoduje teda výhradne spotreba (J/TH) a tvoja cena elektriny. Lacný starý stroj je takmer vždy pasca.
            </Text>
          </Card>

          {HARDWARE.map((hw) => {
            const p = projectRig(s, d, hw, qty);
            const afford = s.eur >= p.cost;
            const profitable = p.netPerDay > 0;
            return (
              <Card key={hw.id} style={{ marginBottom: S.md }} accent={profitable ? C.green : C.red}>
                <View style={st.hwHead}>
                  <Text style={{ fontSize: 26 }}>{hw.emoji}</Text>
                  <View style={{ flex: 1, marginLeft: S.md }}>
                    <Text style={F.h3}>{hw.name}</Text>
                    <Text style={F.tiny}>
                      tier {hw.tier} · {s.rigs[hw.id]?.count ? `máš ${s.rigs[hw.id].count}×` : 'nevlastníš'}
                    </Text>
                  </View>
                  <View style={{ alignItems: 'flex-end' }}>
                    <Text style={[F.mono, { fontSize: 16, color: C.accent }]}>{formatEur(p.cost, 0)}</Text>
                    {qty > 1 ? <Text style={F.tiny}>{formatEur(shopPrice(s, hw), 0)} / ks</Text> : null}
                  </View>
                </View>

                <View style={st.specRow}>
                  <Spec label="HASHRATE" value={formatHash(hw.hash * qty)} />
                  <Spec label="SPOTREBA" value={formatPower(hw.watts * qty)} />
                  <Spec label="EFEKTIVITA" value={`${jPerTh(hw).toFixed(1)} J/TH`} />
                  <Spec label="TEPLO" value={`${(hw.heat * qty).toFixed(2)} kW`} />
                </View>

                <View style={st.divider} />

                <Row label="Hrubý príjem" value={`${formatEur(p.grossPerDay, 2)}/deň`} valueColor={C.green} />
                <Row label="Elektrina" value={`−${formatEur(p.elecPerDay, 2)}/deň`} valueColor={C.red} />
                <Row
                  label="Čistý prínos"
                  value={`${formatEur(p.netPerDay, 2)}/deň`}
                  valueColor={signColor(p.netPerDay)}
                />
                <Row
                  label="Návratnosť"
                  value={isFinite(p.payback) ? `${formatNumber(Math.round(p.payback))} herných dní` : 'nikdy'}
                  valueColor={isFinite(p.payback) ? C.text : C.red}
                  hint={isFinite(p.payback) ? `≈ ${(p.payback / 365).toFixed(1)} roka` : 'stratový'}
                />

                {p.overheats ? (
                  <Warning color={C.red}>
                    ⛔ Toto prekročí tvoje chladenie ({(p.newLoad * 100).toFixed(0)} %). Stroje by sa tepelne obmedzili
                    alebo odstavili. Najprv kúp chladenie vo Vylepšeniach.
                  </Warning>
                ) : p.throttle ? (
                  <Warning color={C.yellow}>
                    ⚠️ Chladenie bude na {(p.newLoad * 100).toFixed(0)} %. Ide to, ale bez rezervy.
                  </Warning>
                ) : null}

                {!profitable ? (
                  <Warning color={C.red}>
                    📉 Pri aktuálnej cene elektriny a difficulty je tento stroj v mínuse. Reálne by skončil v šrote.
                  </Warning>
                ) : null}

                <Text style={[F.small, { marginTop: S.md, color: C.textDim, lineHeight: 19 }]}>{hw.desc}</Text>

                <Button
                  style={{ marginTop: S.md }}
                  label={afford ? `Kúpiť ${qty}× za ${formatEur(p.cost, 0)}` : `Nedostatok peňazí (chýba ${formatEur(p.cost - s.eur, 0)})`}
                  disabled={!afford}
                  variant={profitable ? 'primary' : 'muted'}
                  onPress={() => actions.buyRig(hw.id, qty)}
                />
              </Card>
            );
          })}
        </>
      ) : null}

      {tab === 'up' ? (
        <>
          <Card style={{ marginBottom: S.lg, backgroundColor: C.bgAlt }}>
            <Text style={[F.small, { lineHeight: 19 }]}>
              🔧 Vylepšenia menia pravidlá hry: lacnejšia elektrina, viac chladenia, nižšia poruchovosť. Niektoré
              vyžadujú iné vylepšenie ako predpoklad.
            </Text>
          </Card>
          {UPGRADES.map((u) => {
            const check = canBuyUpgrade(s, u.id);
            const owned = !!s.upgrades[u.id];
            const blocked = !owned && !check.ok && !/peňazí/.test(check.reason || '');
            return (
              <Card key={u.id} style={{ marginBottom: S.md }} accent={owned ? C.green : blocked ? C.borderHi : C.accent}>
                <View style={st.hwHead}>
                  <Text style={{ fontSize: 24 }}>{u.emoji}</Text>
                  <View style={{ flex: 1, marginLeft: S.md }}>
                    <Text style={[F.h3, owned && { color: C.green }]}>{u.name}</Text>
                    <Text style={F.tiny}>{owned ? 'VLASTNÍŠ' : blocked ? check.reason : formatEur(u.price, 0)}</Text>
                  </View>
                  {!owned ? <Text style={[F.mono, { fontSize: 15, color: C.accent }]}>{formatEur(u.price, 0)}</Text> : <Text style={{ fontSize: 20 }}>✅</Text>}
                </View>
                <Text style={[F.small, { marginTop: S.sm, lineHeight: 19, color: C.textDim }]}>{u.desc}</Text>
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: S.sm, marginTop: S.sm }}>
                  {u.coolingKw ? <Chip label={`+${u.coolingKw} kW chladenie`} color={C.blue} /> : null}
                  {u.elecDiscount ? <Chip label={`−${(u.elecDiscount * 100).toFixed(0)} % elektrina`} color={C.green} /> : null}
                  {u.elecPrice ? <Chip label={`sadzba ${u.elecPrice} €/kWh`} color={C.green} /> : null}
                  {u.hashMult ? <Chip label={`+${((u.hashMult - 1) * 100).toFixed(0)} % hashrate`} color={C.accent} /> : null}
                  {u.powerMult && u.powerMult > 1 ? <Chip label={`+${((u.powerMult - 1) * 100).toFixed(0)} % spotreba`} color={C.red} /> : null}
                  {u.powerMult && u.powerMult < 1 ? <Chip label={`−${((1 - u.powerMult) * 100).toFixed(0)} % spotreba`} color={C.green} /> : null}
                  {u.effBonus ? <Chip label={`+${(u.effBonus * 100).toFixed(0)} % efektivita`} color={C.purple} /> : null}
                  {u.failMult ? <Chip label={`−${((1 - u.failMult) * 100).toFixed(0)} % poruchy`} color={C.blue} /> : null}
                  {u.poolFee !== undefined ? <Chip label={`poplatok poolu ${(u.poolFee * 100).toFixed(1)} %`} color={C.accent} /> : null}
                  {u.blackoutProtection ? <Chip label="odolnosť voči výpadkom" color={C.yellow} /> : null}
                </View>
                {!owned ? (
                  <Button
                    style={{ marginTop: S.md }}
                    label={check.ok ? `Kúpiť za ${formatEur(u.price, 0)}` : check.reason || 'Nedostupné'}
                    disabled={!check.ok}
                    onPress={() => actions.buyUpgrade(u.id)}
                  />
                ) : null}
              </Card>
            );
          })}
        </>
      ) : null}

      {tab === 'svc' ? (
        <>
          <Card>
            <Text style={F.h2}>🛠️ Servis a údržba</Text>
            <Text style={[F.small, { marginTop: S.sm, lineHeight: 20, color: C.textDim }]}>
              Poruchové stroje neťažia, ale stále zaberajú miesto. Oprava stojí{' '}
              {(GAME.REPAIR_RATIO * 100).toFixed(0)} % obstarávacej ceny za kus. Predaj použitých strojov
              vráti {(GAME.SELLBACK_RATIO * 100).toFixed(0)} % ceny.
            </Text>
            <View style={st.divider} />
            <Row label="Pokazených strojov" value={String(totalBroken)} valueColor={totalBroken ? C.red : C.green} />
            <Row label="Celková cena opráv" value={formatEur(totalRepair, 0)} />
            <Row label="Zaplatené opravy celkovo" value={formatEur(s.stats.eurSpentRepairs, 0)} />
            <Row label="Počet porúch celkovo" value={formatNumber(s.stats.breakdowns)} />
            <Button
              style={{ marginTop: S.lg }}
              label={totalBroken ? `Opraviť všetko za ${formatEur(totalRepair, 0)}` : 'Všetko je v poriadku ✅'}
              disabled={!totalBroken || s.eur < totalRepair}
              onPress={actions.repairAll}
            />
          </Card>

          <Card style={{ marginTop: S.lg, backgroundColor: C.bgAlt }}>
            <Text style={[F.small, { lineHeight: 20 }]}>
              💡 Poruchovosť rastie s teplotou a s pretaktovaním. Imérzne chladenie a monitoring ju výrazne znižujú.
              Podtaktovanie (−15 %) znižuje poruchy a často zvýši čistý zisk, pretože ušetrí viac na elektrine,
              než stratí na výkone.
            </Text>
          </Card>
        </>
      ) : null}
    </ScrollView>
  );
}

function Spec({ label, value }) {
  return (
    <View style={{ flex: 1, minWidth: '45%' }}>
      <Text style={F.tiny}>{label}</Text>
      <Text style={[F.mono, { fontSize: 13, color: C.text }]}>{value}</Text>
    </View>
  );
}

function Warning({ children, color }) {
  return (
    <View style={[st.warn, { borderColor: color, backgroundColor: `${color}14` }]}>
      <Text style={[F.small, { color, lineHeight: 18 }]}>{children}</Text>
    </View>
  );
}

const st = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: C.bg },
  content: { padding: S.lg, paddingBottom: S.xxl },
  qtyRow: { flexDirection: 'row', alignItems: 'center', gap: S.md, marginBottom: S.md },
  hwHead: { flexDirection: 'row', alignItems: 'center' },
  specRow: { flexDirection: 'row', flexWrap: 'wrap', gap: S.sm, marginTop: S.md },
  divider: { height: 1, backgroundColor: C.border, marginVertical: S.md },
  warn: { borderRadius: R.sm, borderWidth: 1, padding: S.sm + 2, marginTop: S.sm },
});
