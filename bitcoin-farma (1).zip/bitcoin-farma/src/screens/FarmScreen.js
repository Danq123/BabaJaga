import React from 'react';
import { View, Text, ScrollView, Pressable, StyleSheet } from 'react-native';

import { C, S, F, R, signColor, tempColor } from '../theme.js';
import { Card, Section, Button, Stat, Chip, Segmented, Row, Empty } from '../components/ui.js';
import { Gauge } from '../components/Sparkline.js';
import {
  formatHash, formatEur, formatBtc, formatSats, formatPower, formatEnergy,
  formatGameTime, formatDuration, formatDifficulty, formatNumber,
} from '../game/format.js';
import { HARDWARE, HW_BY_ID, jPerTh } from '../data/hardware.js';
import { GAME } from '../game/constants.js';

const MODES = [
  { value: 'uc', label: '−15 % úspora' },
  { value: 'normal', label: 'Normálne' },
  { value: 'oc', label: '+15 % OC' },
];

export default function FarmScreen({ state: s, d, actions, goShop }) {
  const owned = Object.entries(s.rigs).filter(([, r]) => r.count > 0);
  const time = formatGameTime(s.time);
  const tempCol = tempColor(s.temp);
  const coolingPct = d.nominalLoad;
  const coolingColor = coolingPct > 1 ? C.red : coolingPct > 0.75 ? C.yellow : C.green;

  return (
    <ScrollView style={st.scroll} contentContainerStyle={st.content} showsVerticalScrollIndicator={false}>
      {/* ---------------- hlavička ---------------- */}
      <Card style={st.hero} accent={C.accent}>
        <View style={st.heroTop}>
          <View style={{ flex: 1 }}>
            <Text style={F.tiny}>HODNOTA FARMY</Text>
            <Text style={[F.big, { fontSize: 32, color: C.accent }]}>{formatEur(d.netWorth, 0)}</Text>
            <Text style={[F.tiny, { marginTop: 2 }]}>
              {formatEur(d.portfolioEur, 0)} likvidné · {formatEur(d.rigValue, 0)} v hardvéri
            </Text>
          </View>
          <View style={{ alignItems: 'flex-end' }}>
            <Text style={F.tiny}>{time.label}</Text>
            <Text style={[F.mono, { color: C.textDim, marginTop: 3 }]}>{formatNumber(Math.floor(s.height))}</Text>
            <Text style={F.tiny}>block height</Text>
          </View>
        </View>

        <View style={st.heroRow}>
          <Stat label="BTC peňaženka" value={formatBtc(s.btc, 6)} sub={formatSats(s.btc * 1e8)} color={C.accent} />
          <Stat label="Hotovosť" value={formatEur(s.eur, 0)} color={signColor(s.eur)} />
        </View>

        {/* rýchlosť hry */}
        <View style={st.speedRow}>
          <Segmented
            style={{ flex: 1 }}
            options={GAME.SPEEDS.map((x) => ({ value: x, label: `${x}×` }))}
            value={s.speed}
            onChange={(v) => actions.setSpeed(v)}
          />
          <Button small label={s.paused ? '▶' : '⏸'} variant="muted" onPress={actions.togglePause} style={{ width: 46 }} />
          <Button small label="+1 deň" variant="muted" onPress={actions.skipDay} style={{ width: 76 }} />
        </View>
        <Text style={[F.tiny, { marginTop: S.sm, textAlign: 'center' }]}>
          1 reálna sekunda = {formatDuration(GAME.BASE_TIME_SCALE * s.speed)} herného času
          {s.paused ? ' · PAUZNUTÉ' : ''}
        </Text>
      </Card>

      {/* ---------------- varovania ---------------- */}
      {s.autoShutdown ? (
        <Card style={[st.alert, { borderColor: C.red }]} accent={C.red}>
          <Text style={[F.h3, { color: C.red }]}>⛔ Odpojené od elektriny</Text>
          <Text style={[F.small, { marginTop: 4 }]}>
            Dlh {formatEur(d.debt, 0)} presiahol limit {formatEur(GAME.DEBT_LIMIT, 0)}. Predaj BTC alebo stroje —
            farma sa sama naštartuje pri likvidite nad {formatEur(GAME.RESTART_LIQUIDITY, 0)}.
          </Text>
          <View style={{ flexDirection: 'row', gap: S.sm, marginTop: S.md }}>
            {s.btc > 0 ? (
              <Button small label={`Predať všetko BTC (${formatEur(s.btc * s.price, 0)})`} variant="good" style={{ flex: 1 }} onPress={() => actions.sellBtc(s.btc)} />
            ) : null}
            <Button small label="Ísť do obchodu" variant="muted" style={{ flex: 1 }} onPress={goShop} />
          </View>
        </Card>
      ) : null}

      {d.curtail < 0.98 ? (
        <Card style={[st.alert, { borderColor: C.yellow }]} accent={C.yellow}>
          <Text style={[F.h3, { color: C.yellow }]}>🌡️ Tepelné obmedzenie — výkon na {(d.curtail * 100).toFixed(0)} %</Text>
          <Text style={[F.small, { marginTop: 4 }]}>
            Chladenie nestíha odvádzať {formatPower(d.heatKw * 1000)} tepla. Stroje samy znižujú výkon, aby sa
            nepoškodili. Kúp chladenie alebo vypni časť strojov.
          </Text>
        </Card>
      ) : null}

      {d.runwayDays < 5 && !s.autoShutdown && d.elecEurPerDay > 0 ? (
        <Card style={[st.alert, { borderColor: C.yellow }]} accent={C.yellow}>
          <Text style={[F.h3, { color: C.yellow }]}>💸 Dochádza hotovosť</Text>
          <Text style={[F.small, { marginTop: 4 }]}>
            Pri súčasnej spotrebe ti hotovosť vydrží {d.runwayDays.toFixed(1)} herného dňa.
            {s.settings.autoTreasury
              ? ' Treasury automaticky predá BTC, keď nebude na elektrinu.'
              : ' Zapni treasury auto-predaj na Trhu, alebo predaj BTC ručne.'}
          </Text>
        </Card>
      ) : null}

      {/* ---------------- výkonnostné metriky ---------------- */}
      <Section title="Ťažobný výkon">
        <Card>
          <View style={st.grid}>
            <Stat label="HASHRATE" value={formatHash(d.hashrate)} sub={`z ${formatHash(d.nominalHashrate)} nominálne`} color={C.accent} />
            <Stat label="PODIEL SIETE" value={`${(d.share * 100).toExponential(2)} %`} sub={`sieť ${formatHash(d.netHashrate)}`} />
            <Stat label="SPOTREBA" value={formatPower(d.watts)} sub={`${formatEnergy(d.kwhPerDay)} / deň`} />
            <Stat label="EFEKTIVITA" value={`${(d.efficiency * 100).toFixed(0)} %`} sub={`${d.temp.toFixed(0)} °C v hale`} color={tempCol} />
          </View>

          <View style={st.divider} />

          <Gauge
            value={coolingPct}
            label="VYŤAŽENIE CHLADENIA"
            left={`${formatPower(d.heatKw * 1000)} teplo`}
            right={`${formatPower(d.coolingKw * 1000)} kapacita`}
            color={coolingColor}
            markers={[0.75, 1]}
          />

          <View style={st.divider} />

          <Row label="Odmena za block" value={`${d.reward} BTC`} hint={`halving za ${formatDuration(d.secondsToHalving)}`} />
          <Row label="Difficulty" value={formatDifficulty(d.difficulty)} hint={`úprava za ${formatNumber(Math.ceil(d.blocksToDiffAdj))} bl.`} />
          <Row label="Hashprice" value={`${d.hashPriceEurPerThDay.toFixed(4)} €/TH/deň`} />
          <Row label="Cena elektriny" value={`${d.elecPrice.toFixed(4)} €/kWh`} hint={`${d.elecCostPerThDay.toFixed(4)} €/TH/deň`} />
        </Card>
      </Section>

      {/* ---------------- ekonomika ---------------- */}
      <Section title="Denná bilancia">
        <Card>
          <Row label="Hrubý príjem z ťažby" value={`${formatEur(d.grossEurPerDay, 2)}/deň`} valueColor={C.green} />
          <Row label="Elektrina" value={`−${formatEur(d.elecEurPerDay, 2)}/deň`} valueColor={C.red} />
          <View style={st.divider} />
          <Row label="Čistý zisk z ťažby" value={`${formatEur(d.netEurPerDay, 2)}/deň`} valueColor={signColor(d.netEurPerDay)} />
          <Row label="Peňažný tok do peňaženky" value={`${formatEur(d.cashFlowEurPerDay, 2)}/deň`} valueColor={signColor(d.cashFlowEurPerDay)} hint={`auto-predaj ${d.autoSellPct} %`} />
          <Row label="Vyťažené" value={`${formatBtc(d.btcPerDay, 8)}/deň`} valueColor={C.accent} />
          <View style={st.divider} />
          <Row label="Návratnosť hardvéru" value={isFinite(d.paybackDays) ? `${formatNumber(Math.round(d.paybackDays))} dní` : '—'} hint={isFinite(d.paybackDays) ? formatDuration(d.paybackDays * 86400) : ''} />
          <Row label="Marža" value={`${(d.margin * 100).toFixed(1)} %`} valueColor={signColor(d.margin)} />
        </Card>
      </Section>

      {/* ---------------- aktívne efekty ---------------- */}
      {s.effects.length ? (
        <Section title="Aktuálne udalosti">
          <View style={st.chips}>
            {s.effects.map((e) => (
              <Chip key={e.id + e.until} label={`${e.emoji} ${e.title} · ${formatDuration(e.until - s.time)}`} color={C.yellow} />
            ))}
          </View>
        </Section>
      ) : null}

      {/* ---------------- stroje ---------------- */}
      <Section
        title={`Tvoje stroje (${d.rigCount})`}
        right={
          owned.length ? (
            <View style={{ flexDirection: 'row', gap: S.sm }}>
              <Chip label="Všetko ZAP" color={C.green} onPress={() => actions.powerAll(true)} />
              <Chip label="Všetko VYP" color={C.red} onPress={() => actions.powerAll(false)} />
            </View>
          ) : null
        }
      >
        {owned.length === 0 ? (
          <Card>
            <Empty
              emoji="⛏️"
              title="Zatiaľ nemáš žiadny stroj"
              text="Bez hardvéru nič nevyťažíš. Choď do Obchodu a kúp si prvý ASIC. Pozor — nie každý stroj je ziskový: rozhodeje pomer J/TH a tvoja cena elektriny."
            />
            <Button label="Otvoriť obchod" onPress={goShop} />
          </Card>
        ) : (
          owned.map(([id, r]) => {
            const hw = HW_BY_ID[id];
            if (!hw) return null;
            const running = r.on && r.broken < r.count;
            return (
              <Card key={id} style={{ marginBottom: S.md }} accent={running ? C.green : C.textFaint}>
                <View style={st.rigHead}>
                  <Text style={{ fontSize: 22 }}>{hw.emoji}</Text>
                  <View style={{ flex: 1, marginLeft: S.sm }}>
                    <Text style={F.h3} numberOfLines={1}>
                      {hw.name} <Text style={{ color: C.textDim }}>×{r.count}</Text>
                    </Text>
                    <Text style={F.tiny} numberOfLines={1}>
                      {formatHash(hw.hash)} · {formatPower(hw.watts)} · {jPerTh(hw).toFixed(1)} J/TH
                      {r.broken > 0 ? ` · ${r.broken}× POKAZENÝ` : ''}
                    </Text>
                  </View>
                  <Pressable
                    onPress={() => actions.toggleRig(id)}
                    style={[st.switch, running ? st.switchOn : st.switchOff]}
                  >
                    <View style={[st.knob, running && st.knobOn]} />
                  </Pressable>
                </View>

                {r.broken > 0 ? (
                  <View style={st.repairRow}>
                    <Text style={[F.small, { flex: 1, color: C.red }]}>
                      🛠️ {r.broken}× nefunkčných — oprava {formatEur(r.broken * hw.price * GAME.REPAIR_RATIO, 0)}
                    </Text>
                    <Button small label="Opraviť" variant="danger" onPress={() => actions.repair(id)} />
                  </View>
                ) : null}

                <View style={{ marginTop: S.sm }}>
                  <Text style={[F.tiny, { marginBottom: 4 }]}>REŽIM ČIPOV</Text>
                  <Segmented options={MODES} value={r.mode || 'normal'} onChange={(m) => actions.setRigMode(id, m)} />
                </View>

                <View style={st.rigFoot}>
                  <Text style={[F.tiny, { flex: 1 }]}>
                    {running
                      ? `Prispieva ${formatHash(hw.hash * (r.count - r.broken) * (r.mode === 'oc' ? 1.15 : r.mode === 'uc' ? 0.85 : 1))}`
                      : r.broken >= r.count
                      ? 'Všetky kusy sú pokazené'
                      : 'Vypnuté — nič nespotrebováva ani neťaží'}
                  </Text>
                  <Chip
                    label={`Predať 1 ks (${formatEur(hw.price * GAME.SELLBACK_RATIO, 0)})`}
                    color={C.textDim}
                    onPress={() => actions.sellRig(id, 1)}
                  />
                </View>
              </Card>
            );
          })
        )}
      </Section>

      {/* ---------------- denník ---------------- */}
      <Section title="Denník farmy">
        <Card>
          {s.log.length === 0 ? (
            <Text style={F.small}>Zatiaľ sa nič nestalo.</Text>
          ) : (
            s.log.slice(0, 25).map((l, i) => (
              <View key={i} style={st.logRow}>
                <Text style={[F.tiny, { width: 62, color: C.textFaint }]}>{formatGameTime(l.t).short}</Text>
                <Text
                  style={[
                    F.small,
                    { flex: 1 },
                    l.kind === 'danger' && { color: C.red },
                    l.kind === 'good' && { color: C.green },
                    l.kind === 'halving' && { color: C.purple, fontWeight: '700' },
                    l.kind === 'warn' && { color: C.yellow },
                    l.kind === 'event' && { color: C.text },
                  ]}
                >
                  {l.text}
                </Text>
              </View>
            ))
          )}
        </Card>
      </Section>
    </ScrollView>
  );
}

const st = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: C.bg },
  content: { padding: S.lg, paddingBottom: S.xxl, gap: S.lg },
  hero: { backgroundColor: C.cardHi },
  heroTop: { flexDirection: 'row', alignItems: 'flex-start' },
  heroRow: { flexDirection: 'row', gap: S.xl, marginTop: S.lg },
  speedRow: { flexDirection: 'row', gap: S.sm, marginTop: S.lg, alignItems: 'center' },
  alert: { backgroundColor: 'rgba(255,197,61,0.06)' },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: S.lg },
  divider: { height: 1, backgroundColor: C.border, marginVertical: S.md },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: S.sm },
  rigHead: { flexDirection: 'row', alignItems: 'center' },
  rigFoot: { flexDirection: 'row', alignItems: 'center', gap: S.sm, marginTop: S.md },
  repairRow: { flexDirection: 'row', alignItems: 'center', gap: S.sm, marginTop: S.md, backgroundColor: C.redDim, padding: S.sm, borderRadius: R.sm },
  switch: { width: 46, height: 27, borderRadius: 99, padding: 3, justifyContent: 'center' },
  switchOn: { backgroundColor: C.green },
  switchOff: { backgroundColor: C.borderHi },
  knob: { width: 21, height: 21, borderRadius: 99, backgroundColor: '#fff' },
  knobOn: { alignSelf: 'flex-end' },
});
