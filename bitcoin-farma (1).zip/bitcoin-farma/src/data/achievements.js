/**
 * Achievements. `check(s, ctx)` dostane stav hry a odvodené metriky.
 */

export const ACHIEVEMENTS = [
  { id: 'first-rig', emoji: '📦', name: 'Prvý stroj', desc: 'Kúp si prvý ASIC.', check: (s) => totalRigs(s) >= 1 },
  { id: 'ten-rigs', emoji: '🏗️', name: 'Malá farma', desc: 'Vlastni 10 strojov.', check: (s) => totalRigs(s) >= 10 },
  { id: 'fifty-rigs', emoji: '🏭', name: 'Priemyselná hala', desc: 'Vlastni 50 strojov.', check: (s) => totalRigs(s) >= 50 },
  { id: 'one-ph', emoji: '⚡', name: 'Jeden petahash', desc: 'Dosiahni 1 PH/s.', check: (_s, c) => c.hashrate >= 1e15 },
  { id: 'ten-ph', emoji: '🚀', name: 'Desať petahashov', desc: 'Dosiahni 10 PH/s.', check: (_s, c) => c.hashrate >= 1e16 },
  { id: 'first-btc', emoji: '🪙', name: 'Prvý satoshi', desc: 'Vyťaž svoj prvý bitcoinový zlomok.', check: (s) => s.stats.btcMined > 0 },
  { id: 'one-btc', emoji: '₿', name: 'Celý bitcoin', desc: 'Nazbieraj 1 BTC.', check: (s) => s.btc + s.stats.btcSold >= 1 },
  { id: 'halving', emoji: '✂️', name: 'Prežil si halving', desc: 'Zaži halving na vlastnej koži.', check: (s) => s.stats.halvingsSeen >= 1 },
  { id: 'two-halvings', emoji: '✂️', name: 'Veterán dvoch epoch', desc: 'Zaži dva halvingy.', check: (s) => s.stats.halvingsSeen >= 2 },
  { id: 'sold', emoji: '💶', name: 'Realizovaný zisk', desc: 'Predaj BTC za viac ako 10 000 €.', check: (s) => s.stats.eurFromSales >= 10000 },
  { id: 'rich', emoji: '🤑', name: 'Veľryba v zárodku', desc: 'Majetok nad 100 000 €.', check: (_s, c) => c.totalValue >= 100000 },
  { id: 'million', emoji: '👑', name: 'Miliónová farma', desc: 'Majetok nad 1 000 000 €.', check: (_s, c) => c.totalValue >= 1000000 },
  { id: 'green', emoji: '🌱', name: 'Zelená farma', desc: 'Kúp solárnu strechu.', check: (s) => !!s.upgrades.solar },
  { id: 'fully-upgraded', emoji: '🏆', name: 'Plne vybavené', desc: 'Kúp všetky vylepšenia.', check: (_s, c) => c.allUpgrades },
  { id: 'survivor', emoji: '🛠️', name: 'Survivor', desc: 'Zaži 10 porúch a oprav ich.', check: (s) => s.stats.breakdowns >= 10 },
  { id: 'year', emoji: '📅', name: 'Rok v baní', desc: 'Hraj jeden herný rok.', check: (s) => s.time >= 365 * 86400 },
];

function totalRigs(s) {
  return Object.values(s.rigs).reduce((a, r) => a + (r.count || 0), 0);
}
