/**
 * Krátke vzdelávacie „karty“ — odomykajú sa podľa progresu hráča.
 * Každá má `unlock(state)` vrátené booleanom.
 */

export const LESSONS = [
  {
    id: 'what-is-mining',
    emoji: '⛏️',
    title: 'Čo vlastne robí miner?',
    text: 'Mineri hádžu hashovacou funkciou SHA-256 miliardy pokusov za sekundu a hľadajú číslo (nonce), ktoré spolu s hlavičkou blocku dá hash menší ako stanovený cieľ. Kto ho nájde prvý, pripíše si block a odmenu.',
    fact: 'SHA-256 je jednosmerná funkcia — neexistuje skratka, len skúšanie.',
  },
  {
    id: 'difficulty',
    emoji: '🎚️',
    title: 'Difficulty',
    text: 'Difficulty určuje, aký ťažké je nájsť platný hash. Sieť ju upraví každých 2016 blockov tak, aby priemerný čas medzi blockmi ostal 10 minút — bez ohľadu na to, koľko hashrate pribudlo.',
    fact: 'Vzťah: hashrate siete ≈ difficulty × 2³² ÷ 600 s.',
  },
  {
    id: 'halving',
    emoji: '✂️',
    title: 'Halving',
    text: 'Každých 210 000 blockov sa odmena za block zníži na polovicu: 50 → 25 → 12,5 → 6,25 → 3,125 → 1,5625 BTC. Preto bude existovať maximálne 21 miliónov BTC (posledný sa vyťaží okolo roku 2140).',
    fact: 'Po roku 2140 budú mineri žiť len z poplatkov za transakcie.',
  },
  {
    id: 'hashprice',
    emoji: '💰',
    title: 'Hashprice',
    text: 'Hashprice je výnos za jednotku hashrate za deň, zvyčajne v € za TH/s/deň. Je to jediné číslo, ktoré rozhoduje, či sa ťažba oplatí.',
    fact: 'Vzťah: tvoj denný BTC = (tvoj hashrate ÷ hashrate siete) × odmena × 144 blockov.',
  },
  {
    id: 'electricity',
    emoji: '⚡',
    title: 'Elektrina je všetko',
    text: 'Typicky 60–90 % prevádzkových nákladov miningu je elektrina. Preto farmy stoja tam, kde je energia najlacnejšia: pri priehradách, sopkách, v horúcich púštnych elektrárňach alebo pri spaľovaní plynu z vrtov.',
    fact: 'Rozdiel 0,05 €/kWh dokáže urobiť zo stratovej farmy ziskovú.',
  },
  {
    id: 'jth',
    emoji: '🌡️',
    title: 'J/TH — efektivita čipu',
    text: 'Joule na terahash udáva, koľko energie stroj minie na jednotku výpočtového výkonu. Nižšie je lepšie. Za desať rokov klesla efektivita ASIC-ov z ~1000 J/TH na ~13 J/TH.',
    fact: 'Pokles o ~75-násobok za dekádu — preto sú staré stroje šrot.',
  },
  {
    id: 'pool',
    emoji: '👥',
    title: 'Mining pool',
    text: 'Sólo ťažba je pri dnešnej difficulty lotéria — aj s 100 TH/s by si čakal na block roky. Pool združuje hashrate tisícov minerov a výnos delí podľa odvedenej práce, za poplatok 0,5–2 %.',
    fact: 'Najväčšie pooly kontrolujú desiatky percent celosvetového hashrate — preto sa hovorí o centralizácii.',
  },
  {
    id: 'luck',
    emoji: '🎲',
    title: 'Pool luck',
    text: 'Nájdenie blocku je náhodný proces. Pool môže mať smolu (blocky padajú neskôr, než štatistika čaká) alebo šťastie. V dlhom horizonte sa to vyruší, v krátkom nie.',
    fact: 'Rozdelenie času medzi blockmi je exponenciálne — nie normálne.',
  },
  {
    id: 'sats',
    emoji: '🔢',
    title: 'Satoshi',
    text: 'Jeden bitcoin sa delí na 100 000 000 satoshi (sats). Je to najmenšia jednotka v protokole. Bežne sa účtuje v sats, pretože BTC sumy sú neprakticky malé.',
    fact: '1 BTC = 100 000 000 sats. „Stacking sats“ je slang pre postupné dokupovanie.',
  },
  {
    id: 'energy-mix',
    emoji: '🌍',
    title: 'Energetický mix',
    text: 'Odhady podielu obnoviteľných zdrojov v bitcoinovej ťažbe sa pohybujú zhruba medzi 40 a 60 %. Mining zároveň spotrebúva globálne menej energie než napr. klimatizácie alebo Vianoce v USA.',
    fact: 'Mineri sú jediný veľký odberateľ, ktorý vie svoju spotrebu vypnúť v priebehu sekúnd.',
  },
  {
    id: 'asic-resistance',
    emoji: '🧱',
    title: 'Prečo SHA-256 a ASIC-y',
    text: 'Bitcoin používa SHA-256, ktorý sa dal efektívne implementovať v kremíku. Iné kryptomeny volia „ASIC-resistant“ algoritmy (napr. memory-hard), ale ASIC-y ich väčšinou časom dobehli.',
    fact: 'CPU → GPU → FPGA → ASIC: rovnaká cesta, akou prešiel aj Bitcoin v rokoch 2009–2013.',
  },
  {
    id: 'not-investment',
    emoji: '⚠️',
    title: 'Toto nie je investičné poradenstvo',
    text: 'Táto aplikácia je vzdelávacia simulácia. Ceny, udalosti aj „výnosy“ sú generované alebo historicky inšpirované. Reálny mining aj reálne kryptomeny nesú riziko straty celého vkladu.',
    fact: 'Nikdy nevkladaj peniaze, o ktoré nemôžeš prísť.',
  },
];
