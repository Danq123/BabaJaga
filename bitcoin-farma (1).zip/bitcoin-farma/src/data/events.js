/**
 * Náhodné a skriptované udalosti.
 *
 * duration  – 0 = okamžitý/permamentný efekt, inak dĺžka trvania v herných sekundách
 * mods      – dočasné multiplikátory, kým udalosť trvá
 * instant   – efekty aplikované raz, v momente vyhodnotenia udalosti
 */

const DAY = 86400;
const HOUR = 3600;

export const EVENTS = [
  {
    id: 'heatwave',
    title: 'Vlna horúčav',
    emoji: '🥵',
    weight: 10,
    duration: 3 * DAY,
    mods: { ambientAdd: 9, coolingMult: 0.75 },
    text: 'Teplomery ukazujú 38 °C. Chladenie nestíha, stroje sa dusia.',
    lesson: 'Ambientná teplota priamo znižuje efektivitu chladenia — farmy sa preto stavajú v chladných krajinách.',
  },
  {
    id: 'winter',
    title: 'Mrazivá zima',
    emoji: '❄️',
    weight: 8,
    duration: 4 * DAY,
    mods: { ambientAdd: -8, coolingMult: 1.25 },
    text: 'Mráz. Chladenie má rezervu a stroje bežia efektívnejšie než inokedy.',
    lesson: 'Prebytočné teplo z miningu sa v chladných krajinách predáva do teplární.',
  },
  {
    id: 'blackout',
    title: 'Výpadok rozvodnej siete',
    emoji: '🔌',
    weight: 7,
    duration: 14 * HOUR,
    mods: { miningMult: 0 },
    text: 'Distribútor odstavil trať. Bez UPS stojíš, s UPS ťažíš ďalej.',
    lesson: 'Mineri sú v sieťach „prerušiteľná záťaž“ — za poplatok ich distribútor môže kedykoľvek odpojiť.',
  },
  {
    id: 'newasic',
    title: 'Nová generácia ASIC-ov',
    emoji: '🆕',
    weight: 9,
    instant: { difficultyMult: 1.14 },
    duration: 0,
    text: 'Výrobca vydal o 40 % efektívnejšie stroje. Celá sieť okamžite zosilnela.',
    lesson: 'Difficulty rastie, keď do siete pribudne hashrate. Tvoj podiel klesá, aj keď sa u teba nič nezmení.',
  },
  {
    id: 'ban',
    title: 'Veľká krajina zakázala mining',
    emoji: '🚫',
    weight: 6,
    instant: { difficultyMult: 0.86, priceMult: 0.94 },
    duration: 0,
    text: 'Regulátor vyhnal ťažiarov z regiónu. Sieť dočasne oslabla, cena zareagovala.',
    lesson: 'V roku 2021 Čína zakázala mining a hashrate siete klesol o viac ako polovicu — potom sa presunul inde.',
  },
  {
    id: 'etf',
    title: 'Prílev peňazí do BTC ETF',
    emoji: '📈',
    weight: 9,
    instant: { priceMult: 1.11 },
    duration: 0,
    text: 'Inštitucionálni investori nakúpili. Cena skočila hore.',
    lesson: 'Cenu bitcoinu neurčuje ťažba, ale ponuka a dopyt na trhu. Mineri sú len cenoví príjemcovia.',
  },
  {
    id: 'exchangehack',
    title: 'Hack burzy',
    emoji: '🚨',
    weight: 6,
    instant: { priceMult: 0.87 },
    duration: 0,
    text: 'Burza prišla o prostriedky klientov. Trh spanikáril.',
    lesson: '„Not your keys, not your coins.“ Vlastná úschova znamená vlastný privátny kľúč.',
  },
  {
    id: 'elecprice',
    title: 'Cena elektriny rastie',
    emoji: '💡',
    weight: 8,
    duration: 6 * DAY,
    mods: { elecMult: 1.6 },
    text: 'Energetická kríza. Dodávateľ zdvihol sadzbu o 60 %.',
    lesson: 'Hashprice môže klesnúť pod tvoje náklady — vtedy je správne stroje vypnúť, nie ťažiť do straty.',
  },
  {
    id: 'subsidy',
    title: 'Dotácia na zelenú energiu',
    emoji: '🌱',
    weight: 5,
    duration: 45 * DAY,
    mods: { elecMult: 0.8 },
    text: 'Štát prispel na obnoviteľné zdroje. Na 45 dní platíš za elektrinu o 20 % menej.',
    lesson: 'Mineri dokážu stabilizovať sieť s OZE — ťažia, keď je prebytok, a vypnú, keď je nedostatok.',
  },
  {
    id: 'memefrenzy',
    title: 'Býčí trh',
    emoji: '🐂',
    weight: 7,
    duration: 5 * DAY,
    instant: { priceMult: 1.06 },
    mods: { priceVolMult: 1.8 },
    text: 'Sociálne siete šalejú, volatilita je extrémna. Drž sa.',
    lesson: 'Volatilita bitcoinu je štrukturálna — trh je malý a bez centrálneho tvorcu ceny.',
  },
  {
    id: 'bearish',
    title: 'Medvedí sentiment',
    emoji: '🐻',
    weight: 7,
    duration: 5 * DAY,
    instant: { priceMult: 0.93 },
    mods: { priceVolMult: 1.5 },
    text: 'Makrodáta sklamali, trh padá.',
    lesson: 'Po každom veľkom raste nasleduje korekcia. Cykly sú súčasťou trhu, nie anomália.',
  },
  {
    id: 'fleamarket',
    title: 'Výpredaj z krachu farmy',
    emoji: '🏷️',
    weight: 6,
    duration: 2 * DAY,
    mods: { shopDiscount: 0.3 },
    text: 'Konkurent zbankrotoval a vypredáva stroje. V obchode máš 30 % zľavu.',
    lesson: 'Keď hashprice padne, slabí mineri predávajú hardvér — pre silných je to príležitosť.',
  },
  {
    id: 'pooloutage',
    title: 'Výpadok poolu',
    emoji: '📴',
    weight: 5,
    duration: 10 * HOUR,
    mods: { miningMult: 0.25 },
    text: 'Tvoj mining pool má výpadok stratum servera. Ťažíš len štvrťinovo.',
    lesson: 'Pool centralizuje výplatu odmien. Výpadok poolu neznamená výpadok blockchainu.',
  },
  {
    id: 'dust',
    title: 'Prach na chladičoch',
    emoji: '🧹',
    weight: 6,
    duration: 4 * DAY,
    mods: { coolingMult: 0.8 },
    text: 'Filtre sú zanesené. Chladenie stráca účinnosť, kým ich nevyčistíš.',
    lesson: 'Údržba je v miningu reálna prevádzková položka, nie detail.',
  },
];

export const HALVING_EVENT = {
  id: 'halving',
  title: 'HALVING!',
  emoji: '🎉',
  text: 'Block reward sa znížil na polovicu. Príjem z ťažby klesol okamžite o 50 %.',
  lesson:
    'Halving je naprogramovaný každých 210 000 blockov (~4 roky). Znižuje novú ponuku BTC a je dôvodom, prečo je ich max. 21 miliónov.',
};

export const DIFF_ADJUST_EVENT = {
  id: 'diffadjust',
  title: 'Úprava difficulty',
  emoji: '🎚️',
  text: 'Sieť upravila difficulty podľa skutočnej rýchlosti ťažby.',
  lesson:
    'Každých 2016 blockov (~2 týždne) sieť prepočíta difficulty tak, aby block padol v priemere každých 10 minút.',
};
