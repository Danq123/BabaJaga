/**
 * Katalóg ťažobného hardvéru.
 *
 * hash  – hashrate v H/s
 * watts – spotreba vo W
 * heat  – tepelný výkon v kW (koľko musí farma uchladiť)
 * eff   – J/TH, len informatívne pre UI (efektivita)
 * fail  – relatívna poruchovosť (1 = bežná)
 *
 * Ceny aj spotreby sú inšpirované reálnymi ASIC generáciami, názvy sú vymyslené.
 */

export const HARDWARE = [
  {
    id: 'stick',
    name: 'BlockStick USB',
    emoji: '🔌',
    hash: 0.03e12,
    watts: 5,
    heat: 0.005,
    price: 25,
    fail: 0.4,
    tier: 0,
    desc: 'Hračka na stôl. Reálne ťaží menej, ako minie za elektrinu — slúži ako učebná pomôcka.',
    lesson: 'Hashrate sám o sebe nič neznamená. Rozhoduje pomer J/TH a cena elektriny.',
  },
  {
    id: 's9',
    name: 'HashMaster S9 (bazár)',
    emoji: '📦',
    hash: 14e12,
    watts: 1350,
    heat: 1.35,
    price: 120,
    fail: 2.2,
    tier: 1,
    desc: 'Legenda z roku 2016. Lacná, ale 96 J/TH — pri dnešnej difficulty väčšinou v mínuse.',
    lesson: 'Staré ASIC-y po halvingu zvyčajne prestanú byť ziskové a končia ako šrot.',
  },
  {
    id: 't19',
    name: 'VoltCore T19',
    emoji: '🖨️',
    hash: 84e12,
    watts: 3150,
    heat: 3.15,
    price: 780,
    fail: 1.3,
    tier: 2,
    desc: 'Rozumný vstup do vážnejšej ťažby. 37 J/TH, hlučný ako vysávač.',
    lesson: 'Hluk a odpadové teplo sú reálne náklady farmy, nielen elektrina.',
  },
  {
    id: 'x19',
    name: 'VoltCore X19 Pro',
    emoji: '⚙️',
    hash: 141e12,
    watts: 3010,
    heat: 3.0,
    price: 1650,
    fail: 1.0,
    tier: 3,
    desc: 'Pracant strednej triedy. 21 J/TH, dobrý pomer cena/výkon.',
    lesson: 'Novšia generácia má často MENŠIU spotrebu a VÄČŠÍ hashrate ako staršia.',
  },
  {
    id: 'm60',
    name: 'NovaRig M60 Hydro',
    emoji: '💧',
    hash: 335e12,
    watts: 5360,
    heat: 2.4,
    price: 4200,
    fail: 0.7,
    tier: 4,
    desc: 'Vodné chladenie = menej hluku, menej tepla do vzduchu, vyššia životnosť. 16 J/TH.',
    lesson: 'Hydro/immersion stroje majú nižšie tepelné straty a menšiu poruchovosť.',
  },
  {
    id: 'q100',
    name: 'Quantum X100',
    emoji: '🛢️',
    hash: 500e12,
    watts: 7250,
    heat: 2.2,
    price: 8500,
    fail: 0.6,
    tier: 5,
    desc: 'Ponorné chladenie v oleji. 14,5 J/TH a takmer nulový hluk.',
    lesson: 'Ponorné chladenie dokáže recyklovať teplo — napríklad na vykurovanie budov.',
  },
  {
    id: 'z1',
    name: 'TitanHash Z1',
    emoji: '🏭',
    hash: 1200e12,
    watts: 15600,
    heat: 3.9,
    price: 26000,
    fail: 0.5,
    tier: 6,
    desc: 'Najnovšia generácia. 13 J/TH. Potrebuje poriadny rozvod a chladenie.',
    lesson: 'Najefektívnejšie stroje sveta sa vyrábajú v obmedzených sériách a sú okamžite vypredané.',
  },
];

export const HW_BY_ID = Object.fromEntries(HARDWARE.map((h) => [h.id, h]));

export function jPerTh(hw) {
  if (!hw || !hw.hash) return 0;
  return hw.watts / (hw.hash / 1e12);
}
