/** Formátovanie čísel pre UI. Čisté JS, žiadne závislosti. */

const HASH_UNITS = ['H/s', 'kH/s', 'MH/s', 'GH/s', 'TH/s', 'PH/s', 'EH/s', 'ZH/s'];

export function formatHash(hps) {
  if (!isFinite(hps) || hps <= 0) return '0 H/s';
  const i = Math.min(Math.floor(Math.log10(hps) / 3), HASH_UNITS.length - 1);
  const v = hps / Math.pow(1000, i);
  return `${v >= 100 ? v.toFixed(0) : v >= 10 ? v.toFixed(1) : v.toFixed(2)} ${HASH_UNITS[i]}`;
}

export function formatDifficulty(d) {
  if (!isFinite(d) || d <= 0) return '0';
  const units = [
    [1e12, 'T'],
    [1e9, 'G'],
    [1e6, 'M'],
  ];
  for (const [div, suf] of units) {
    if (d >= div) return `${(d / div).toFixed(2)} ${suf}`;
  }
  return d.toFixed(0);
}

export function formatEur(v, digits) {
  const n = Number(v) || 0;
  const abs = Math.abs(n);
  const d = digits !== undefined ? digits : abs >= 10000 ? 0 : abs >= 100 ? 1 : 2;
  const s = n.toLocaleString('sk-SK', { minimumFractionDigits: d, maximumFractionDigits: d });
  return `${s} €`;
}

export function formatBtc(v, digits = 8) {
  const n = Number(v) || 0;
  if (n === 0) return '0 BTC';
  const abs = Math.abs(n);
  let d = digits;
  if (abs >= 1) d = 4;
  else if (abs >= 0.01) d = 5;
  else if (abs >= 0.0001) d = 6;
  return `${n.toFixed(d)} BTC`;
}

export function formatSats(v) {
  const n = Math.round(Number(v) || 0);
  return `${n.toLocaleString('sk-SK')} sats`;
}

export function formatNumber(v, digits = 0) {
  const n = Number(v) || 0;
  return n.toLocaleString('sk-SK', { minimumFractionDigits: digits, maximumFractionDigits: digits });
}

export function formatPercent(v, digits = 1) {
  const n = Number(v) || 0;
  return `${n >= 0 ? '+' : ''}${n.toFixed(digits)} %`;
}

export function formatPower(w) {
  if (w >= 1e6) return `${(w / 1e6).toFixed(2)} MW`;
  if (w >= 1000) return `${(w / 1000).toFixed(2)} kW`;
  return `${Math.round(w)} W`;
}

export function formatEnergy(kwh) {
  if (kwh >= 1e6) return `${(kwh / 1e6).toFixed(2)} GWh`;
  if (kwh >= 1000) return `${(kwh / 1000).toFixed(1)} MWh`;
  return `${kwh.toFixed(1)} kWh`;
}

/** Herný čas (sekundy od štartu hry) -> "Rok 3, deň 214, 07:00" */
export function formatGameTime(gameSeconds) {
  const s = Math.max(0, Math.floor(gameSeconds));
  const day = Math.floor(s / 86400);
  const year = Math.floor(day / 365) + 1;
  const dayOfYear = (day % 365) + 1;
  const hh = Math.floor((s % 86400) / 3600);
  const mm = Math.floor((s % 3600) / 60);
  return {
    year,
    dayOfYear,
    day,
    clock: `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`,
    label: `Rok ${year}, deň ${dayOfYear} · ${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`,
    short: `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`,
  };
}

/** Zvyšný čas do udalosti v herných sekundách -> "2 d 4 h" */
export function formatDuration(gameSeconds) {
  const s = Math.max(0, Math.floor(gameSeconds));
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (d > 0) return `${d} d ${h} h`;
  if (h > 0) return `${h} h ${m} min`;
  return `${m} min`;
}
