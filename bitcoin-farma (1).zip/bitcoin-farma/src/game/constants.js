/**
 * Vyvažovacie konštanty hry. Všetko je tu, aby sa hra dala ľahko doladiť.
 *
 * Dôležité: engine používa REÁLNE vzorce bitcoinového miningu
 *   networkHashrate = difficulty * 2^32 / 600
 *   podiel na blocku = tvojHashrate / networkHashrate
 * ale sieť je pre hrateľnosť zmenšená faktorom NETWORK_SCALE.
 */

export const GAME = {
  // --- Čas ---
  // 1 reálna sekunda = BASE_TIME_SCALE herných sekúnd (3600 => 1 reálna s = 1 herná hodina)
  BASE_TIME_SCALE: 3600,
  SPEEDS: [1, 4, 16],
  DEFAULT_SPEED: 4,
  TICK_MS: 1000,
  // najväčší krok simulácie (v herných sekundách) — 600 s = 1 block
  MAX_STEP: 600,
  // koľko herného času sa maximálne dosimuluje, kým bola appka zavretá
  MAX_OFFLINE_GAME_SECONDS: 3 * 86400,

  // --- Blockchain ---
  BLOCK_TIME: 600, // 10 minút, v sekundách
  HALVING_BLOCKS: 210_000,
  DIFFICULTY_ADJUST_BLOCKS: 2016,
  GENESIS_REWARD: 50,
  START_HEIGHT: 1_020_000, // ~30 000 blockov do ďalšieho halvingu
  START_DIFFICULTY: 3.25e13, // reálne ~130 T, zmenšené o NETWORK_SCALE
  NETWORK_SCALE: 0.25,
  // dlhodobý rast difficulty (na jedno obdobie úpravy = 2016 blockov ≈ 14 dní)
  DIFFICULTY_GROWTH_PER_ERA: 0.006,
  DIFFICULTY_NOISE: 0.02,
  // časová konštanta, s akou sa dočasný šok difficulty vracia k 1 (30 dní)
  DIFFICULTY_SHOCK_TAU: 30 * 86400,

  // Ťažba v pool-e: poplatok a rozptyl šťastia poolu
  POOL_FEE: 0.02,
  POOL_LUCK_SIGMA: 0.06,

  // --- Ekonomika ---
  START_EUR: 2000,
  START_BTC: 0,
  START_PRICE_EUR: 85_000,
  ELEC_PRICE: 0.08, // €/kWh — vlastná garážová sadzba
  AMBIENT_C: 22,
  COOLING_BASE_KW: 35, // základné chladenie (garáž s vetrákmi)
  SELLBACK_RATIO: 0.55, // za koľko predáš použitý stroj
  REPAIR_RATIO: 0.1, // oprava = 10 % obstarávacej ceny za kus

  // --- Cena BTC (simulovaný trh) ---
  // Cena = dlhodobý trend × 4-ročný cyklus (sinusoida) × šum, s návratom k „férovej“ hodnote.
  PRICE_SIGMA: 0.9, // ročná volatilita šumu okolo cyklu
  PRICE_DRIFT: 0.05, // dlhodobý ročný trend
  PRICE_REVERSION: 6, // sila návratu šumu k nule (polčas ~6 týždňov)
  PRICE_NOISE_CLAMP: 0.8, // max. odchýlka od cyklu v log. vyjadrení (±2,2×)
  PRICE_CYCLE_AMP: 0.5, // amplitúda 4-ročného cyklu (±50 %)
  PRICE_CYCLE_PEAK_PHASE: 0.35, // vrchol cyklu ako podiel periody od halvingu
  PRICE_SHOCK_TAU: 3 * 86400, // ako rýchlo sa jednorazový cenový šok vytratí (3 dni)
  PRICE_HISTORY: 160,

  // --- Teplota / poruchy ---
  TEMP_PER_LOAD: 30, // °C nad ambient pri 100 % vyťažení chladenia
  TEMP_SAFE_C: 45, // do tejto teploty žiadna strata výkonu
  TEMP_EFF_LOSS: 0.012, // strata efektívnosti na °C nad TEMP_SAFE_C
  TEMP_MIN_EFF: 0.5,
  TEMP_WARN_C: 58, // UI varovanie
  TEMP_CRITICAL_C: 70, // tepelná ochrana: stroje sa samy odpoja, kým nevychladnú
  TEMP_RESUME_C: 52, // pod túto teplotu sa stroje samy znova naštartujú
  FAILURE_RATE_PER_DAY: 0.0015,

  // --- Dlh a núdzové odstavenie ---
  // dokedy môžeš byť v mínuse, kým ti dodávateľ odpojí elektrinu
  DEBT_LIMIT: 5000,
  // nad akú likviditu (EUR + BTC) sa farma po odpojení sama naštartuje
  RESTART_LIQUIDITY: 500,

  // --- Udalosti ---
  EVENT_CHANCE_PER_DAY: 0.12, // ~jedna udalosť za 8 herných dní
  LOG_LIMIT: 80,
};

export const SATS_PER_BTC = 100_000_000;
