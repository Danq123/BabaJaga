/**
 * Živý kurz BTC z verejného API (CoinGecko). Nepovinná funkcia —
 * hra beží plne offline na simulovanom trhu.
 */

const URL = 'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=eur,usd';

/**
 * @returns {Promise<{eur:number, usd:number, at:number}|null>}
 */
export async function fetchLivePrice(timeoutMs = 8000) {
  const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = controller ? setTimeout(() => controller.abort(), timeoutMs) : null;
  try {
    const res = await fetch(URL, controller ? { signal: controller.signal } : undefined);
    if (!res.ok) return null;
    const json = await res.json();
    const eur = Number(json?.bitcoin?.eur);
    const usd = Number(json?.bitcoin?.usd);
    if (!isFinite(eur) || eur <= 0) return null;
    return { eur, usd: isFinite(usd) ? usd : null, at: Date.now() };
  } catch (e) {
    return null;
  } finally {
    if (timer) clearTimeout(timer);
  }
}
