import { useCallback, useEffect, useReducer, useRef, useState } from 'react';
import { AppState } from 'react-native';

import * as E from './engine.js';
import { GAME } from './constants.js';
import { loadSave, persistSave, clearSave } from '../lib/storage.js';
import { fetchLivePrice } from './price.js';

const SAVE_INTERVAL_MS = 8000;

/**
 * Most medzi čistým herným enginom (mutovateľný stav) a Reactom.
 * Engine mutuje `stateRef.current`; tento hook len žiada prekreslenie.
 */
export function useGame() {
  const stateRef = useRef(null);
  const [, bump] = useReducer((x) => x + 1, 0);
  const [ready, setReady] = useState(false);
  const [offline, setOffline] = useState(null);
  const [toasts, setToasts] = useState([]);
  const [liveInfo, setLiveInfo] = useState({ status: 'idle', at: null, usd: null });
  const lastTickRef = useRef(Date.now());
  const lastSaveRef = useRef(Date.now());

  /* ------------------------- inicializácia ------------------------- */
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const saved = await loadSave();
      if (cancelled) return;
      let s;
      let report = null;
      if (saved) {
        s = saved;
        // migrácia/doplnenie chýbajúcich polí
        s.settings = s.settings || { elecPrice: GAME.ELEC_PRICE, ambient: GAME.AMBIENT_C };
        if (s.settings.autoSellPct === undefined) s.settings.autoSellPct = 0;
        if (s.settings.autoTreasury === undefined) s.settings.autoTreasury = true;
        if (s.curtail === undefined) s.curtail = 1;
        if (s.thermalState === undefined) s.thermalState = 'ok';
        if (s.effects === undefined) s.effects = [];
        if (s.priceBase === undefined) s.priceBase = s.price;
        if (s.priceNoise === undefined) s.priceNoise = 0;
        if (s.difficultyTrend === undefined) s.difficultyTrend = s.difficulty;
        if (s.difficultyShock === undefined) s.difficultyShock = 1;
        if (s.priceShock === undefined) s.priceShock = 1;
        report = E.applyOfflineProgress(s, Date.now());
      } else {
        s = E.createState();
        E.pushLog(s, '👋 Vitaj vo svojej bitcoinovej farme. Začni v Obchode — kúp si prvý stroj.', 'good');
      }
      s.savedAt = Date.now();
      stateRef.current = s;
      if (report && report.offlineGameSeconds > 60) setOffline(report);
      setReady(true);
      bump();
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  /* ------------------------- herná slučka ------------------------- */
  useEffect(() => {
    if (!ready) return undefined;
    const id = setInterval(() => {
      const s = stateRef.current;
      if (!s) return;
      const now = Date.now();
      const elapsedReal = Math.min(5, (now - lastTickRef.current) / 1000);
      lastTickRef.current = now;

      E.advance(s, elapsedReal);

      const unlocked = E.checkAchievements(s);
      if (unlocked.length) {
        setToasts((t) => [
          ...t,
          ...unlocked.map((a) => ({ kind: 'achievement', title: `${a.emoji} ${a.name}`, text: a.desc })),
        ]);
      }

      if (now - lastSaveRef.current > SAVE_INTERVAL_MS) {
        lastSaveRef.current = now;
        s.savedAt = now;
        persistSave(s);
      }
      bump();
    }, GAME.TICK_MS);
    return () => clearInterval(id);
  }, [ready]);

  /* ---------------- uloženie pri prechode na pozadie ---------------- */
  useEffect(() => {
    if (!ready) return undefined;
    const sub = AppState.addEventListener('change', (next) => {
      const s = stateRef.current;
      if (!s) return;
      if (next !== 'active') {
        s.savedAt = Date.now();
        lastTickRef.current = Date.now();
        persistSave(s);
      } else {
        // po návrate z pozadia dosimuluj uplynutý čas
        const report = E.applyOfflineProgress(s, Date.now());
        lastTickRef.current = Date.now();
        if (report.offlineGameSeconds > 60) setOffline(report);
        bump();
      }
    });
    return () => sub.remove();
  }, [ready]);

  /* ------------------------- živý kurz ------------------------- */
  const refreshPrice = useCallback(async () => {
    setLiveInfo((i) => ({ ...i, status: 'loading' }));
    const res = await fetchLivePrice();
    const s = stateRef.current;
    if (res && s) {
      s.livePrice = res.eur;
      s.priceMode = 'live';
      setLiveInfo({ status: 'ok', at: res.at, usd: res.usd });
      E.pushLog(s, `🌐 Načítaný živý kurz BTC: ${Math.round(res.eur).toLocaleString('sk-SK')} €`, 'info');
    } else {
      setLiveInfo((i) => ({ ...i, status: 'error' }));
    }
    bump();
    return !!res;
  }, []);

  /* ------------------------- akcie ------------------------- */
  const act = useCallback((fn) => {
    const s = stateRef.current;
    if (!s) return { ok: false, reason: 'Hra ešte nie je načítaná.' };
    const res = fn(s) || { ok: true };
    E.checkAchievements(s);
    bump();
    return res;
  }, []);

  const actions = {
    buyRig: (hwId, qty) => act((s) => E.buyRig(s, hwId, qty)),
    sellRig: (hwId, qty) => act((s) => E.sellRig(s, hwId, qty)),
    toggleRig: (hwId) => act((s) => E.toggleRig(s, hwId)),
    setRigMode: (hwId, mode) => act((s) => E.setRigMode(s, hwId, mode)),
    repair: (hwId) => act((s) => E.repairRigs(s, hwId)),
    repairAll: () =>
      act((s) => {
        let fixed = 0;
        let cost = 0;
        for (const id of Object.keys(s.rigs)) {
          const r = E.repairRigs(s, id);
          if (r.ok) {
            fixed += r.fixed;
            cost += r.cost;
          }
        }
        return { ok: fixed > 0, fixed, cost };
      }),
    powerAll: (on) =>
      act((s) => {
        E.setAllRigsPower(s, on);
        if (on) s.autoShutdown = false;
        return { ok: true };
      }),
    buyUpgrade: (id) => act((s) => E.buyUpgrade(s, id)),
    sellBtc: (amount) => act((s) => E.sellBtc(s, amount)),
    buyBtc: (amount) => act((s) => E.buyBtc(s, amount)),
    setSpeed: (speed) => act((s) => ({ ok: true, speed: E.setSpeed(s, speed) })),
    togglePause: () => act((s) => ({ ok: true, paused: E.togglePause(s) })),
    skipDay: () =>
      act((s) => {
        E.advanceGameTime(s, 86400);
        return { ok: true };
      }),
    setAutoSellPct: (pct) => act((s) => ({ ok: true, pct: E.setAutoSellPct(s, pct) })),
    setAutoTreasury: (on) => act((s) => ({ ok: true, on: E.setAutoTreasury(s, on) })),
    setPriceMode: (mode) =>
      act((s) => {
        s.priceMode = mode === 'live' && s.livePrice > 0 ? 'live' : 'sim';
        return { ok: true, mode: s.priceMode };
      }),
    dismissToast: () => setToasts((t) => t.slice(1)),
    dismissEngineToast: () => act((s) => E.dismissToast(s)),
    dismissOffline: () => setOffline(null),
    refreshPrice,
    newGame: async () => {
      await clearSave();
      const s = E.createState();
      E.pushLog(s, '🔄 Nová hra. Veľa šťastia!', 'good');
      s.savedAt = Date.now();
      stateRef.current = s;
      lastTickRef.current = Date.now();
      setOffline(null);
      setToasts([]);
      setLiveInfo({ status: 'idle', at: null, usd: null });
      bump();
    },
    save: () => {
      const s = stateRef.current;
      if (!s) return;
      s.savedAt = Date.now();
      persistSave(s);
    },
  };

  const state = stateRef.current;
  const derived = state ? E.derive(state) : null;

  return { ready, state, derived, actions, offline, toasts, liveInfo };
}
