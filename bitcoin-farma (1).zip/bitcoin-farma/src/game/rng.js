/**
 * Deterministický RNG (mulberry32). Stav sa ukladá spolu s hrou,
 * takže hra je reprodukovateľná a funguje aj offline.
 */

export function nextRandom(state) {
  // uint32 aritmetika
  state.rngState = (state.rngState + 0x6d2b79f5) >>> 0;
  let t = state.rngState;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}

/** Gaussovské náhodné číslo (Box–Muller). */
export function nextGaussian(state) {
  let u = 0;
  let v = 0;
  while (u === 0) u = nextRandom(state);
  while (v === 0) v = nextRandom(state);
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

export function pick(state, arr) {
  if (!arr || arr.length === 0) return null;
  return arr[Math.floor(nextRandom(state) * arr.length) % arr.length];
}

export function newSeed() {
  return (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
}
