/**
 * Herný engine — ČISTÝ JavaScript, bez React / React Native.
 * Beží v Node (testy), v prehliadači (web náhľad) aj v mobilnej appke.
 *
 * Konvencia: funkcie MUTUJÚ stav (parameter `s`). Vlastník stavu (React hook)
 * sa stará o vyrenderovanie. Všetko je serializovateľné do JSON.
 */

import { GAME, SATS_PER_BTC } from './constants.js';
import { nextRandom, nextGaussian, newSeed } from './rng.js';
import { HARDWARE, HW_BY_ID, jPerTh } from '../data/hardware.js';
import { UPGRADE_BY_ID } from '../data/upgrades.js';
import { EVENTS, HALVING_EVENT, DIFF_ADJUST_EVENT } from '../data/events.js';
import { ACHIEVEMENTS } from '../data/achievements.js';

const SECONDS_PER_YEAR = 365 * 86400;

// Kotva dlhodobého cenového trendu. Zvolená tak, aby hra začínala presne
// na GAME.START_PRICE_EUR pri štartovnej výške blocku (čiže na dne cyklu).
const PRICE_ANCHOR = GAME.START_PRICE_EUR / cycleFactorAt(GAME.START_HEIGHT);

function cycleFactorAt(height) {
  const h = ((height % GAME.HALVING_BLOCKS) + GAME.HALVING_BLOCKS) % GAME.HALVING_BLOCKS;
  const phase = h / GAME.HALVING_BLOCKS;
  return 1 + GAME.PRICE_CYCLE_AMP * Math.sin(2 * Math.PI * (phase - (GAME.PRICE_CYCLE_PEAK_PHASE - 0.25)));
}
const ADDITIVE_KEYS = new Set(['ambientAdd']);
const MAXED_KEYS = new Set(['shopDiscount']);

/* ------------------------------------------------------------------ */
/* Blockchainové vzťahy                                                */
/* ------------------------------------------------------------------ */

/** Odmena za block v BTC pre danú výšku — presne ako v Bitcoine. */
export function blockRewardAt(height) {
  const epoch = Math.floor(Math.max(0, height) / GAME.HALVING_BLOCKS);
  if (epoch >= 64) return 0;
  return GAME.GENESIS_REWARD / Math.pow(2, epoch);
}

/** Hashrate siete (H/s) z difficulty — reálny vzťah Bitcoinu. */
export function networkHashrate(difficulty) {
  return (difficulty * Math.pow(2, 32)) / GAME.BLOCK_TIME;
}

export function nextHalvingHeight(height) {
  return (Math.floor(height / GAME.HALVING_BLOCKS) + 1) * GAME.HALVING_BLOCKS;
}

/* ------------------------------------------------------------------ */
/* Nová hra                                                            */
/* ------------------------------------------------------------------ */

export function createState(opts = {}) {
  const seed = opts.seed !== undefined ? opts.seed >>> 0 : newSeed();
  const s = {
    v: 1,
    seed,
    rngState: seed,
    time: 0, // herné sekundy od štartu
    savedAt: Date.now(), // reálny čas uloženia (pre offline progres)
    speed: GAME.DEFAULT_SPEED,
    paused: false,

    height: GAME.START_HEIGHT,
    difficulty: GAME.START_DIFFICULTY,
    difficultyTrend: GAME.START_DIFFICULTY, // dlhodobá zložka (rastie)
    difficultyShock: 1, // dočasná zložka z udalostí (vracia sa k 1)

    price: opts.startPrice || GAME.START_PRICE_EUR,
    priceBase: opts.startPrice || GAME.START_PRICE_EUR, // férová hodnota × šum
    priceNoise: 0, // log-odchýlka od cyklu (Ornsteinov-Uhlenbeckov proces)
    priceShock: 1, // dočasný cenový šok z udalostí
    priceMode: 'sim', // 'sim' | 'live'
    livePrice: null,
    priceHistory: [opts.startPrice || GAME.START_PRICE_EUR],

    eur: GAME.START_EUR,
    btc: GAME.START_BTC,

    rigs: {}, // { [hwId]: { count, on, mode, broken } }
    upgrades: {}, // { [id]: true }
    effects: [], // dočasné modifikátory z udalostí
    temp: GAME.AMBIENT_C,
    curtail: 1, // regulátor výkonu: 1 = plný výkon, 0 = stroje stoja (tepelná ochrana)
    thermalState: 'ok', // 'ok' | 'throttle' | 'stop' — len pre logy/toasty
    autoShutdown: false, // stroje odpojené, lebo nebolo na elektrinu
    nextEventDay: 86400,

    settings: {
      elecPrice: GAME.ELEC_PRICE, // €/kWh — mení sa vylepšeniami a udalosťami
      ambient: GAME.AMBIENT_C, // základná teplota okolia
      // koľko % vyťažených BTC sa ihneď predá na EUR (0 = všetko HODL-ujem)
      autoSellPct: 0,
      // ak nemáš na elektrinu, engine sám predá potrebné množstvo BTC
      autoTreasury: true,
    },

    log: [], // { t, kind, text }
    toast: null,
    achievements: {}, // { id: true }
    lessonsSeen: {}, // { lessonText: true }

    stats: {
      btcMined: 0,
      btcSold: 0,
      btcBought: 0,
      eurFromSales: 0,
      eurSpentRigs: 0,
      eurSpentUpgrades: 0,
      eurSpentElectricity: 0,
      eurSpentRepairs: 0,
      halvingsSeen: 0,
      breakdowns: 0,
      gameDays: 0,
      peakNetWorth: 0,
    },
  };
  return s;
}

/* ------------------------------------------------------------------ */
/* Pomocné: log, efekty, vylepšenia                                    */
/* ------------------------------------------------------------------ */

export function pushLog(s, text, kind = 'info') {
  s.log.unshift({ t: s.time, kind, text });
  if (s.log.length > GAME.LOG_LIMIT) s.log.length = GAME.LOG_LIMIT;
}

export function unlockLesson(s, text) {
  if (text && !s.lessonsSeen[text]) {
    s.lessonsSeen[text] = true;
    return true;
  }
  return false;
}

/** Zoznam práve platných efektov (odstráni expirované). */
export function activeEffects(s) {
  if (s.effects.length) s.effects = s.effects.filter((e) => e.until > s.time);
  return s.effects;
}

function activeMods(s) {
  const m = {
    miningMult: 1,
    elecMult: 1,
    coolingMult: 1,
    ambientAdd: 0,
    shopDiscount: 0,
    priceVolMult: 1,
  };
  for (const e of activeEffects(s)) {
    const mods = e.mods || {};
    for (const k of Object.keys(mods)) {
      if (!(k in m)) continue;
      if (ADDITIVE_KEYS.has(k)) m[k] += mods[k];
      else if (MAXED_KEYS.has(k)) m[k] = Math.max(m[k], mods[k]);
      else m[k] *= mods[k];
    }
  }
  return m;
}

function ownedUpgrades(s) {
  return Object.keys(s.upgrades).filter((id) => s.upgrades[id] && UPGRADE_BY_ID[id]);
}

function product(s, key, fallback = 1) {
  let v = fallback;
  for (const id of ownedUpgrades(s)) {
    const u = UPGRADE_BY_ID[id];
    if (typeof u[key] === 'number') v *= u[key];
  }
  return v;
}

function sum(s, key) {
  let v = 0;
  for (const id of ownedUpgrades(s)) {
    const u = UPGRADE_BY_ID[id];
    if (typeof u[key] === 'number') v += u[key];
  }
  return v;
}

export function hasUpgrade(s, id) {
  return !!s.upgrades[id];
}

/* ------------------------------------------------------------------ */
/* derive() — všetko odvodené z jedného stavu                          */
/* ------------------------------------------------------------------ */

export function derive(s) {
  const mods = activeMods(s);
  const hashMult = product(s, 'hashMult');
  const powerMult = product(s, 'powerMult');
  const effBonus = sum(s, 'effBonus');
  const failMult = product(s, 'failMult');
  const coolingUpgradeKw = sum(s, 'coolingKw');

  let nominalHash = 0;
  let watts = 0;
  let heatKw = 0;
  let rigCount = 0;
  let brokenCount = 0;
  let rigValue = 0;
  let rigInvestment = 0;

  for (const [id, r] of Object.entries(s.rigs)) {
    const hw = HW_BY_ID[id];
    if (!hw) continue;
    const count = r.count || 0;
    if (count <= 0) continue;
    const broken = Math.min(r.broken || 0, count);
    rigCount += count;
    brokenCount += broken;
    rigInvestment += count * hw.price;
    rigValue += (count - broken) * hw.price * GAME.SELLBACK_RATIO;
    if (!r.on) continue;
    const active = count - broken;
    if (active <= 0) continue;
    const modeHash = r.mode === 'oc' ? 1.15 : r.mode === 'uc' ? 0.85 : 1;
    const modePower = r.mode === 'oc' ? 1.28 : r.mode === 'uc' ? 0.78 : 1;
    nominalHash += hw.hash * active * modeHash;
    watts += hw.watts * active * modePower;
    heatKw += hw.heat * active * modePower;
  }
  watts *= powerMult;
  heatKw *= powerMult;

  // --- Chladenie, teplota a regulátor výkonu ---
  // Reálne ASIC-y pri prehriatí plynule znižujú výkon (thermal throttling).
  // `curtail` je stavový regulátor s vlastným oneskorením, takže slučka
  // teplota -> curtailment -> teplota je stabilná a nekmitá.
  const curtail = s.curtail === undefined ? 1 : s.curtail;
  watts *= curtail;
  heatKw *= curtail;

  const coolingKw = (GAME.COOLING_BASE_KW + coolingUpgradeKw) * mods.coolingMult;
  const ambient = s.settings ? s.settings.ambient : GAME.AMBIENT_C;
  const ambientNow = ambient + mods.ambientAdd;
  const load = coolingKw > 0 ? heatKw / coolingKw : 99;
  const nominalLoad = coolingKw > 0 ? (heatKw / Math.max(curtail, 1e-9)) / coolingKw : 99;
  const targetTemp = ambientNow + GAME.TEMP_PER_LOAD * Math.pow(Math.max(load, 0), 1.15);
  const thermalEff =
    s.temp <= GAME.TEMP_SAFE_C
      ? 1
      : Math.max(GAME.TEMP_MIN_EFF, 1 - (s.temp - GAME.TEMP_SAFE_C) * GAME.TEMP_EFF_LOSS);
  const efficiency = thermalEff * (1 + effBonus);

  const hashrate = nominalHash * efficiency * hashMult * mods.miningMult * curtail;

  // --- Sieť a odmena ---
  const netHashrate = networkHashrate(s.difficulty);
  const share = netHashrate > 0 ? hashrate / netHashrate : 0;
  const reward = blockRewardAt(s.height);
  const poolFee = hasUpgrade(s, 'poolnode') ? UPGRADE_BY_ID.poolnode.poolFee : GAME.POOL_FEE;

  const btcPerSec = share * (reward / GAME.BLOCK_TIME) * (1 - poolFee) * mods.miningMult;
  const price = s.price;
  const grossEurPerSec = btcPerSec * price;

  const elecPrice = (s.settings ? s.settings.elecPrice : GAME.ELEC_PRICE) * mods.elecMult;
  const kwhPerSec = watts / 3.6e6;
  const elecEurPerSec = kwhPerSec * elecPrice;
  const netEurPerSec = grossEurPerSec - elecEurPerSec;

  const netEurPerDay = netEurPerSec * 86400;
  const grossEurPerDay = grossEurPerSec * 86400;
  const btcPerDay = btcPerSec * 86400;
  const kwhPerDay = kwhPerSec * 86400;
  const elecEurPerDay = elecEurPerSec * 86400;

  const portfolioEur = s.eur + s.btc * price;
  const netWorth = portfolioEur + rigValue;

  const blocksToHalving = nextHalvingHeight(s.height) - s.height;
  const blocksToDiffAdj =
    GAME.DIFFICULTY_ADJUST_BLOCKS - (s.height % GAME.DIFFICULTY_ADJUST_BLOCKS);

  const ths = hashrate / 1e12;

  return {
    mods,
    // stroje
    hashrate,
    nominalHashrate: nominalHash,
    curtail,
    nominalLoad,
    watts,
    heatKw,
    rigCount,
    brokenCount,
    rigValue,
    rigInvestment,
    efficiency,
    thermalEff,
    // prostredie
    coolingKw,
    load,
    ambient: ambientNow,
    targetTemp,
    temp: s.temp,
    failMult,
    // sieť
    netHashrate,
    share,
    reward,
    difficulty: s.difficulty,
    height: s.height,
    poolFee,
    blocksToHalving,
    blocksToDiffAdj,
    secondsToHalving: blocksToHalving * GAME.BLOCK_TIME,
    daysToHalving: (blocksToHalving * GAME.BLOCK_TIME) / 86400,
    // ekonomika
    price,
    elecPrice,
    btcPerSec,
    btcPerDay,
    satsPerDay: btcPerDay * SATS_PER_BTC,
    grossEurPerDay,
    kwhPerDay,
    elecEurPerDay,
    netEurPerDay,
    netEurPerSec,
    // reálny peňažný tok do peňaženky (časť úlovku, ktorú hneď predáš, mínus elektrina)
    autoSellPct: s.settings ? s.settings.autoSellPct || 0 : 0,
    cashFlowEurPerDay:
      grossEurPerDay * ((s.settings ? s.settings.autoSellPct || 0 : 0) / 100) - elecEurPerDay,
    // na koľko herných dní ešte utiahneš elektrinu bez predaja BTC
    runwayDays: elecEurPerDay > 0 ? s.eur / elecEurPerDay : Infinity,
    hashPriceEurPerThDay: ths > 0 ? grossEurPerDay / ths : 0,
    elecCostPerThDay: ths > 0 ? elecEurPerDay / ths : 0,
    portfolioEur,
    liquidity: s.eur + s.btc * s.price,
    debt: s.eur < 0 ? -s.eur : 0,
    autoShutdown: !!s.autoShutdown,
    netWorth,
    paybackDays: netEurPerDay > 0 ? rigInvestment / netEurPerDay : Infinity,
    margin: grossEurPerDay > 0 ? netEurPerDay / grossEurPerDay : 0,
  };
}

/* ------------------------------------------------------------------ */
/* Simulácia                                                           */
/* ------------------------------------------------------------------ */

/** Posun hry dopredu o `realSeconds` reálnych sekúnd (pri aktuálnej rýchlosti). */
export function advance(s, realSeconds) {
  if (s.paused || !(realSeconds > 0)) return s;
  const scale = GAME.BASE_TIME_SCALE * (s.speed || 1);
  let remaining = realSeconds * scale;
  if (remaining > GAME.MAX_OFFLINE_GAME_SECONDS) remaining = GAME.MAX_OFFLINE_GAME_SECONDS;
  let guard = 0;
  while (remaining > 1e-6 && guard < 100000) {
    const dt = Math.min(remaining, GAME.MAX_STEP);
    step(s, dt);
    remaining -= dt;
    guard++;
  }
  return s;
}

/** Posun o presne `gameSeconds` herného času (ignoruje rýchlosť/pauzu). */
export function advanceGameTime(s, gameSeconds) {
  let remaining = Math.max(0, gameSeconds);
  let guard = 0;
  while (remaining > 1e-6 && guard < 100000) {
    const dt = Math.min(remaining, GAME.MAX_STEP);
    step(s, dt);
    remaining -= dt;
    guard++;
  }
  return s;
}

function step(s, dt) {
  const prevHeight = s.height;
  const prevHour = Math.floor(s.time / 3600);

  s.time += dt;
  s.height += dt / GAME.BLOCK_TIME;

  // 1) Difficulty: dlhodobý trend + dočasný šok, ktorý sa vracia k 1
  const blocks = dt / GAME.BLOCK_TIME;
  s.difficultyTrend *= Math.pow(
    1 + GAME.DIFFICULTY_GROWTH_PER_ERA,
    blocks / GAME.DIFFICULTY_ADJUST_BLOCKS
  );
  const prevEra = Math.floor(prevHeight / GAME.DIFFICULTY_ADJUST_BLOCKS);
  const nowEra = Math.floor(s.height / GAME.DIFFICULTY_ADJUST_BLOCKS);
  if (nowEra > prevEra) {
    // šum raz za obdobie úpravy (2016 blockov ≈ 14 dní)
    s.difficultyTrend *= 1 + nextGaussian(s) * GAME.DIFFICULTY_NOISE;
    const pct = (nowEra - prevEra) * GAME.DIFFICULTY_GROWTH_PER_ERA * 100;
    pushLog(
      s,
      `${DIFF_ADJUST_EVENT.emoji} Difficulty +${pct.toFixed(1)} % → ${diffLabel(s.difficultyTrend)}`,
      'network'
    );
    unlockLesson(s, DIFF_ADJUST_EVENT.lesson);
  }
  s.difficultyShock = lerpTo1(s.difficultyShock, dt, GAME.DIFFICULTY_SHOCK_TAU);
  s.difficulty = s.difficultyTrend * s.difficultyShock;

  // 2) Halving
  const prevEpoch = Math.floor(prevHeight / GAME.HALVING_BLOCKS);
  const nowEpoch = Math.floor(s.height / GAME.HALVING_BLOCKS);
  if (nowEpoch > prevEpoch) {
    s.stats.halvingsSeen += nowEpoch - prevEpoch;
    const newReward = blockRewardAt(s.height);
    pushLog(
      s,
      `${HALVING_EVENT.emoji} HALVING! Odmena za block je teraz ${newReward} BTC.`,
      'halving'
    );
    unlockLesson(s, HALVING_EVENT.lesson);
    s.toast = {
      kind: 'halving',
      title: HALVING_EVENT.title,
      text: `Odmena klesla na ${newReward} BTC. ${HALVING_EVENT.text}`,
    };
  }

  // 3) Trh: cena BTC
  updateMarket(s, dt);

  // 4) Ťažba a náklady
  const c = derive(s);
  if (c.hashrate > 0) {
    const luck = clamp(1 + nextGaussian(s) * GAME.POOL_LUCK_SIGMA, 0.2, 3);
    let mined = c.btcPerSec * dt * luck;
    if (mined > 0) {
      s.stats.btcMined += mined;
      const pct = clamp((s.settings?.autoSellPct || 0) / 100, 0, 1);
      if (pct > 0 && s.price > 0) {
        const sold = mined * pct;
        const eur = sold * s.price;
        s.eur += eur;
        s.stats.btcSold += sold;
        s.stats.eurFromSales += eur;
        mined -= sold;
      }
      s.btc += mined;
    }
  }
  if (c.watts > 0) {
    const kwh = (c.watts * dt) / 3.6e6;
    const cost = kwh * c.elecPrice;
    s.eur -= cost;
    s.stats.eurSpentElectricity += cost;
  }

  // 4b) Treasury — reálni mineri predávajú BTC, aby zaplatili elektrinu
  if (s.eur < 0 && s.settings?.autoTreasury !== false && s.btc > 0 && s.price > 0) {
    const need = -s.eur;
    const btcNeeded = Math.min(s.btc, need / s.price);
    if (btcNeeded > 0) {
      const got = btcNeeded * s.price;
      s.btc -= btcNeeded;
      s.eur += got;
      s.stats.btcSold += btcNeeded;
      s.stats.eurFromSales += got;
      if (s.time - (s.lastTreasuryLog || -1e9) > 3600) {
        s.lastTreasuryLog = s.time;
        pushLog(
          s,
          `🏦 Treasury: predaných ${btcNeeded.toFixed(6)} BTC (+${Math.round(got).toLocaleString('sk-SK')} €) na pokrytie elektriny.`,
          'info'
        );
      }
    }
  }

  // 5) Teplota (časová konštanta 1 herná hodina)
  const k = 1 - Math.exp(-dt / 3600);
  s.temp += (c.targetTemp - s.temp) * k;
  if (!isFinite(s.temp)) s.temp = GAME.AMBIENT_C;
  s.temp = clamp(s.temp, -40, 140);

  // 5b) Tepelný regulátor — plynule znižuje výkon, keď chladenie nestačí
  const span = Math.max(1, GAME.TEMP_CRITICAL_C - GAME.TEMP_WARN_C);
  const desiredCurtail = clamp(1 - Math.max(0, s.temp - GAME.TEMP_WARN_C) / span, 0, 1);
  const kc = 1 - Math.exp(-dt / 1200);
  s.curtail = clamp((s.curtail === undefined ? 1 : s.curtail) + (desiredCurtail - s.curtail) * kc, 0, 1);

  const thermalState = s.curtail > 0.98 ? 'ok' : s.curtail > 0.02 ? 'throttle' : 'stop';
  if (thermalState !== s.thermalState) {
    if (thermalState === 'throttle') {
      pushLog(s, `🌡️ Farma sa prehrieva (${s.temp.toFixed(0)} °C) — stroje znižujú výkon na ${(s.curtail * 100).toFixed(0)} %.`, 'warn');
      s.toast = {
        kind: 'warn',
        title: 'Prehrievanie',
        text: `Chladenie nestačí. Stroje samy znížia výkon. Kúp ventilátory alebo imérzne chladenie v Obchode.`,
      };
    } else if (thermalState === 'stop') {
      pushLog(s, `⛔ Tepelná ochrana: stroje sa pri ${s.temp.toFixed(0)} °C úplne odstavili, kým farma nevychladne.`, 'danger');
      s.toast = {
        kind: 'danger',
        title: 'Tepelná ochrana',
        text: 'Stroje stoja, kým farma nevychladne. Toto znamená, že máš príliš veľa hardvéru na svoje chladenie.',
      };
    } else {
      pushLog(s, `✅ Farma sa ochladila na ${s.temp.toFixed(0)} °C — stroje bežia na plný výkon.`, 'good');
    }
    s.thermalState = thermalState;
  }

  // 6) Dlh a núdzové odstavenie.
  //    Kým máš BTC, treasury z neho platí elektrinu — ťažíš ďalej.
  //    Odpojenie príde až pri dlhu nad DEBT_LIMIT, a farma sa sama naštartuje,
  //    len čo máš dosť likvidity (žiadny soft-lock).
  const liquidity = s.eur + s.btc * s.price;
  if (!s.autoShutdown && s.eur < -GAME.DEBT_LIMIT) {
    if (Object.values(s.rigs).some((r) => r.on && r.count > 0)) {
      setAllRigsPower(s, false);
      s.autoShutdown = true;
      pushLog(
        s,
        `⛔ Dodávateľ ti odpojil elektrinu. Dlh ${Math.round(s.eur).toLocaleString('sk-SK')} €.`,
        'danger'
      );
      s.toast = {
        kind: 'danger',
        title: 'Odpojenie od siete',
        text: `Dlh presiahol ${GAME.DEBT_LIMIT.toLocaleString('sk-SK')} €. Predaj BTC alebo stroje — farma sa sama naštartuje pri likvidite nad ${GAME.RESTART_LIQUIDITY} €.`,
      };
    }
  } else if (s.autoShutdown && liquidity > GAME.RESTART_LIQUIDITY) {
    setAllRigsPower(s, true);
    s.autoShutdown = false;
    pushLog(s, '✅ Dlhy sú pokryté — farma sa automaticky naštartovala.', 'good');
    s.toast = { kind: 'good', title: 'Farma beží', text: 'Stroje sa znova naštartovali.' };
  }

  // 7) Poruchy
  applyFailures(s, dt, c);

  // 8) Udalosti (raz za herný deň)
  while (s.time >= s.nextEventDay) {
    s.nextEventDay += 86400;
    s.stats.gameDays += 1;
    maybeEvent(s);
  }

  // 9) História cien (raz za hernú hodinu)
  const nowHour = Math.floor(s.time / 3600);
  if (nowHour > prevHour) {
    s.priceHistory.push(s.price);
    if (s.priceHistory.length > GAME.PRICE_HISTORY) {
      s.priceHistory.splice(0, s.priceHistory.length - GAME.PRICE_HISTORY);
    }
  }

  // 10) Štatistiky
  if (c.netWorth > s.stats.peakNetWorth) s.stats.peakNetWorth = c.netWorth;
}

/**
 * Cenový model.
 *  - `priceBase`  : geometrický Brownov pohyb + 4-ročný cyklus + mierny návrat k trendu
 *  - `priceShock` : dočasný multiplikátor z udalostí, exponenciálne sa vracia k 1
 *  - `price`      : to, čo vidí hráč a za čo obchoduje
 * V režime „živý kurz“ sa ako základ použije cena z API a šoky sa neuplatnia.
 */
function updateMarket(s, dt) {
  const dtY = dt / SECONDS_PER_YEAR;
  const mods = activeMods(s);

  // Férová hodnota = dlhodobý trend × 4-ročný cyklus.
  // Cena = férová hodnota × šum, kde šum je OU proces s návratom k 1.
  // Vďaka tomu je cyklus vždy viditeľný a cena nemôže odletieť do nuly.
  const fair = fairPrice(s.time, s.height);
  const sigma = GAME.PRICE_SIGMA * (mods.priceVolMult || 1);
  const z = nextGaussian(s);
  let noise = s.priceNoise === undefined ? 0 : s.priceNoise;
  noise += -GAME.PRICE_REVERSION * noise * dtY + sigma * Math.sqrt(dtY) * z;
  s.priceNoise = clamp(noise, -GAME.PRICE_NOISE_CLAMP, GAME.PRICE_NOISE_CLAMP);
  if (!isFinite(s.priceNoise)) s.priceNoise = 0;

  s.priceBase = clamp(fair * Math.exp(s.priceNoise), 1000, 20_000_000);

  s.priceShock = clamp(lerpTo1(s.priceShock, dt, GAME.PRICE_SHOCK_TAU), 0.5, 2);

  if (s.priceMode === 'live' && s.livePrice > 0) {
    // živý kurz z API — plynulé dobehnutie, aby graf pri každom fetchi neskočil
    s.price = s.price + (s.livePrice - s.price) * Math.min(1, dt / 1800);
    if (!isFinite(s.price) || s.price <= 0) s.price = s.livePrice;
  } else {
    s.price = clamp(s.priceBase * s.priceShock, 500, 20_000_000);
  }
}

/** Exponenciálny návrat hodnoty k 1 s danou časovou konštantou (sekundy). */
function lerpTo1(v, dt, tau) {
  return 1 + (v - 1) * Math.exp(-dt / tau);
}

function diffLabel(d) {
  if (d >= 1e12) return `${(d / 1e12).toFixed(1)} T`;
  if (d >= 1e9) return `${(d / 1e9).toFixed(1)} G`;
  return d.toFixed(0);
}

/**
 * 4-ročný cenový cyklus ako multiplikátor férovej hodnoty.
 * phase = 0 tesne po halvingu, 0.35 = vrchol, ~0.85 = dno.
 * Kopíruje historický tvar: rast po halvingu, blow-off, medvedia fáza, zotavenie.
 */
export function cycleFactor(height) {
  const h = ((height % GAME.HALVING_BLOCKS) + GAME.HALVING_BLOCKS) % GAME.HALVING_BLOCKS;
  const phase = h / GAME.HALVING_BLOCKS;
  const peak = GAME.PRICE_CYCLE_PEAK_PHASE;
  return 1 + GAME.PRICE_CYCLE_AMP * Math.sin(2 * Math.PI * (phase - (peak - 0.25)));
}

/** „Férová“ cena BTC v danom čase — trend × cyklus, bez šumu. */
export function fairPrice(gameSeconds, height) {
  const years = gameSeconds / SECONDS_PER_YEAR;
  return PRICE_ANCHOR * Math.exp(GAME.PRICE_DRIFT * years) * cycleFactor(height);
}

function applyFailures(s, dt, c) {
  if (c.rigCount === 0 || c.curtail < 0.05) return;
  // poruchy rastú až nad varovnou teplotou (nie hneď nad bezpečnou),
  // inak by prehriatie spôsobilo neodrateľnú špirálu
  const overheat = c.temp > GAME.TEMP_WARN_C ? 1 + (c.temp - GAME.TEMP_WARN_C) * 0.04 : 1;
  const days = dt / 86400;
  for (const [id, r] of Object.entries(s.rigs)) {
    const hw = HW_BY_ID[id];
    if (!hw || !r.on) continue;
    const active = (r.count || 0) - Math.min(r.broken || 0, r.count || 0);
    if (active <= 0) continue;
    const modeFail = r.mode === 'oc' ? 2.2 : r.mode === 'uc' ? 0.7 : 1;
    const p = GAME.FAILURE_RATE_PER_DAY * hw.fail * modeFail * overheat * c.failMult;
    const expected = active * p * days;
    if (expected <= 0) continue;
    let n = Math.floor(expected);
    if (nextRandom(s) < expected - n) n += 1;
    if (n > 0) {
      n = Math.min(n, active);
      r.broken = (r.broken || 0) + n;
      s.stats.breakdowns += n;
      pushLog(s, `🛠️ ${hw.name}: ${n}× porucha (oprava v Obchode).`, 'danger');
    }
  }
}

function maybeEvent(s) {
  if (nextRandom(s) >= GAME.EVENT_CHANCE_PER_DAY) return;
  const activeIds = new Set(activeEffects(s).map((e) => e.id));
  const pool = EVENTS.filter((e) => !activeIds.has(e.id));
  if (pool.length === 0) return;
  const total = pool.reduce((a, e) => a + (e.weight || 1), 0);
  let roll = nextRandom(s) * total;
  let chosen = pool[0];
  for (const e of pool) {
    roll -= e.weight || 1;
    if (roll <= 0) {
      chosen = e;
      break;
    }
  }
  applyEvent(s, chosen);
}

export function applyEvent(s, ev) {
  const inst = ev.instant || {};

  // difficulty šok je dočasný — vráti sa k trendu, takže sa efekty nekumulujú donekonečna
  if (inst.difficultyMult) {
    s.difficultyShock = clamp(s.difficultyShock * inst.difficultyMult, 0.3, 3);
  }
  // cenový šok tiež dočasný; v režime živého kurzu ho ignorujeme
  if (inst.priceMult) {
    if (s.priceMode === 'live' && s.livePrice > 0) {
      pushLog(s, `ℹ️ ${ev.title} — pri živom kurze udalosť cenu neovplyvní.`, 'info');
    } else {
      s.priceShock = clamp(s.priceShock * inst.priceMult, 0.5, 2);
    }
  }
  if (ev.duration > 0 && ev.mods) {
    // blackout ignoruj, ak máš UPS
    if (ev.id === 'blackout' && hasUpgrade(s, 'ups')) {
      pushLog(s, `🔋 ${ev.title} — UPS ťa zachránila, ťažíš ďalej.`, 'good');
      return;
    }
    s.effects.push({
      id: ev.id,
      title: ev.title,
      emoji: ev.emoji,
      mods: ev.mods,
      until: s.time + ev.duration,
    });
  }
  pushLog(s, `${ev.emoji} ${ev.title} — ${ev.text}`, 'event');
  unlockLesson(s, ev.lesson);
  s.toast = { kind: 'event', title: `${ev.emoji} ${ev.title}`, text: ev.text, lesson: ev.lesson };
}

/* ------------------------------------------------------------------ */
/* Akcie hráča                                                         */
/* ------------------------------------------------------------------ */

export function shopPrice(s, hw) {
  const discount = activeMods(s).shopDiscount || 0;
  return hw.price * (1 - discount);
}

export function buyRig(s, hwId, qty = 1) {
  const hw = HW_BY_ID[hwId];
  if (!hw || qty <= 0) return { ok: false, reason: 'Neznámy stroj.' };
  const unit = shopPrice(s, hw);
  let n = qty;
  while (n > 0 && s.eur < unit * n) n -= 1;
  if (n <= 0) return { ok: false, reason: 'Nemáš dosť peňazí.' };
  const cost = unit * n;
  s.eur -= cost;
  s.stats.eurSpentRigs += cost;
  const r = s.rigs[hwId] || (s.rigs[hwId] = { count: 0, on: true, mode: 'normal', broken: 0 });
  r.count += n;
  if (r.on === undefined) r.on = true;
  pushLog(s, `${hw.emoji} Kúpené ${n}× ${hw.name} za ${fmt(cost)} €`, 'buy');
  unlockLesson(s, hw.lesson);
  return { ok: true, count: n, cost };
}

export function sellRig(s, hwId, qty = 1) {
  const hw = HW_BY_ID[hwId];
  const r = s.rigs[hwId];
  if (!hw || !r || r.count <= 0) return { ok: false, reason: 'Nemáš čo predať.' };
  const n = Math.min(qty, r.count);
  const income = n * hw.price * GAME.SELLBACK_RATIO;
  s.eur += income;
  r.count -= n;
  r.broken = Math.max(0, Math.min(r.broken || 0, r.count));
  if (r.count === 0) delete s.rigs[hwId];
  pushLog(s, `💶 Predané ${n}× ${hw.name} za ${fmt(income)} €`, 'sell');
  return { ok: true, count: n, income };
}

export function toggleRig(s, hwId) {
  const r = s.rigs[hwId];
  if (!r) return { ok: false };
  r.on = !r.on;
  return { ok: true, on: r.on };
}

/** Zapne/vypne všetky stroje naraz. */
export function setAllRigsPower(s, on) {
  for (const r of Object.values(s.rigs)) {
    if ((r.count || 0) > 0) r.on = !!on;
  }
  return on;
}

export function setRigMode(s, hwId, mode) {
  const r = s.rigs[hwId];
  if (!r || !['normal', 'oc', 'uc'].includes(mode)) return { ok: false };
  r.mode = mode;
  return { ok: true };
}

export function repairCost(s, hwId) {
  const hw = HW_BY_ID[hwId];
  const r = s.rigs[hwId];
  if (!hw || !r || !r.broken) return 0;
  return r.broken * hw.price * GAME.REPAIR_RATIO;
}

export function repairRigs(s, hwId) {
  const r = s.rigs[hwId];
  const cost = repairCost(s, hwId);
  if (!r || cost <= 0) return { ok: false, reason: 'Nič na opravu.' };
  if (s.eur < cost) return { ok: false, reason: 'Nemáš dosť peňazí na opravu.' };
  s.eur -= cost;
  s.stats.eurSpentRepairs += cost;
  const fixed = r.broken;
  r.broken = 0;
  pushLog(s, `🔧 Opravené ${fixed}× — ${fmt(cost)} €`, 'good');
  return { ok: true, fixed, cost };
}

export function canBuyUpgrade(s, id) {
  const u = UPGRADE_BY_ID[id];
  if (!u) return { ok: false, reason: 'Neznáme vylepšenie.' };
  if (s.upgrades[id]) return { ok: false, reason: 'Už vlastníš.' };
  for (const req of u.requires || []) {
    if (!s.upgrades[req]) {
      return { ok: false, reason: `Najprv kúp: ${UPGRADE_BY_ID[req]?.name || req}` };
    }
  }
  if (s.eur < u.price) return { ok: false, reason: 'Nemáš dosť peňazí.' };
  return { ok: true };
}

export function buyUpgrade(s, id) {
  const check = canBuyUpgrade(s, id);
  if (!check.ok) return check;
  const u = UPGRADE_BY_ID[id];
  s.eur -= u.price;
  s.stats.eurSpentUpgrades += u.price;
  s.upgrades[id] = true;
  if (typeof u.elecPrice === 'number' && s.settings) s.settings.elecPrice = u.elecPrice;
  pushLog(s, `${u.emoji} Vylepšenie: ${u.name} (−${fmt(u.price)} €)`, 'buy');
  unlockLesson(s, u.lesson);
  return { ok: true };
}

export function sellBtc(s, btcAmount) {
  const amt = Math.min(Math.max(0, btcAmount), s.btc);
  if (amt <= 0) return { ok: false, reason: 'Nemáš čo predať.' };
  const income = amt * s.price;
  s.btc -= amt;
  s.eur += income;
  s.stats.btcSold += amt;
  s.stats.eurFromSales += income;
  pushLog(s, `₿→€ Predané ${amt.toFixed(6)} BTC za ${fmt(income)} €`, 'sell');
  return { ok: true, amount: amt, income };
}

export function buyBtc(s, eurAmount) {
  const amt = Math.min(Math.max(0, eurAmount), s.eur);
  if (amt <= 0) return { ok: false, reason: 'Nemáš dosť peňazí.' };
  const btc = amt / s.price;
  s.eur -= amt;
  s.btc += btc;
  s.stats.btcBought += btc;
  pushLog(s, `€→₿ Kúpené ${btc.toFixed(6)} BTC za ${fmt(amt)} €`, 'buy');
  return { ok: true, amount: btc, cost: amt };
}

export function setAutoSellPct(s, pct) {
  if (!s.settings) s.settings = { elecPrice: GAME.ELEC_PRICE, ambient: GAME.AMBIENT_C };
  s.settings.autoSellPct = clamp(Math.round(Number(pct) || 0), 0, 100);
  return s.settings.autoSellPct;
}

export function setAutoTreasury(s, on) {
  if (!s.settings) s.settings = { elecPrice: GAME.ELEC_PRICE, ambient: GAME.AMBIENT_C };
  s.settings.autoTreasury = !!on;
  return s.settings.autoTreasury;
}

export function setSpeed(s, speed) {
  if (GAME.SPEEDS.includes(speed)) s.speed = speed;
  return s.speed;
}

export function togglePause(s) {
  s.paused = !s.paused;
  return s.paused;
}

export function dismissToast(s) {
  s.toast = null;
}

/* ------------------------------------------------------------------ */
/* Achievements                                                        */
/* ------------------------------------------------------------------ */

export function checkAchievements(s, ctx) {
  const c = ctx || derive(s);
  const metricCtx = {
    hashrate: c.hashrate,
    totalValue: c.netWorth,
    allUpgrades: ownedUpgrades(s).length >= Object.keys(UPGRADE_BY_ID).length,
  };
  const unlocked = [];
  for (const a of ACHIEVEMENTS) {
    if (s.achievements[a.id]) continue;
    let ok = false;
    try {
      ok = !!a.check(s, metricCtx);
    } catch {
      ok = false;
    }
    if (ok) {
      s.achievements[a.id] = true;
      unlocked.push(a);
    }
  }
  return unlocked;
}

/* ------------------------------------------------------------------ */
/* Offline progres                                                     */
/* ------------------------------------------------------------------ */

/**
 * Vráti { state, offlineGameSeconds, capped }.
 * `savedAt` je reálny timestamp posledného uloženia.
 */
export function applyOfflineProgress(s, nowMs = Date.now(), speedOverride) {
  const realSeconds = Math.max(0, (nowMs - (s.savedAt || nowMs)) / 1000);
  if (realSeconds < 5) return { offlineGameSeconds: 0, capped: false };
  const speed = speedOverride || s.speed || 1;
  let gameSeconds = realSeconds * GAME.BASE_TIME_SCALE * speed;
  const capped = gameSeconds > GAME.MAX_OFFLINE_GAME_SECONDS;
  if (capped) gameSeconds = GAME.MAX_OFFLINE_GAME_SECONDS;
  const before = { eur: s.eur, btc: s.btc, time: s.time };
  const wasPaused = s.paused;
  s.paused = false;
  advanceGameTime(s, gameSeconds);
  s.paused = wasPaused;
  return {
    offlineGameSeconds: gameSeconds,
    capped,
    realSeconds,
    gainedBtc: s.btc - before.btc,
    spentEur: before.eur - s.eur,
  };
}

/* ------------------------------------------------------------------ */
/* utils                                                               */
/* ------------------------------------------------------------------ */

function clamp(v, lo, hi) {
  return Math.min(hi, Math.max(lo, v));
}

function fmt(v) {
  return Math.round(v).toLocaleString('sk-SK');
}

export { HARDWARE, HW_BY_ID, jPerTh, SATS_PER_BTC, clamp };
