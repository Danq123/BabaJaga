import React from 'react';
import { View, Text, Pressable, StyleSheet, Platform } from 'react-native';

import { C, S, F } from '../theme.js';

export const TABS = [
  { id: 'farm', label: 'Farma', emoji: '⛏️' },
  { id: 'shop', label: 'Obchod', emoji: '🛒' },
  { id: 'market', label: 'Trh', emoji: '📈' },
  { id: 'learn', label: 'Akadémia', emoji: '🎓' },
  { id: 'stats', label: 'Štatistiky', emoji: '📊' },
];

export default function TabBar({ active, onChange, badge }) {
  return (
    <View style={st.wrap}>
      {TABS.map((t) => {
        const on = t.id === active;
        const b = badge?.[t.id];
        return (
          <Pressable
            key={t.id}
            onPress={() => onChange(t.id)}
            style={({ pressed }) => [st.tab, on && st.tabActive, pressed && { opacity: 0.7 }]}
          >
            <Text style={[st.emoji, on && { transform: [{ scale: 1.1 }] }]}>{t.emoji}</Text>
            <Text style={[st.label, on && st.labelActive]} numberOfLines={1}>
              {t.label}
            </Text>
            {b ? (
              <View style={st.badge}>
                <Text style={st.badgeText}>{b > 9 ? '9+' : b}</Text>
              </View>
            ) : null}
          </Pressable>
        );
      })}
    </View>
  );
}

const st = StyleSheet.create({
  wrap: {
    flexDirection: 'row',
    backgroundColor: C.bgAlt,
    borderTopWidth: 1,
    borderTopColor: C.border,
    paddingTop: S.sm - 2,
    paddingBottom: Platform.OS === 'ios' ? S.xl : S.sm,
  },
  tab: { flex: 1, alignItems: 'center', gap: 2, paddingVertical: 4, borderRadius: 8 },
  tabActive: { backgroundColor: 'rgba(247,147,26,0.12)' },
  emoji: { fontSize: 17 },
  label: { ...F.tiny, fontSize: 10, color: C.textFaint },
  labelActive: { color: C.accent, fontWeight: '800' },
  badge: {
    position: 'absolute',
    top: 0,
    right: '22%',
    backgroundColor: C.red,
    borderRadius: 99,
    minWidth: 15,
    height: 15,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 3,
  },
  badgeText: { color: '#fff', fontSize: 9, fontWeight: '800' },
});
