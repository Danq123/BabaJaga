import React, { useMemo } from 'react';
import { View, Text, StyleSheet } from 'react-native';

import { C, S, F } from '../theme.js';

/**
 * Graf ceny bez závislosti na SVG — stĺpcový priebeh vykreslený z View.
 * `data` je pole čísel (história cien).
 */
export default function PriceChart({ data = [], height = 120, color = C.accent }) {
  const { bars, min, max, last, changePct } = useMemo(() => {
    if (!data.length) return { bars: [], min: 0, max: 0, last: 0, changePct: 0 };
    const src = data.slice(-80);
    const lo = Math.min(...src);
    const hi = Math.max(...src);
    const span = Math.max(hi - lo, hi * 0.0001);
    const bs = src.map((v, i) => ({
      v,
      h: 0.12 + 0.88 * ((v - lo) / span),
      up: i === 0 ? true : v >= src[i - 1],
    }));
    return {
      bars: bs,
      min: lo,
      max: hi,
      last: src[src.length - 1],
      changePct: src[0] > 0 ? ((last0(src) - src[0]) / src[0]) * 100 : 0,
    };
  }, [data]);

  if (!bars.length) {
    return (
      <View style={[st.wrap, { height }]}>
        <Text style={F.small}>Zatiaľ žiadne dáta.</Text>
      </View>
    );
  }

  const up = changePct >= 0;

  return (
    <View>
      <View style={st.header}>
        <View>
          <Text style={[F.tiny]}>MIN</Text>
          <Text style={[F.mono, { color: C.textDim }]}>{fmt(min)}</Text>
        </View>
        <View style={{ alignItems: 'center' }}>
          <Text style={[F.tiny]}>POSLEDNÁ</Text>
          <Text style={[F.h3, { color: up ? C.green : C.red }]}>{fmt(last)}</Text>
        </View>
        <View style={{ alignItems: 'flex-end' }}>
          <Text style={[F.tiny]}>MAX</Text>
          <Text style={[F.mono, { color: C.textDim }]}>{fmt(max)}</Text>
        </View>
      </View>

      <View style={[st.plot, { height }]}>
        {bars.map((b, i) => (
          <View
            key={i}
            style={{
              flex: 1,
              height: `${b.h * 100}%`,
              backgroundColor: i === bars.length - 1 ? (up ? C.green : C.red) : color,
              opacity: i === bars.length - 1 ? 1 : 0.25 + 0.6 * (i / bars.length),
              marginHorizontal: bars.length > 50 ? 0 : 0.5,
              borderRadius: 1,
            }}
          />
        ))}
      </View>

      <View style={st.footer}>
        <Text style={[F.tiny]}>staršie</Text>
        <Text style={[F.mono, { color: up ? C.green : C.red, fontSize: 11 }]}>
          {up ? '+' : ''}
          {changePct.toFixed(2)} %
        </Text>
        <Text style={[F.tiny]}>teraz</Text>
      </View>
    </View>
  );
}

function last0(arr) {
  return arr[arr.length - 1];
}

function fmt(v) {
  if (!isFinite(v)) return '—';
  if (v >= 1000) return `${(v / 1000).toFixed(1)}k €`;
  return `${v.toFixed(0)} €`;
}

/** Ukazovateľ vyťaženia (napr. chladenie) s farebnými pásmi. */
export function Gauge({ value, label, left, right, color = C.accent, markers }) {
  const pct = Math.max(0, Math.min(1.5, Number(value) || 0));
  return (
    <View>
      <View style={st.gaugeHead}>
        <Text style={F.tiny}>{label}</Text>
        <Text style={[F.mono, { color }]}>{(pct * 100).toFixed(0)} %</Text>
      </View>
      <View style={st.barTrack}>
        <View style={[st.barFill, { width: `${Math.min(1, pct) * 100}%`, backgroundColor: color }]} />
        {(markers || []).map((m, i) => (
          <View key={i} style={[st.barMarker, { left: `${Math.min(1, m) * 100}%` }]} />
        ))}
      </View>
      <View style={st.gaugeHead}>
        <Text style={F.tiny}>{left}</Text>
        <Text style={F.tiny}>{right}</Text>
      </View>
    </View>
  );
}

const st = StyleSheet.create({
  wrap: { alignItems: 'center', justifyContent: 'center' },
  header: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: S.sm, alignItems: 'flex-start' },
  plot: { flexDirection: 'row', alignItems: 'flex-end', gap: 1, backgroundColor: C.bgAlt, borderRadius: 8, padding: 6 },
  footer: { flexDirection: 'row', justifyContent: 'space-between', marginTop: S.xs },
  gaugeHead: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 3 },
  barTrack: { height: 10, backgroundColor: C.bgAlt, borderRadius: 99, overflow: 'hidden' },
  barFill: { height: '100%', borderRadius: 99 },
  barMarker: { position: 'absolute', width: 1.5, height: 10, backgroundColor: C.borderHi, top: 0 },
});
