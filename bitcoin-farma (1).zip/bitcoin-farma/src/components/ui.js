import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';

import { C, S, R, F } from '../theme.js';

/* ------------------------------- Card ------------------------------- */

export function Card({ children, style, accent, ...rest }) {
  return (
    <View style={[st.card, accent && { borderLeftColor: accent, borderLeftWidth: 3 }, style]} {...rest}>
      {children}
    </View>
  );
}

/* ------------------------------ Section ----------------------------- */

export function Section({ title, right, children, style }) {
  return (
    <View style={[{ marginBottom: S.lg }, style]}>
      {(title || right) && (
        <View style={st.sectionHead}>
          {title ? <Text style={F.label}>{title}</Text> : <View />}
          {right || null}
        </View>
      )}
      {children}
    </View>
  );
}

/* ------------------------------- Button ----------------------------- */

export function Button({ label, onPress, variant = 'primary', disabled, style, small, sub }) {
  const bg =
    variant === 'primary' ? C.accent : variant === 'danger' ? C.redDim : variant === 'good' ? C.greenDim : C.cardHi;
  const fg = variant === 'primary' ? '#1A1206' : C.text;
  return (
    <Pressable
      onPress={disabled ? undefined : onPress}
      style={({ pressed }) => [
        st.btn,
        small && st.btnSmall,
        { backgroundColor: bg, opacity: disabled ? 0.35 : pressed ? 0.75 : 1 },
        style,
      ]}
    >
      <Text style={[st.btnLabel, { color: fg }, small && st.btnLabelSmall]} numberOfLines={1}>
        {label}
      </Text>
      {sub ? <Text style={[st.btnSub, { color: fg }]} numberOfLines={1}>{sub}</Text> : null}
    </Pressable>
  );
}

/* -------------------------------- Stat ------------------------------ */

export function Stat({ label, value, sub, color, style, big }) {
  return (
    <View style={[st.stat, style]}>
      <Text style={F.tiny} numberOfLines={1}>
        {label}
      </Text>
      <Text style={[big ? F.big : F.mono, { color: color || C.text, fontSize: big ? 26 : 15 }]} numberOfLines={1}>
        {value}
      </Text>
      {sub ? <Text style={[F.tiny, { marginTop: 2 }]} numberOfLines={1}>{sub}</Text> : null}
    </View>
  );
}

/* --------------------------------- Bar ------------------------------ */

export function Bar({ value, color = C.accent, height = 8, trackColor, markers, style }) {
  const pct = Math.max(0, Math.min(1, Number(value) || 0));
  return (
    <View style={[st.barTrack, { height, backgroundColor: trackColor || C.bgAlt }, style]}>
      <View style={[st.barFill, { width: `${pct * 100}%`, backgroundColor: color }]} />
      {(markers || []).map((m, i) => (
        <View
          key={i}
          style={[st.barMarker, { left: `${Math.max(0, Math.min(1, m)) * 100}%`, height }]}
        />
      ))}
    </View>
  );
}

/* -------------------------------- Chip ------------------------------ */

export function Chip({ label, color = C.textDim, filled, onPress, style }) {
  const content = (
    <View
      style={[
        st.chip,
        { borderColor: color },
        filled && { backgroundColor: color },
        style,
      ]}
    >
      <Text style={[st.chipLabel, { color: filled ? C.bg : color }]} numberOfLines={1}>
        {label}
      </Text>
    </View>
  );
  if (!onPress) return content;
  return <Pressable onPress={onPress} style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}>{content}</Pressable>;
}

/* ---------------------------- Segmented ----------------------------- */

export function Segmented({ options, value, onChange, style }) {
  return (
    <View style={[st.seg, style]}>
      {options.map((o) => {
        const active = o.value === value;
        return (
          <Pressable
            key={String(o.value)}
            onPress={() => onChange(o.value)}
            style={[st.segItem, active && st.segItemActive]}
          >
            <Text style={[st.segLabel, active && st.segLabelActive]}>{o.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

/* ------------------------------- Row -------------------------------- */

export function Row({ label, value, valueColor, style, hint }) {
  return (
    <View style={[st.row, style]}>
      <Text style={[F.small, { flex: 1 }]} numberOfLines={1}>
        {label}
      </Text>
      <Text style={[F.mono, { color: valueColor || C.text }]} numberOfLines={1}>
        {value}
      </Text>
      {hint ? <Text style={[F.tiny, { marginLeft: S.sm, width: 78, textAlign: 'right' }]}>{hint}</Text> : null}
    </View>
  );
}

/* ------------------------------- Toast ------------------------------ */

export function Toast({ title, text, kind = 'info', onPress, actionLabel }) {
  const color =
    kind === 'danger' ? C.red : kind === 'good' ? C.green : kind === 'warn' ? C.yellow : kind === 'halving' ? C.purple : C.accent;
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [st.toast, { borderColor: color, opacity: pressed ? 0.8 : 1 }]}>
      <View style={{ flex: 1 }}>
        <Text style={[F.h3, { color }]}>{title}</Text>
        {text ? <Text style={[F.small, { marginTop: 3, color: C.text }]}>{text}</Text> : null}
      </View>
      {actionLabel ? <Text style={[F.tiny, { color, marginLeft: S.sm }]}>{actionLabel}</Text> : null}
    </Pressable>
  );
}

/* ------------------------------- Empty ------------------------------ */

export function Empty({ emoji, title, text }) {
  return (
    <View style={st.empty}>
      <Text style={{ fontSize: 34 }}>{emoji}</Text>
      <Text style={[F.h3, { marginTop: S.sm, textAlign: 'center' }]}>{title}</Text>
      {text ? <Text style={[F.small, { marginTop: S.xs, textAlign: 'center', lineHeight: 19 }]}>{text}</Text> : null}
    </View>
  );
}

const st = StyleSheet.create({
  card: {
    backgroundColor: C.card,
    borderRadius: R.lg,
    borderWidth: 1,
    borderColor: C.border,
    padding: S.lg,
    borderLeftWidth: 1,
  },
  sectionHead: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: S.sm,
    paddingHorizontal: 2,
  },
  btn: {
    borderRadius: R.md,
    paddingVertical: 12,
    paddingHorizontal: S.lg,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 46,
  },
  btnSmall: { minHeight: 34, paddingVertical: 7, paddingHorizontal: S.md },
  btnLabel: { fontSize: 14, fontWeight: '700' },
  btnLabelSmall: { fontSize: 12 },
  btnSub: { fontSize: 11, fontWeight: '600', opacity: 0.75, marginTop: 1 },
  stat: { gap: 2 },
  barTrack: { borderRadius: R.pill, overflow: 'hidden', width: '100%' },
  barFill: { height: '100%', borderRadius: R.pill },
  barMarker: { position: 'absolute', width: 1.5, backgroundColor: C.borderHi, top: 0 },
  chip: {
    borderRadius: R.pill,
    borderWidth: 1,
    paddingHorizontal: S.sm + 2,
    paddingVertical: 3,
    alignSelf: 'flex-start',
  },
  chipLabel: { fontSize: 11, fontWeight: '700' },
  seg: {
    flexDirection: 'row',
    backgroundColor: C.bgAlt,
    borderRadius: R.md,
    padding: 3,
    borderWidth: 1,
    borderColor: C.border,
  },
  segItem: { flex: 1, paddingVertical: 8, borderRadius: R.sm, alignItems: 'center' },
  segItemActive: { backgroundColor: C.accent },
  segLabel: { fontSize: 12, fontWeight: '700', color: C.textDim },
  segLabelActive: { color: '#1A1206' },
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 5, gap: S.sm },
  toast: {
    backgroundColor: C.card,
    borderRadius: R.lg,
    borderWidth: 1.5,
    padding: S.md,
    flexDirection: 'row',
    alignItems: 'center',
  },
  empty: { alignItems: 'center', paddingVertical: S.xxl, paddingHorizontal: S.xl },
});
