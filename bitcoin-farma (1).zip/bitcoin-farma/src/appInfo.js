/**
 * Identita projektu čítaná priamo z Expo konfigurácie (app.config.js),
 * aby sa názov appky nemenil na dvoch miestach.
 */
import Constants from 'expo-constants';

export const APP_NAME = Constants.expoConfig?.name || 'My app';
export const APP_SLUG = Constants.expoConfig?.slug || 'my-app';
export const APP_VERSION = Constants.expoConfig?.version || '1.0.0';
