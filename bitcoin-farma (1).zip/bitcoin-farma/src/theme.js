/** Dizajnový systém — tmavá téma s bitcoinovo-oranžovým akcentom. */

export const C = {
  bg: '#0B0E14',
  bgAlt: '#11151F',
  card: '#161B27',
  cardHi: '#1D2433',
  border: '#252D3F',
  borderHi: '#33405A',

  text: '#E8ECF4',
  textDim: '#98A2B8',
  textFaint: '#5E6880',

  accent: '#F7931A', // bitcoin orange
  accentDim: '#8A5410',
  green: '#2ECC71',
  greenDim: '#17603A',
  red: '#FF5C5C',
  redDim: '#6E2222',
  yellow: '#FFC53D',
  yellowDim: '#6B5315',
  blue: '#4DA3FF',
  purple: '#A97BFF',
};

export const S = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
};

export const R = {
  sm: 8,
  md: 12,
  lg: 18,
  pill: 999,
};

export const F = {
  h1: { fontSize: 28, fontWeight: '800', color: C.text, letterSpacing: -0.5 },
  h2: { fontSize: 20, fontWeight: '700', color: C.text, letterSpacing: -0.3 },
  h3: { fontSize: 16, fontWeight: '700', color: C.text },
  body: { fontSize: 14, fontWeight: '400', color: C.text },
  small: { fontSize: 12, fontWeight: '400', color: C.textDim },
  tiny: { fontSize: 11, fontWeight: '500', color: C.textFaint },
  label: { fontSize: 11, fontWeight: '700', color: C.textFaint, letterSpacing: 0.8, textTransform: 'uppercase' },
  mono: { fontSize: 13, fontWeight: '600', fontVariant: ['tabular-nums'] },
  big: { fontSize: 26, fontWeight: '800', fontVariant: ['tabular-nums'], letterSpacing: -0.5 },
};

/** farba podľa znamienka / stavu */
export function signColor(v) {
  if (v > 0) return C.green;
  if (v < 0) return C.red;
  return C.textDim;
}

export function tempColor(temp) {
  if (temp >= 70) return C.red;
  if (temp >= 58) return C.yellow;
  if (temp >= 45) return C.accent;
  return C.green;
}
