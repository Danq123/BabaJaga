# ₿ Bitcoin Farma — vzdelávacia simulácia ťažby bitcoinu

Mobilná hra (React Native / Expo), v ktorej si postavíš bitcoinovú farmu od jedného
použitého ASIC-u v garáži až po priemyselnú halu. Hra používa **skutočné vzťahy
Bitcoinu**, takže hraním sa naučíš, čo je difficulty, halving, hashprice, J/TH,
mining pool a prečo je elektrina všetko.

> ⚠️ **Toto nie je spôsob, ako „namnožiť bitcoiny“.** Je to hra a učebná pomôcka.
> Nepoužívajú sa žiadne reálne bitcoiny ani peniaze. Aplikácie sľubujúce
> garantované zhodnotenie bitcoinu sú podvod — a táto to nerobí a nikdy nebude.

---

## Identita projektu

Názov a slug appky sú nastavené na hodnoty, ktoré si zadal — **`My app` / `my-app`** —
a žijú výhradne v `app.config.js` (jediný zdroj pravdy). Herný obsah sa volá
„Bitcoin Farma“, ale to, čo uvidíš pod ikonou a v Expo Go, je `My app`.
Oboje vieš prepísať premennými prostredia bez zásahu do kódu:

```bash
APP_NAME="Moja Farma" APP_SLUG="moja-farma" npx expo start
```

Detaily a EAS profily sú v sekcii [Identita projektu a EAS Build](#identita-projektu-a-eas-build).

---

## Spustenie

```bash
cd bitcoin-farma
npm install
npx expo start
```

Potom:

| Cieľ | Príkaz | Poznámka |
|---|---|---|
| **Android telefón** | stlač `a` v Expo CLI | Pozri nižšie — Expo Go pre SDK 57 zatiaľ nie je v obchodoch |
| **iOS simulátor** | `npx expo run:ios` | vyžaduje macOS + Xcode |
| **Android emulátor** | `npx expo run:android` | vyžaduje Android Studio |
| **Prehliadač** | `npm run web` | rovnaký kód, beží ako web app |

### ⚠️ Dôležité: Expo Go a SDK 57

Expo Go pre SDK 56/57 **zatiaľ nie je dostupné v App Store ani Google Play**
(čaká na schválenie). Máš tri možnosti:

1. **Android** — staršie Expo Go sa dá stiahnuť z <https://expo.dev/go> (APK),
   alebo použi `npx expo run:android` s emulátorom/pripojeným telefónom.
2. **iOS** — `eas go` (nový spôsob spúšťania Expo Go na iOS zariadení).
3. **Najspoľahlivejšie** — development build:
   ```bash
   npm install expo-dev-client
   npx expo run:android   # alebo run:ios
   ```

Ak `npm install` hlási konflikt verzií, spusti `npm run fix`
(= `expo install --fix`), ktorý doladí verzie balíčkov presne pre SDK 57.

Verzie v `package.json` sú prevzaté z oficiálneho `expo@57.0.22/bundledNativeModules.json`:
React Native 0.86.3, React 19.2.3, AsyncStorage 2.2.0.

---

## Čo je v krabici

```
bitcoin-farma/
├── App.js                    koreňová komponenta, taby, hlavička, toasty, intro
├── index.js                  Expo entry point
├── package.json              Expo SDK 57 / RN 0.86.3 / React 19.2.3
├── app.config.js             ⭐ identita projektu (name/slug) + celá Expo konfigurácia
├── eas.json                  profily EAS Build (development / preview / production)
├── src/
│   ├── package.json          {"type":"module"} — len kvôli Node testom, pozri nižšie
│   ├── theme.js              farby, medzery, typografia
│   ├── game/
│   │   ├── constants.js      ⚖️  VŠETKY vyvažovacie konštanty na jednom mieste
│   │   ├── engine.js         herný engine — ČISTÝ JS, mutuje stav
│   │   ├── rng.js            deterministický mulberry32 + Box–Muller
│   │   ├── format.js         formátovanie (sk-SK, hashove jednotky, herný čas)
│   │   ├── price.js          živý kurz BTC z CoinGecko (nepovinné)
│   │   └── useGame.js        React hook: herná slučka, ukladanie, akcie
│   ├── data/
│   │   ├── hardware.js       7 ASIC-ov od USB hračky po 1,2 PH/s
│   │   ├── upgrades.js       10 vylepšení farmy s dependenciami
│   │   ├── events.js         14 náhodných udalostí + halving + úprava difficulty
│   │   ├── lessons.js        12 vzdelávacích lekcií
│   │   └── achievements.js   16 úspechov
│   ├── components/           ui.js (Card, Button, Stat, Bar, Chip, Segmented…),
│   │                         Sparkline.js (graf + Gauge), TabBar.js
│   ├── screens/              FarmScreen, ShopScreen, MarketScreen,
│   │                         LearnScreen, StatsScreen
│   └── lib/storage.js        AsyncStorage obal
├── test/engine.test.mjs      26 testov (`npm test`)
└── scripts/balance.mjs       simuluje 8 herných rokov a vypíše metriky (`npm run balance`)
```

### Prečo je v `src/` samostatný `package.json`

Herný engine je zámerne **čistý JavaScript bez akejkoľvek závislosti na React Native**,
aby sa dal testovať v Node a spustiť aj v prehliadači. Node potrebuje vedieť, že `.js`
súbory v `src/` sú ES moduly — preto je tam `{"type":"module"}`. Koreňový
`package.json` ostáva CommonJS, pretože `babel.config.js` používa `module.exports`.
Na Metro/Expo bundler to nemá vplyv (žiadny import neukazuje na adresár `src/`).
Ak by ti to náhodou prekážalo, súbor môžeš zmazať a pridať `"type": "module"`
do koreňového `package.json` + premenovať `babel.config.js` na `babel.config.cjs`.

---

## Identita projektu a EAS Build

### `app.config.js` (namiesto app.json)

Pôvodný `app.json` je preč; všetko riadi dynamická konfigurácia. Načíta ju
Expo CLI aj EAS a vie čítať premenné prostredia:

| Premenná | Predvolené | Na čo |
|---|---|---|
| `APP_NAME` | `My app` | zobrazovaný názov appky |
| `APP_SLUG` | `my-app` | slug projektu (určuje EAS projekt a URL) |
| `APP_VERSION` | `1.0.0` | verzia buildu |
| `APP_BUNDLE_ID` | `com.myapp.mobile` | iOS bundleId + Android package |
| `APP_SCHEME` | `myapp` | deep-link scheme |
| `EAS_PROJECT_ID` | — | ak je nastavené, zapíše sa do `extra.eas.projectId` |

Identifikátory balíkov sa odvodzujú zo slug-u, takže keď slug zmeníš, zmení sa
aj package/bundleId konzistentne. Výslednú konfiguráciu si vieš pozrieť cez
`npx expo config --type public`.

Zobrazovaný názov v UI (hlavička, intro, disklaimer) sa **nehardcoduje** — číta sa
z `expo-constants` cez `src/appInfo.js`, takže jedno premenovanie stačí.

### `eas.json` — profily buildov

| Profil | Čo robí |
|---|---|
| `development` | dev client, interne, `APP_VARIANT=development` |
| `development-simulator` | to isté, ale iOS simulátor |
| `preview` | interná distribúcia, **APK na Androide**, channel `preview` |
| `production` | auto-increment verzie, channel `production` |

Prvý build:

```bash
npm install -g eas-cli        # alebo npx eas-cli
eas login
eas init                      # prepojí projekt s tvojím Expo účtom podľa slug-u
eas build --profile preview --platform android
```

`eas init` doplní `extra.eas.projectId` do konfigurácie automaticky.
Profil `preview` ti dá nainštalovateľné APK — to je najjednoduchšia cesta,
kým Expo Go pre SDK 56/57 nie je v obchodoch.

---

## Herné mechaniky

### Reálne vzťahy Bitcoinu (žiadna skratka)

| Vzťah | Implementácia |
|---|---|
| Odmena za block | `50 / 2^floor(height / 210000)` — hra začína na blocku 1 020 000, teda v ére **3,125 BTC** |
| Hashrate siete | `difficulty × 2³² / 600 s` |
| Tvoj podiel | `tvojHashrate / hashrateSiete` |
| Denný príjem | `podiel × odmena × 144 blockov × (1 − poplatok poolu)` |
| Úprava difficulty | každých 2016 blockov, trend + šum |
| Spotreba | `W × h / 1000` kWh, náklad `kWh × cena elektriny` |
| Efektivita | `J/TH = watty / (hashrate v TH/s)` |

Jediná herná úprava: sieť je zmenšená faktorom `NETWORK_SCALE = 0.25`, inak by bol
tvoj podiel `1e-9 %` a hra by bola o ničom.

### Cena BTC — deterministický cyklus + šum

```
cena = férováHodnota × šum × dočasnýŠok
férováHodnota = kotva × e^(0,05 × roky) × cyklus(height)
cyklus = 1 + 0,5 × sin(2π × (fáza − 0,10))
```

Fáza je pozícia v 4-ročnom cykle od halvingu. Vrchol je na 35 % (≈ 1,4 roka po
halvingu), dno na 85 %. Hra začína na dne cyklu pri 85 000 €. Šum je
Ornsteinov–Uhlenbeckov proces (návrat k cyklu), takže cena nemôže odletieť do nuly.
Udalosti pridávajú dočasný šok s 3-dňovým polčasom rozpadu.

Na obrazovke **Trh** môžeš prepnúť na **živý kurz** z CoinGecko — vtedy sa
použije reálna cena a simulácia trhu sa vypne.

### Prečo nie je hra triviálna

1. **Elektrina sa platí v eurách, ťažíš v bitcoinoch.** Presne ako v skutočnosti musíš
   časť úlovku predávať. Máš na to auto-predaj (0–100 %) a záchranný treasury predaj.
2. **Chladenie je limit.** Každý stroj produkuje teplo. Keď prekročíš kapacitu,
   regulátor plynule zníži výkon (thermal throttling) a pri 70 °C stroje odstavia.
3. **Poruchy.** Rastú s teplotou a s pretaktovaním. Oprava stojí 10 % ceny stroja.
4. **Halving.** Odmena spadne o 50 % zo dňa na deň. Kto nemá rezervu, padne.
5. **Difficulty rastie.** Tvoj podiel na sieti klesá, aj keď sa u teba nič nezmení.

### Reálne čísla z hry (štart: 2 000 €, 35 kW chladenia, 0,08 €/kWh)

| Stroj | Cena | Hashrate | J/TH | Príjem/deň | Elektrina/deň | Čistý/deň | Návratnosť |
|---|---|---|---|---|---|---|---|
| BlockStick USB | 25 € | 30 GH/s | 167 | 0,00 € | 0,01 € | −0,01 € | nikdy |
| HashMaster S9 | 120 € | 14 TH/s | 96 | 2,26 € | 2,59 € | −0,34 € | nikdy |
| VoltCore T19 | 780 € | 84 TH/s | 37,5 | 13,53 € | 6,05 € | +7,49 € | 104 dní |
| VoltCore X19 Pro | 1 650 € | 141 TH/s | 21,3 | 22,72 € | 5,78 € | +16,94 € | 97 dní |
| NovaRig M60 Hydro | 4 200 € | 335 TH/s | 16,0 | 53,98 € | 10,29 € | +43,69 € | 96 dní |
| Quantum X100 | 8 500 € | 500 TH/s | 14,5 | 80,56 € | 13,92 € | +66,64 € | 128 dní |
| TitanHash Z1 | 26 000 € | 1 200 TH/s | 13,0 | 193,35 € | 29,95 € | +163,40 € | 159 dní |

Všimni si, že **hrubý príjem na TH/s je pre všetky stroje rovnaký** (0,1611 €/TH/deň).
Rozhoduje výhradne spotreba. Preto je S9 v mínuse, hoci je lacný — presne tak ako v skutočnosti.

### Čas

1 reálna sekunda = 1 herná hodina, vynásobená rýchlosťou (1× / 4× / 16×).
Herný rok teda trvá 36 minút pri 4× a 9 minút pri 16×. Halving príde po ~208 herných
dňoch, takže prvý halving zažiješ po ~20 minútach hrania pri 4×.
Hra sa ukladá každých 8 sekúnd a pri prechode na pozadie; po návrate sa
dosimuluje offline čas (max. 3 herné dni).

---

## Testy a ladenie vyváženia

```bash
npm test         # 26 testov enginu (Node, bez React Native)
npm run balance  # simuluje 8 herných rokov „rozumným hráčom“ a vypíše tabuľku
```

Testy pokrývajú okrem mechaník aj dva dôležité invarianty:

- **Účtovníctvo** — `hotovosť = príjmy − výdavky` musí sediť na cent.
- **Stabilita regulátora** — teplota sa musí ustáliť, nesmie kmitať ani spamovať log.

Pri ladení sa ukázalo, že naivné modely vedú k dvom typickým chybám, ktoré sú
v kóde vyriešené zámerne:

- **Kumulujúce sa jednorazové šoky.** Ak udalosť natrvalo vynásobí difficulty alebo
  cenu, po stovkách udalostí hodnota odletí (pôvodne difficulty ×887, cena −99 %).
  Riešenie: šoky sú dočasné a vracajú sa k trendu.
- **Mŕtve slučky.** Vypnutá farma nič nezarobí, takže sa nikdy nereštartuje.
  Riešenie: dlh s limitom, automatický treasury predaj BTC a reštart pri likvidite.

---

## QR kód na spustenie v telefóne

Expo CLI vypisuje QR priamo v termináli pri `npx expo start`. Ak chceš QR ako
**obrázok** (druhý displej, tlač, prezentácia, poslanie niekomu), použi generátor:

```bash
npm run qr                        # zistí tvoju LAN IP a port 8081
npm run qr -- --ip 192.168.1.42   # ak má viac rozhraní / chceš inú IP
npm run qr -- --port 19000        # ak Expo beží na inom porte
npm run qr -- --web               # pridá aj QR na webovú verziu http://IP:PORT
npm run qr -- --size 1024         # väčšie PNG
```

Vygeneruje sa do `qr/`:

| Súbor | Na čo |
|---|---|
| `expo-qr.svg` | vektorový — ideálny na tlač, nemení kvalitu |
| `expo-qr.png` | rastrový (predvolene 640 px) — na druhý displej |
| `expo-qr.html` | samostatná stránka s QR, URL a návodom (funguje offline) |
| `web-qr.svg/png` | len s `--web` — QR na `http://IP:PORT` |

Skript QR vypíše aj priamo do terminálu, takže ho môžeš nascanovať hneď.
URL overíš jednoduchým dekódom: QR z `qr/` obsahuje presne
`exp://<tvoja-IP>:8081`.

> Generátor potrebuje dev závislosť `qrcode` (je v `package.json`), takže pred
> prvým použitím spusti `npm install`. Ak sa na stroji nenájde LAN IP,
> použije placeholder `192.168.1.100` a upozorní ťa, že máš dosadiť vlastnú.

---

## Úprava vyváženia

Všetko je v `src/game/constants.js`. Najcitlivejšie páky:

```js
START_EUR: 2000,                  // počiatočný kapitál
NETWORK_SCALE: 0.25,              // zmenšenie siete (väčšie = ľahšia hra)
DIFFICULTY_GROWTH_PER_ERA: 0.006, // rast difficulty na 2016 blockov
ELEC_PRICE: 0.08,                 // €/kWh — najdôležitejšie číslo v celej hre
PRICE_CYCLE_AMP: 0.5,             // amplitúda 4-ročného cyklu (±50 %)
COOLING_BASE_KW: 35,              // základná kapacita chladenia
FAILURE_RATE_PER_DAY: 0.0015,     // poruchovosť
BASE_TIME_SCALE: 3600,            // 1 reálna s = 1 herná hodina
```

---

## Web náhľad

V `../preview/index.html` je webový náhľad, ktorý importuje **ten istý**
`src/game/engine.js`. Slúži na rýchle overenie mechaník bez spúšťania Expа:

```bash
cd ..   # koreň workspace-u
python3 -m http.server 8000 --bind 0.0.0.0
# otvor http://localhost:8000/preview/index.html
```
